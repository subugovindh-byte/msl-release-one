import { getDb } from '../db/connection.js';

/**
 * Generate next invoice number: SI/25-26/0001
 * Fiscal year April-March, zero-padded 4-digit sequence
 */
export function nextInvoiceId() {
  const db = getDb();
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  // Indian FY: Apr-Mar. If before April, we're still in prev FY.
  const fyStart = month >= 4 ? year : year - 1;
  const fyEnd = fyStart + 1;
  const prefix = `SI/${String(fyStart).slice(-2)}-${String(fyEnd).slice(-2)}/`;

  const row = db.prepare(
    `SELECT id FROM invoices WHERE id LIKE ? ORDER BY id DESC LIMIT 1`
  ).get(prefix + '%');

  let seq = 1;
  if (row) {
    const lastSeq = parseInt(row.id.slice(prefix.length), 10);
    seq = lastSeq + 1;
  }
  return prefix + String(seq).padStart(4, '0');
}

export function nextPOId() {
  const db = getDb();
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const fyStart = month >= 4 ? year : year - 1;
  const fyEnd = fyStart + 1;
  const prefix = `PO/${String(fyStart).slice(-2)}-${String(fyEnd).slice(-2)}/`;

  const row = db.prepare(
    `SELECT id FROM purchase_orders WHERE id LIKE ? ORDER BY id DESC LIMIT 1`
  ).get(prefix + '%');

  let seq = 1;
  if (row) {
    const lastSeq = parseInt(row.id.slice(prefix.length), 10);
    seq = lastSeq + 1;
  }
  return prefix + String(seq);
}

export function nextJobId() {
  const db = getDb();
  const row = db.prepare(
    `SELECT id FROM production_jobs WHERE id LIKE 'JOB-%' ORDER BY id DESC LIMIT 1`
  ).get();

  let seq = 1;
  if (row) {
    const lastSeq = parseInt(row.id.slice(4), 10);
    seq = lastSeq + 1;
  }
  return `JOB-${seq}`;
}

export function nextPaymentId(type = 'receipt') {
  const db = getDb();
  const prefix = type === 'receipt' ? 'RCT' : 'PMT';
  const year = new Date().getFullYear();
  const pattern = `${prefix}/${year}/%`;

  const row = db.prepare(
    `SELECT id FROM payments WHERE id LIKE ? ORDER BY id DESC LIMIT 1`
  ).get(pattern);

  let seq = 1;
  if (row) {
    const lastSeq = parseInt(row.id.split('/').pop(), 10);
    seq = lastSeq + 1;
  }
  return `${prefix}/${year}/${String(seq).padStart(3, '0')}`;
}

export function nextCustomerId() {
  const db = getDb();
  const row = db.prepare(
    `SELECT id FROM customers WHERE id LIKE 'C%' ORDER BY id DESC LIMIT 1`
  ).get();
  let seq = 1;
  if (row) seq = parseInt(row.id.slice(1), 10) + 1;
  return 'C' + String(seq).padStart(3, '0');
}

export function nextVendorId() {
  const db = getDb();
  const row = db.prepare(
    `SELECT id FROM vendors WHERE id LIKE 'V%' ORDER BY id DESC LIMIT 1`
  ).get();
  let seq = 1;
  if (row) seq = parseInt(row.id.slice(1), 10) + 1;
  return 'V' + String(seq).padStart(3, '0');
}
