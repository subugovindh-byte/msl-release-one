import { Router } from 'express';
import { getDb } from '../db/connection.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { poCreateSchema, GST_RATE } from '@modernex/shared';
import { NotFoundError, AppError } from '../middleware/error.js';
import { audit } from '../services/audit.js';
import { nextPOId } from '../services/idGenerator.js';

export const purchaseRouter = Router();

purchaseRouter.use(authenticate);

// ─── GET /purchase ───
purchaseRouter.get('/', (req, res) => {
  const { vendor_id, status, from, to } = req.query;
  const db = getDb();
  let sql = 'SELECT * FROM purchase_orders WHERE 1=1';
  const params = [];
  if (vendor_id) { sql += ' AND vendor_id = ?'; params.push(vendor_id); }
  if (status) { sql += ' AND status = ?'; params.push(status); }
  if (from) { sql += ' AND date >= ?'; params.push(from); }
  if (to) { sql += ' AND date <= ?'; params.push(to); }
  sql += ' ORDER BY date DESC, id DESC';
  res.json({ purchase_orders: db.prepare(sql).all(...params) });
});

// ─── GET /purchase/:id ───
purchaseRouter.get('/:id', (req, res, next) => {
  try {
    const db = getDb();
    const po = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id);
    if (!po) throw new NotFoundError('PO not found');
    res.json({ po });
  } catch (err) { next(err); }
});

// ─── POST /purchase ───
purchaseRouter.post('/',
  requireRole('admin', 'accounts'),
  validate(poCreateSchema),
  (req, res, next) => {
    try {
      const db = getDb();
      const p = req.body;
      const vendor = db.prepare('SELECT * FROM vendors WHERE id = ?').get(p.vendor_id);
      if (!vendor) throw new NotFoundError('Vendor not found');

      const taxable = Math.round(p.cft * p.rate_per_cft_paise) + (p.transport_paise || 0);
      const gst = Math.round(taxable * GST_RATE);
      const total = taxable + gst;

      const id = nextPOId();
      const date = new Date().toISOString().slice(0, 10);

      db.prepare(`
        INSERT INTO purchase_orders (
          id, date, vendor_id, variety, blocks, cft, rate_per_cft_paise,
          transport_paise, taxable_paise, gst_paise, total_paise, notes, created_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        id, date, p.vendor_id, p.variety, p.blocks, p.cft, p.rate_per_cft_paise,
        p.transport_paise || 0, taxable, gst, total, p.notes || null, req.user.username
      );

      const po = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(id);
      audit(req, 'PO_CREATE', 'purchase_orders', id, null, po);
      res.status(201).json({ po });
    } catch (err) { next(err); }
  }
);

// ─── PATCH /purchase/:id/status ───
purchaseRouter.patch('/:id/status',
  requireRole('admin', 'accounts'),
  (req, res, next) => {
    try {
      const { status } = req.body;
      if (!['new', 'approved', 'received', 'cancelled'].includes(status)) {
        throw new AppError('Invalid status', 400);
      }
      const db = getDb();
      const existing = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id);
      if (!existing) throw new NotFoundError('PO not found');

      db.prepare('UPDATE purchase_orders SET status = ?, updated_by = ? WHERE id = ?')
        .run(status, req.user.username, req.params.id);

      const updated = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id);
      audit(req, 'PO_STATUS_CHANGE', 'purchase_orders', req.params.id,
            { status: existing.status }, { status });
      res.json({ po: updated });
    } catch (err) { next(err); }
  }
);
