import { Router } from 'express';
import { getDb } from '../db/connection.js';
import { authenticate, requireRole } from '../middleware/auth.js';

export const reportsRouter = Router();
reportsRouter.use(authenticate);

// ─── GET /reports/dashboard — KPIs ───
reportsRouter.get('/dashboard', (req, res) => {
  const db = getDb();

  const revenue = db.prepare(`SELECT COALESCE(SUM(taxable_paise), 0) as v FROM invoices`).get().v;
  const ar = db.prepare(`SELECT COALESCE(SUM(total_paise), 0) as v FROM invoices WHERE paid = 0`).get().v;
  const collected = db.prepare(`SELECT COALESCE(SUM(total_paise), 0) as v FROM invoices WHERE paid = 1`).get().v;
  const ap = db.prepare(`SELECT COALESCE(SUM(total_paise), 0) as v FROM purchase_orders`).get().v;
  const gst_output = db.prepare(`
    SELECT COALESCE(SUM(cgst_paise + sgst_paise + igst_paise), 0) as v FROM invoices
  `).get().v;
  const gst_itc = db.prepare(`SELECT COALESCE(SUM(gst_paise), 0) as v FROM purchase_orders`).get().v;

  // Stock value across all products (each uses its own UOM — rate × stock in UOM)
  const stockValue = db.prepare(`
    SELECT COALESCE(SUM(rate_paise * stock), 0) as v FROM products WHERE active = 1
  `).get().v;
  const totalProducts = db.prepare(
    `SELECT COUNT(*) as v FROM products WHERE active = 1`
  ).get().v;
  const invoiceCount = db.prepare(`SELECT COUNT(*) as v FROM invoices`).get().v;
  const unpaidCount = db.prepare(`SELECT COUNT(*) as v FROM invoices WHERE paid = 0`).get().v;
  const lowStock = db.prepare(
    `SELECT COUNT(*) as v FROM products WHERE active = 1 AND stock <= 2`
  ).get().v;

  // Weekly revenue for chart
  const weeklyRevenue = db.prepare(`
    SELECT strftime('%Y-%W', date) as week, SUM(taxable_paise) as v
    FROM invoices
    WHERE date >= date('now', '-56 days')
    GROUP BY week ORDER BY week
  `).all();

  // ─── Per-kind product mix (stock value) ───
  const byKind = db.prepare(`
    SELECT kind,
           COUNT(*) as products,
           SUM(stock) as total_stock,
           SUM(rate_paise * stock) as value_paise
    FROM products WHERE active = 1
    GROUP BY kind
    ORDER BY value_paise DESC
  `).all();

  // ─── Grade mix for slabs only ───
  const gradeMix = db.prepare(`
    SELECT grade, SUM(stock) as stock
    FROM products WHERE active = 1 AND kind = 'slab' AND grade IS NOT NULL
    GROUP BY grade
  `).all();

  // ─── Sales mix by kind (last 30 days) ───
  const salesByKind = db.prepare(`
    SELECT ii.product_kind as kind,
           COUNT(DISTINCT ii.invoice_id) as invoices,
           SUM(ii.line_total_paise) as revenue_paise
    FROM invoice_items ii
    JOIN invoices i ON i.id = ii.invoice_id
    WHERE i.date >= date('now', '-30 days')
    GROUP BY ii.product_kind
    ORDER BY revenue_paise DESC
  `).all();

  res.json({
    summary: {
      revenue_paise: revenue,
      ar_paise: ar,
      collected_paise: collected,
      ap_paise: ap,
      gst_output_paise: gst_output,
      gst_itc_paise: gst_itc,
      net_gst_paise: Math.max(0, gst_output - gst_itc),
      stock_value_paise: stockValue,
      total_products: totalProducts,
      invoice_count: invoiceCount,
      unpaid_count: unpaidCount,
      low_stock_count: lowStock,
    },
    charts: {
      weeklyRevenue,
      gradeMix,
      byKind,
      salesByKind,
    },
  });
});

// ─── GET /reports/pnl ───
reportsRouter.get('/pnl', requireRole('admin', 'accounts'), (req, res) => {
  const { from, to } = req.query;
  const db = getDb();
  const range = from && to ? { from, to } : null;

  const revenue = range
    ? db.prepare(`SELECT COALESCE(SUM(taxable_paise), 0) as v FROM invoices WHERE date >= ? AND date <= ?`).get(range.from, range.to).v
    : db.prepare(`SELECT COALESCE(SUM(taxable_paise), 0) as v FROM invoices`).get().v;

  const rawMaterial = range
    ? db.prepare(`SELECT COALESCE(SUM(taxable_paise), 0) as v FROM purchase_orders WHERE date >= ? AND date <= ?`).get(range.from, range.to).v
    : db.prepare(`SELECT COALESCE(SUM(taxable_paise), 0) as v FROM purchase_orders`).get().v;

  const production = range
    ? db.prepare(`SELECT COALESCE(SUM(labour_paise + power_paise + consumables_paise), 0) as v FROM production_jobs WHERE date >= ? AND date <= ?`).get(range.from, range.to).v
    : db.prepare(`SELECT COALESCE(SUM(labour_paise + power_paise + consumables_paise), 0) as v FROM production_jobs`).get().v;

  // Per-kind revenue (for margin analysis)
  const revByKind = range
    ? db.prepare(`
        SELECT ii.product_kind as kind, COALESCE(SUM(ii.line_total_paise), 0) as revenue
        FROM invoice_items ii JOIN invoices i ON i.id = ii.invoice_id
        WHERE i.date >= ? AND i.date <= ? GROUP BY ii.product_kind
      `).all(range.from, range.to)
    : db.prepare(`
        SELECT product_kind as kind, COALESCE(SUM(line_total_paise), 0) as revenue
        FROM invoice_items GROUP BY product_kind
      `).all();

  const cogs = Math.round(rawMaterial * 0.6);
  const transport = 2400000;
  const overheads = 1800000;
  const grossProfit = revenue - cogs - production - transport - overheads;

  res.json({
    period: { from, to },
    income: { revenue_paise: revenue },
    expenses: {
      raw_material_paise: cogs,
      production_paise: production,
      transport_paise: transport,
      overheads_paise: overheads,
    },
    gross_profit_paise: grossProfit,
    margin_pct: revenue > 0 ? ((grossProfit / revenue) * 100).toFixed(2) : 0,
    revenue_by_kind: revByKind,
  });
});

// ─── GET /reports/gstr1 — grouped by HSN (2515 / 2516 / 2517 rows) ───
reportsRouter.get('/gstr1', requireRole('admin', 'accounts'), (req, res) => {
  const { from, to } = req.query;
  const db = getDb();

  // We compute HSN-grouped totals from the invoice_items table (per-line HSN)
  const buildHsnQuery = (extraWhere) => `
    SELECT ii.hsn,
           COUNT(DISTINCT ii.invoice_id) as invoices,
           COALESCE(SUM(ii.line_total_paise), 0) as taxable,
           COALESCE(SUM(
             CASE WHEN i.customer_state = 'Tamil Nadu'
                  THEN ROUND(ii.line_total_paise * (CASE WHEN ii.hsn = '2517' THEN 0.025 ELSE 0.06 END))
                  ELSE 0 END
           ), 0) as cgst,
           COALESCE(SUM(
             CASE WHEN i.customer_state = 'Tamil Nadu'
                  THEN ROUND(ii.line_total_paise * (CASE WHEN ii.hsn = '2517' THEN 0.025 ELSE 0.06 END))
                  ELSE 0 END
           ), 0) as sgst,
           COALESCE(SUM(
             CASE WHEN i.customer_state != 'Tamil Nadu'
                  THEN ROUND(ii.line_total_paise * (CASE WHEN ii.hsn = '2517' THEN 0.05 ELSE 0.12 END))
                  ELSE 0 END
           ), 0) as igst
    FROM invoice_items ii
    JOIN invoices i ON i.id = ii.invoice_id
    WHERE 1=1 ${extraWhere}
    GROUP BY ii.hsn
    ORDER BY ii.hsn
  `;

  const range = from && to ? ' AND i.date >= ? AND i.date <= ?' : '';
  const rangeParams = from && to ? [from, to] : [];

  const hsnBreakdown = db.prepare(buildHsnQuery(range)).all(...rangeParams);

  // Invoice-level B2B / B2C totals
  const invWhere = from && to ? 'WHERE date >= ? AND date <= ?' : '';
  const invParams = from && to ? [from, to] : [];
  const b2bCond = invWhere ? ` AND customer_gstin IS NOT NULL AND customer_gstin != ''`
                           : ` WHERE customer_gstin IS NOT NULL AND customer_gstin != ''`;
  const b2cCond = invWhere ? ` AND (customer_gstin IS NULL OR customer_gstin = '')`
                           : ` WHERE (customer_gstin IS NULL OR customer_gstin = '')`;

  const b2b = db.prepare(`
    SELECT COALESCE(SUM(taxable_paise), 0) as taxable,
           COALESCE(SUM(cgst_paise), 0) as cgst,
           COALESCE(SUM(sgst_paise), 0) as sgst,
           COALESCE(SUM(igst_paise), 0) as igst,
           COUNT(*) as count
    FROM invoices ${invWhere} ${b2bCond}
  `).get(...invParams);

  const b2c = db.prepare(`
    SELECT COALESCE(SUM(taxable_paise), 0) as taxable,
           COALESCE(SUM(cgst_paise), 0) as cgst,
           COALESCE(SUM(sgst_paise), 0) as sgst,
           COALESCE(SUM(igst_paise), 0) as igst,
           COUNT(*) as count
    FROM invoices ${invWhere} ${b2cCond}
  `).get(...invParams);

  res.json({
    period: { from, to },
    hsn_breakdown: hsnBreakdown,
    b2b, b2c,
    total: {
      taxable: b2b.taxable + b2c.taxable,
      cgst: b2b.cgst + b2c.cgst,
      sgst: b2b.sgst + b2c.sgst,
      igst: b2b.igst + b2c.igst,
    },
  });
});

// ─── GET /reports/gstr3b ───
reportsRouter.get('/gstr3b', requireRole('admin', 'accounts'), (req, res) => {
  const { from, to } = req.query;
  const db = getDb();
  const range = from && to ? ' WHERE date >= ? AND date <= ?' : '';
  const rangeParams = from && to ? [from, to] : [];

  const output = db.prepare(`
    SELECT COALESCE(SUM(taxable_paise), 0) as taxable,
           COALESCE(SUM(cgst_paise), 0) as cgst,
           COALESCE(SUM(sgst_paise), 0) as sgst,
           COALESCE(SUM(igst_paise), 0) as igst
    FROM invoices ${range}
  `).get(...rangeParams);

  const itc = db.prepare(`
    SELECT COALESCE(SUM(gst_paise), 0) as total_itc FROM purchase_orders ${range}
  `).get(...rangeParams);

  const itcCgst = Math.round(itc.total_itc / 2);
  const itcSgst = itc.total_itc - itcCgst;

  res.json({
    period: { from, to },
    '3_1_outward': output,
    '4_itc': {
      cgst_paise: itcCgst,
      sgst_paise: itcSgst,
      total_paise: itc.total_itc,
    },
    net_payable: {
      cgst_paise: Math.max(0, output.cgst - itcCgst),
      sgst_paise: Math.max(0, output.sgst - itcSgst),
      igst_paise: output.igst,
      total_paise: Math.max(0, (output.cgst + output.sgst + output.igst) - itc.total_itc),
    },
  });
});

// ─── GET /reports/aging ───
reportsRouter.get('/aging', requireRole('admin', 'accounts'), (req, res) => {
  const db = getDb();
  const rows = db.prepare(`
    SELECT
      CASE
        WHEN julianday('now') - julianday(date) <= 30 THEN '0-30'
        WHEN julianday('now') - julianday(date) <= 60 THEN '31-60'
        WHEN julianday('now') - julianday(date) <= 90 THEN '61-90'
        ELSE '90+'
      END as bucket,
      COUNT(*) as count,
      SUM(total_paise) as amount
    FROM invoices
    WHERE paid = 0
    GROUP BY bucket
    ORDER BY
      CASE bucket
        WHEN '0-30' THEN 1 WHEN '31-60' THEN 2
        WHEN '61-90' THEN 3 ELSE 4
      END
  `).all();
  res.json({ aging: rows });
});
