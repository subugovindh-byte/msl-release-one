import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';

let _db = null;

export function getDb() {
  if (_db) return _db;

  // Ensure directory exists
  const dir = path.dirname(config.dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
    logger.info({ dir }, 'Created database directory');
  }

  _db = new Database(config.dbPath, {
    verbose: config.isDev() ? (msg) => logger.debug({ sql: msg }) : null,
  });

  // ── Performance + durability PRAGMAs ──
  _db.pragma('journal_mode = WAL');          // Write-ahead log → readers don't block writers
  _db.pragma('synchronous = NORMAL');         // Durability + speed balance (safe with WAL)
  _db.pragma('foreign_keys = ON');            // Enforce FK constraints
  _db.pragma('cache_size = -64000');          // 64 MB cache (negative = KB)
  _db.pragma('temp_store = MEMORY');          // Temp tables in RAM
  _db.pragma('busy_timeout = 5000');          // Wait 5s before SQLITE_BUSY error

  logger.info({ path: config.dbPath }, 'SQLite opened (WAL mode)');
  return _db;
}

export function closeDb() {
  if (_db) {
    _db.close();
    _db = null;
    logger.info('SQLite closed');
  }
}

// Graceful shutdown
process.on('SIGINT', closeDb);
process.on('SIGTERM', closeDb);
