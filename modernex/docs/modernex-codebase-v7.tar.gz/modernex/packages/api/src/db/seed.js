import bcrypt from 'bcrypt';
import { getDb, closeDb } from './connection.js';
import { runMigrations } from './migrate.js';
import { logger } from '../utils/logger.js';
import { toPaise } from '@modernex/shared';

const DEMO_USERS = [
  { username: 'admin',    password: 'admin123',    full_name: 'Subramani R',   role: 'admin' },
  { username: 'accounts', password: 'accounts123', full_name: 'Priya K',        role: 'accounts' },
  { username: 'yard',     password: 'yard123',     full_name: 'Ganesh M',       role: 'yard' },
  { username: 'sales',    password: 'sales123',    full_name: 'Rajesh S',       role: 'sales' },
];

const DEMO_CUSTOMERS = [
  { id: 'C001', name: 'Rajan Tiles & Marbles',     gstin: '33AABCR1234A1Z5', state: 'Tamil Nadu', credit_days: 30, outstanding_paise: 10044200 },
  { id: 'C002', name: 'Sri Balaji Constructions',  gstin: '33AADBS5678B2Z1', state: 'Tamil Nadu', credit_days: 15, outstanding_paise: 0 },
  { id: 'C003', name: 'Kumar Exports Pvt Ltd',     gstin: '33AABCK9012C3Z8', state: 'Tamil Nadu', credit_days: 45, outstanding_paise: 15088600 },
  { id: 'C004', name: 'Prasad Interiors',          gstin: '29AABCP3456D4Z2', state: 'Karnataka',  credit_days: 0,  outstanding_paise: 1850000 },
  { id: 'C005', name: 'Walk-in Customer',          gstin: null,              state: 'Tamil Nadu', credit_days: 0,  outstanding_paise: 0 },
];

const DEMO_VENDORS = [
  { id: 'V001', name: 'Chendarapalli Granite Quarry', gstin: '33AABCC1234A1Z5', state: 'Tamil Nadu', type: 'Quarry',      msme: 1, contact: '9876543210' },
  { id: 'V002', name: 'Krishnagiri Block Traders',    gstin: '33AADBT5678B2Z1', state: 'Tamil Nadu', type: 'Broker',      msme: 0, contact: '9876543211' },
  { id: 'V003', name: 'Sri Lakshmi Transport',        gstin: '33AADST9012C3Z8', state: 'Tamil Nadu', type: 'Transporter', msme: 1, contact: '9876543212' },
];

const DEMO_SLABS = [
  { id: 'S001', lot_id: 'LOT-024', variety: 'Paradiso Classic', size: '260×160', thickness_mm: 18, grade: 'A',  sqft: 27.6, rate: 420, stock: 8 },
  { id: 'S002', lot_id: 'LOT-024', variety: 'Paradiso Classic', size: '240×140', thickness_mm: 18, grade: 'A',  sqft: 23.3, rate: 420, stock: 5 },
  { id: 'S003', lot_id: 'LOT-025', variety: 'Paradiso Extra',   size: '270×170', thickness_mm: 20, grade: 'A+', sqft: 31.8, rate: 580, stock: 3 },
  { id: 'S004', lot_id: 'LOT-022', variety: 'Multicolour Red',  size: '200×120', thickness_mm: 18, grade: 'B',  sqft: 16.7, rate: 290, stock: 12 },
  { id: 'S005', lot_id: 'LOT-022', variety: 'Multicolour Red',  size: '220×130', thickness_mm: 18, grade: 'A',  sqft: 19.8, rate: 320, stock: 7 },
  { id: 'S006', lot_id: 'LOT-026', variety: 'Tan Brown',        size: '250×150', thickness_mm: 20, grade: 'A',  sqft: 26.0, rate: 490, stock: 4 },
  { id: 'S007', lot_id: 'LOT-026', variety: 'Tan Brown',        size: '230×140', thickness_mm: 20, grade: 'B',  sqft: 22.4, rate: 360, stock: 9 },
  { id: 'S008', lot_id: 'LOT-027', variety: 'Black Galaxy',     size: '260×160', thickness_mm: 18, grade: 'A+', sqft: 27.6, rate: 760, stock: 2 },
  { id: 'S009', lot_id: 'LOT-023', variety: 'Vizag Blue',       size: '240×150', thickness_mm: 18, grade: 'A',  sqft: 25.0, rate: 530, stock: 6 },
  { id: 'S010', lot_id: 'LOT-028', variety: 'Steel Grey',       size: '200×110', thickness_mm: 18, grade: 'B',  sqft: 15.3, rate: 270, stock: 14 },
  { id: 'S011', lot_id: 'LOT-028', variety: 'Steel Grey',       size: '260×160', thickness_mm: 20, grade: 'A',  sqft: 27.6, rate: 340, stock: 5 },
  { id: 'S012', lot_id: 'LOT-029', variety: 'Absolute Black',   size: '250×160', thickness_mm: 18, grade: 'A+', sqft: 27.8, rate: 680, stock: 3 },
];

export async function seed() {
  runMigrations();
  const db = getDb();

  // Skip if already seeded
  const userCount = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  if (userCount > 0) {
    logger.info('Database already seeded, skipping');
    return;
  }

  logger.info('Seeding demo data...');

  // Users with bcrypt hashes
  const insertUser = db.prepare(
    'INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)'
  );
  for (const u of DEMO_USERS) {
    const hash = await bcrypt.hash(u.password, 12);
    insertUser.run(u.username, hash, u.full_name, u.role);
  }

  // Customers
  const insertCust = db.prepare(
    `INSERT INTO customers (id, name, gstin, state, credit_days, outstanding_paise)
     VALUES (?, ?, ?, ?, ?, ?)`
  );
  for (const c of DEMO_CUSTOMERS) {
    insertCust.run(c.id, c.name, c.gstin, c.state, c.credit_days, c.outstanding_paise);
  }

  // Vendors
  const insertVend = db.prepare(
    `INSERT INTO vendors (id, name, gstin, state, type, msme, contact)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  );
  for (const v of DEMO_VENDORS) {
    insertVend.run(v.id, v.name, v.gstin, v.state, v.type, v.msme, v.contact);
  }

  // Slabs
  const insertSlab = db.prepare(
    `INSERT INTO slabs (id, lot_id, variety, size, thickness_mm, grade, sqft, rate_paise, stock)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  for (const s of DEMO_SLABS) {
    insertSlab.run(s.id, s.lot_id, s.variety, s.size, s.thickness_mm, s.grade, s.sqft, toPaise(s.rate), s.stock);
  }

  // ── v7: Modernex actual catalog — regional varieties as polymorphic products ──
  // Migration 005 has already created the products + product_slabs tables,
  // and 007 has created variety_defaults. Insert one demo product per real variety.
  const insertProd = db.prepare(`
    INSERT OR IGNORE INTO products
      (id, kind, variety, hsn, uom, grade, lot_id, rate_paise, stock, active, created_by)
    VALUES (?, 'slab', ?, '2516', 'sqft', ?, ?, ?, ?, 1, 'seed-v7')
  `);
  const insertProdSlab = db.prepare(`
    INSERT OR IGNORE INTO product_slabs (product_id, size_lw, thickness_mm, sqft)
    VALUES (?, ?, ?, ?)
  `);

  const REGIONAL_VARIETIES = [
    // Andhra
    { id: 'PRD-400001', variety: 'Viscont White',     grade: 'A',  lot: 'LOT-050', rate: 380, stock: 8, size: '2700×1800', tk: 20, sqft: 52.30 },
    { id: 'PRD-400002', variety: 'S-K Blue',          grade: 'A',  lot: 'LOT-051', rate: 520, stock: 5, size: '2600×1600', tk: 20, sqft: 44.78 },
    { id: 'PRD-400003', variety: 'Safari Green',      grade: 'A',  lot: 'LOT-052', rate: 580, stock: 4, size: '2700×1800', tk: 20, sqft: 52.30 },
    { id: 'PRD-400004', variety: 'Indian Mahogany',   grade: 'A',  lot: 'LOT-053', rate: 460, stock: 7, size: '2600×1700', tk: 20, sqft: 47.57 },
    // Telangana
    { id: 'PRD-400010', variety: 'Jet Black',         grade: 'A+', lot: 'LOT-060', rate: 620, stock: 3, size: '2600×1600', tk: 20, sqft: 44.78 },
    { id: 'PRD-400011', variety: 'Green Galaxy',      grade: 'A+', lot: 'LOT-061', rate: 780, stock: 4, size: '2700×1800', tk: 20, sqft: 52.30 },
    { id: 'PRD-400012', variety: 'English Oak',       grade: 'A',  lot: 'LOT-062', rate: 520, stock: 6, size: '2600×1700', tk: 20, sqft: 47.57 },
    { id: 'PRD-400013', variety: 'Indian Brown',      grade: 'A',  lot: 'LOT-063', rate: 480, stock: 7, size: '2600×1600', tk: 18, sqft: 44.78 },
    { id: 'PRD-400014', variety: 'Colombo Blue',      grade: 'A',  lot: 'LOT-064', rate: 540, stock: 5, size: '2700×1800', tk: 20, sqft: 52.30 },
    { id: 'PRD-400015', variety: 'Colombo Juparana',  grade: 'A+', lot: 'LOT-065', rate: 680, stock: 4, size: '2700×1800', tk: 20, sqft: 52.30 },
    { id: 'PRD-400016', variety: 'Classic Yellowstone', grade: 'A', lot: 'LOT-066', rate: 580, stock: 6, size: '2600×1700', tk: 20, sqft: 47.57 },
    // Tamil Nadu
    { id: 'PRD-400020', variety: 'Mapple Red',        grade: 'A',  lot: 'LOT-070', rate: 480, stock: 6, size: '2600×1700', tk: 20, sqft: 47.57 },
    { id: 'PRD-400021', variety: 'Warangal Black',    grade: 'A+', lot: 'LOT-071', rate: 680, stock: 4, size: '2600×1600', tk: 20, sqft: 44.78 },
    { id: 'PRD-400022', variety: 'Sapphire Brown',    grade: 'A+', lot: 'LOT-072', rate: 720, stock: 3, size: '2700×1800', tk: 20, sqft: 52.30 },
    { id: 'PRD-400023', variety: 'Kunnam Black',      grade: 'A+', lot: 'LOT-073', rate: 780, stock: 4, size: '2600×1600', tk: 20, sqft: 44.78 },
  ];

  for (const v of REGIONAL_VARIETIES) {
    insertProd.run(v.id, v.variety, v.grade, v.lot, toPaise(v.rate), v.stock);
    insertProdSlab.run(v.id, v.size, v.tk, v.sqft);
  }

  logger.info({
    users: DEMO_USERS.length,
    customers: DEMO_CUSTOMERS.length,
    vendors: DEMO_VENDORS.length,
    slabs: DEMO_SLABS.length,
    regional_varieties: REGIONAL_VARIETIES.length,
  }, 'Seed complete');
}

// Run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  await seed();
  closeDb();
}
