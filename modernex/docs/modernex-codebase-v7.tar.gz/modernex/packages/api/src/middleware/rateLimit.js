import rateLimit from 'express-rate-limit';

// Tight limiter for login/auth endpoints — prevents brute force
export const authLimiter = rateLimit({
  windowMs: 60 * 1000,         // 1 minute
  max: 10,                      // 10 attempts per IP per minute
  message: { error: 'Too many authentication attempts. Try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// General API limiter
export const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 100,                     // 100 requests per IP per minute
  message: { error: 'Too many requests. Please slow down.' },
  standardHeaders: true,
  legacyHeaders: false,
});
