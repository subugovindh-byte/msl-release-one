import pino from 'pino';
import { config } from './config.js';

const transport = config.isDev()
  ? {
      target: 'pino-pretty',
      options: {
        colorize: true,
        translateTime: 'HH:MM:ss',
        ignore: 'pid,hostname',
      },
    }
  : undefined;

export const logger = pino({
  level: config.logLevel,
  transport,
});
