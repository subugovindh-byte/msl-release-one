import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';

// Use an ephemeral test database
const TEST_DB = './data/test.db';
process.env.DB_PATH = TEST_DB;
process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'test-secret-for-tests-only';

import { createApp } from '../src/server.js';
import { runMigrations } from '../src/db/migrate.js';
import { seed } from '../src/db/seed.js';
import { closeDb } from '../src/db/connection.js';

describe('API integration', () => {
  let app;
  let cookies;

  beforeAll(async () => {
    if (fs.existsSync(TEST_DB)) fs.unlinkSync(TEST_DB);
    if (fs.existsSync(TEST_DB + '-wal')) fs.unlinkSync(TEST_DB + '-wal');
    if (fs.existsSync(TEST_DB + '-shm')) fs.unlinkSync(TEST_DB + '-shm');
    runMigrations();
    await seed();
    app = createApp();
  });

  afterAll(() => {
    closeDb();
    try { fs.unlinkSync(TEST_DB); } catch {}
    try { fs.unlinkSync(TEST_DB + '-wal'); } catch {}
    try { fs.unlinkSync(TEST_DB + '-shm'); } catch {}
  });

  it('GET /api/health returns ok', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
  });

  it('POST /api/auth/login rejects bad credentials', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ username: 'admin', password: 'wrongpass' });
    expect(res.status).toBe(401);
  });

  it('POST /api/auth/login succeeds with seed creds', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ username: 'admin', password: 'admin123' });
    expect(res.status).toBe(200);
    expect(res.body.user.username).toBe('admin');
    cookies = res.headers['set-cookie'];
  });

  it('GET /api/slabs requires auth', async () => {
    const res = await request(app).get('/api/slabs');
    expect(res.status).toBe(401);
  });

  it('GET /api/slabs returns seed data with cookie', async () => {
    const res = await request(app).get('/api/slabs').set('Cookie', cookies);
    expect(res.status).toBe(200);
    expect(res.body.slabs.length).toBeGreaterThan(0);
    expect(res.body.slabs[0]).toHaveProperty('variety');
  });

  it('POST /api/invoices creates invoice and decrements stock', async () => {
    // Get a slab to buy
    const slabsRes = await request(app).get('/api/slabs?variety=Paradiso Classic').set('Cookie', cookies);
    const slab = slabsRes.body.slabs[0];
    const initialStock = slab.stock;

    const res = await request(app)
      .post('/api/invoices')
      .set('Cookie', cookies)
      .send({
        customer_id: 'C001',
        discount_pct: 0,
        items: [{
          slab_id: slab.id,
          variety: slab.variety,
          size: slab.size,
          thickness_mm: slab.thickness_mm,
          grade: slab.grade,
          sqft: slab.sqft,
          rate_paise: slab.rate_paise,
          qty: 1,
        }],
      });

    expect(res.status).toBe(201);
    expect(res.body.invoice.id).toMatch(/^SI\//);
    expect(res.body.invoice.total_paise).toBeGreaterThan(0);
    expect(res.body.invoice.cgst_paise).toBeGreaterThan(0);  // TN customer -> CGST+SGST
    expect(res.body.invoice.sgst_paise).toBe(res.body.invoice.cgst_paise);
    expect(res.body.invoice.igst_paise).toBe(0);

    // Stock decrement
    const after = await request(app).get(`/api/slabs/${slab.id}`).set('Cookie', cookies);
    expect(after.body.slab.stock).toBe(initialStock - 1);
  });

  it('Inter-state sale generates IGST instead of CGST+SGST', async () => {
    const slabsRes = await request(app).get('/api/slabs').set('Cookie', cookies);
    const slab = slabsRes.body.slabs.find(s => s.stock > 0);
    const res = await request(app)
      .post('/api/invoices')
      .set('Cookie', cookies)
      .send({
        customer_id: 'C004',  // Karnataka customer in seed
        items: [{
          slab_id: slab.id, variety: slab.variety, size: slab.size,
          thickness_mm: slab.thickness_mm, grade: slab.grade,
          sqft: slab.sqft, rate_paise: slab.rate_paise, qty: 1,
        }],
      });
    expect(res.status).toBe(201);
    expect(res.body.invoice.igst_paise).toBeGreaterThan(0);
    expect(res.body.invoice.cgst_paise).toBe(0);
    expect(res.body.invoice.sgst_paise).toBe(0);
  });

  it('Mark invoice paid creates receipt payment', async () => {
    const inv = await request(app).get('/api/invoices?paid=false').set('Cookie', cookies);
    const unpaidId = inv.body.invoices[0].id;
    const res = await request(app)
      .post(`/api/invoices/${unpaidId}/pay`)
      .set('Cookie', cookies)
      .send({ mode: 'NEFT', utr: 'TESTUTR123' });
    expect(res.status).toBe(200);
    expect(res.body.invoice.paid).toBe(1);
  });
});
