import { useEffect, useState } from 'react';
import { api } from '../utils/api.js';
import { useToast } from '../contexts/ToastContext.jsx';
import { StatCard } from '../components/Shared.jsx';

export function SystemPage() {
  const { notify } = useToast();
  const [tab, setTab] = useState('backup');
  const [backups, setBackups] = useState([]);
  const [syncing, setSyncing] = useState(false);

  const load = () => api.get('/backups').then(d => setBackups(d.backups || []));
  useEffect(() => { load(); }, []);

  async function trigger() {
    setSyncing(true);
    try {
      await api.post('/backups/trigger');
      notify('Backup uploaded to Azure Blob ✓');
      load();
    } catch (err) {
      notify(err.message || 'Backup failed', true);
    } finally {
      setSyncing(false);
    }
  }

  return (
    <div className="pw">
      <div className="ph-title">System</div>
      <div className="ph-sub">Backup · Auth · Compliance · Stack</div>

      <div className="itabs">
        {['backup', 'auth', 'compliance', 'stack'].map(k => (
          <div key={k} className={`itab${tab === k ? ' on' : ''}`} onClick={() => setTab(k)}>
            {{ backup: 'Backup', auth: 'Auth', compliance: 'Compliance', stack: 'Stack' }[k]}
          </div>
        ))}
      </div>

      {tab === 'backup' && (
        <>
          <div className="sc-grid">
            <StatCard label="Last Backup"
              value={backups[0] ? new Date(backups[0].ts).toLocaleDateString('en-IN') : '—'}
              sub={backups[0]?.trigger || '—'} tone="s" />
            <StatCard label="Snapshots" value={backups.length} sub="registry entries" tone="b" />
            <StatCard label="Retention" value="30d + 12mo" sub="Azure lifecycle" tone="r" />
            <StatCard label="Cadence" value="02:00 IST" sub="daily cron" tone="g" />
          </div>

          <div className="card">
            <div className="card-head">
              <span className="card-title">Azure Blob Snapshots</span>
              <button className="btn btn-sage btn-sm" onClick={trigger} disabled={syncing}>
                {syncing ? '⟳ Syncing…' : '⬆ Backup Now'}
              </button>
            </div>
            <div className="card-body">
              {backups.slice(0, 10).map(b => (
                <div key={b.id} style={{
                  display: 'flex', alignItems: 'flex-start', gap: 8,
                  padding: '7px 0', borderBottom: '1px solid var(--bd)',
                }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 2 }}>
                      <span className={`bdg ${b.ok ? 'b-s' : 'b-r'}`}>{b.trigger}</span>
                      <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8, color: 'var(--t3)' }}>
                        {new Date(b.ts).toLocaleString('en-IN')}
                      </span>
                    </div>
                    <div style={{
                      fontFamily: "'IBM Plex Mono', monospace", fontSize: 8.5,
                      color: 'var(--blue)', wordBreak: 'break-all', lineHeight: 1.5,
                    }}>{b.blob_path}</div>
                  </div>
                  <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8, color: 'var(--t3)' }}>
                    {b.size_bytes ? Math.round(b.size_bytes / 1024) + ' KB' : ''}
                  </div>
                </div>
              ))}
              {backups.length === 0 && (
                <div style={{ textAlign: 'center', padding: 20, color: 'var(--t3)', fontFamily: "'IBM Plex Mono', monospace", fontSize: 10 }}>
                  No backups yet. Click Backup Now to create one.
                </div>
              )}
            </div>
          </div>
        </>
      )}

      {tab === 'auth' && (
        <div className="card">
          <div className="card-head"><span className="card-title">JWT Auth Flow</span></div>
          <div className="card-body">
            {[
              ['Login', 'POST /auth/login · bcrypt r=12 · JWT 8h + refresh 30d'],
              ['Guard', 'requireRole(...) middleware on every route · 403 if mismatch'],
              ['Brute Force', '5 failed attempts → 15-min IP lock · rate-limit 10/min on /auth'],
              ['Key Vault', 'JWT_SECRET via Azure Managed Identity, never in code'],
              ['Token Rotation', 'Refresh token rotated on every /auth/refresh call'],
              ['Audit Log', 'Every login/logout recorded in audit_log table'],
            ].map(([l, d]) => (
              <div key={l} style={{
                marginBottom: 9, paddingBottom: 9, borderBottom: '1px solid var(--bd)',
              }}>
                <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, color: 'var(--gold)', marginBottom: 2 }}>{l}</div>
                <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8.5, color: 'var(--t2)', lineHeight: 1.7 }}>{d}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'compliance' && [
        ['GST Act 2017 / e-Invoice 2024', 'var(--sage)',
          'IRN via IRP API (einvoice1.gst.gov.in). e-Way Bill for consignments > ₹50K. GSTR-1 by 11th, GSTR-3B by 20th. HSN 2516. ITC @12%.'],
        ['MSMED Act 2006', 'var(--gold)',
          'MSME vendors: payment within 45 days. 3× bank rate interest if delayed. Flag visible on vendor master.'],
        ['IT Act 2000', 'var(--blue)',
          'Immutable audit trail in audit_log table. SQLite WAL is append-only. Azure Blob 7-year immutable retention.'],
        ['IndAS 2 / IndAS 115', 'var(--rust)',
          'Double-entry journal. FIFO inventory (IndAS 2). Revenue recognised on delivery per IndAS 115.'],
      ].map(([t, c, d]) => (
        <div key={t} style={{
          borderLeft: `3px solid ${c}`, padding: '11px 14px',
          marginBottom: 10, borderRadius: '0 4px 4px 0',
        }}>
          <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 11, fontWeight: 700, color: c, marginBottom: 5 }}>{t}</div>
          <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9.5, lineHeight: 1.7, color: 'var(--t2)' }}>{d}</div>
        </div>
      ))}

      {tab === 'stack' && [
        ['Backend', 'Node.js 20 LTS · Express 5 · better-sqlite3 · WAL mode · jsonwebtoken · bcrypt r=12 · node-cron · @azure/storage-blob · helmet · express-rate-limit · Zod'],
        ['Frontend', 'React 18 · Vite 5 · React Router 6 · CSS Variables Theming · Day/Night Toggle · WCAG 2.2 AA · Responsive'],
        ['SQLite', 'WAL journal · PRAGMA foreign_keys ON · PRAGMA synchronous=NORMAL · Audit triggers · FIFO · Numbered migrations · 64MB cache'],
        ['Azure PaaS', 'App Service B2 · Blob Storage (LRS) · Key Vault · Application Insights · India South · Front Door (WAF)'],
      ].map(([t, d]) => (
        <div key={t} className="card">
          <div className="card-head"><span className="card-title">{t}</span></div>
          <div style={{ padding: '10px 13px', display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {d.split(' · ').map(p => (
              <span key={p} style={{
                fontFamily: "'IBM Plex Mono', monospace", fontSize: 9,
                color: 'var(--t2)', border: '1px solid var(--bd)',
                background: 'rgba(128,128,128,.07)', padding: '3px 8px', borderRadius: 3,
              }}>{p}</span>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
