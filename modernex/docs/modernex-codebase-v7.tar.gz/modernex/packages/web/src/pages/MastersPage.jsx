import { useEffect, useState } from 'react';
import { api } from '../utils/api.js';
import { useToast } from '../contexts/ToastContext.jsx';
import { fmtINR } from '../utils/format.js';

const STATES = ['Tamil Nadu', 'Karnataka', 'Andhra Pradesh', 'Kerala', 'Telangana',
  'Maharashtra', 'Gujarat', 'Delhi'];

export function MastersPage() {
  const { notify } = useToast();
  const [tab, setTab] = useState('customers');
  const [customers, setCustomers] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    name: '', gstin: '', state: 'Tamil Nadu', contact: '', email: '',
    credit_days: '0', type: 'Quarry', msme: false,
  });

  const load = () => {
    api.get('/customers').then(d => setCustomers(d.customers || []));
    api.get('/vendors').then(d => setVendors(d.vendors || []));
  };
  useEffect(() => { load(); }, []);

  const upd = k => v => setForm(f => ({ ...f, [k]: v }));

  async function save() {
    if (!form.name) { notify('Name required', true); return; }
    try {
      if (tab === 'customers') {
        await api.post('/customers', {
          name: form.name,
          gstin: form.gstin || undefined,
          state: form.state,
          contact: form.contact || undefined,
          email: form.email || undefined,
          credit_days: +form.credit_days || 0,
        });
      } else {
        await api.post('/vendors', {
          name: form.name,
          gstin: form.gstin || undefined,
          state: form.state,
          contact: form.contact || undefined,
          type: form.type,
          msme: form.msme,
        });
      }
      notify(`${form.name} added`);
      setModalOpen(false);
      setForm({ name: '', gstin: '', state: 'Tamil Nadu', contact: '', email: '',
        credit_days: '0', type: 'Quarry', msme: false });
      load();
    } catch (err) {
      notify(err.message || 'Failed to save', true);
    }
  }

  return (
    <div className="pw">
      <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
        <div>
          <div className="ph-title">Masters</div>
          <div className="ph-sub">Customers · Vendors</div>
        </div>
        <button className="btn btn-p btn-sm" onClick={() => setModalOpen(true)}>
          + Add {tab === 'customers' ? 'Customer' : 'Vendor'}
        </button>
      </div>

      <div className="itabs">
        <div className={`itab${tab === 'customers' ? ' on' : ''}`} onClick={() => setTab('customers')}>Customers</div>
        <div className={`itab${tab === 'vendors' ? ' on' : ''}`} onClick={() => setTab('vendors')}>Vendors</div>
        <div className={`itab${tab === 'kinds' ? ' on' : ''}`} onClick={() => setTab('kinds')}>Product Kinds</div>
        <div className={`itab${tab === 'specs' ? ' on' : ''}`} onClick={() => setTab('specs')}>Standard Specs</div>
      </div>

      {tab === 'kinds' && <KindDefaultsPanel />}
      {tab === 'specs' && <StandardSpecsPanel />}

      {tab === 'customers' && (
        <div className="tw">
          <table className="dt">
            <thead><tr>
              <th>ID</th><th>Name</th><th>GSTIN</th><th>State</th>
              <th>Credit</th><th className="r">Outstanding</th>
            </tr></thead>
            <tbody>
              {customers.map(c => (
                <tr key={c.id}>
                  <td className="tdm">{c.id}</td>
                  <td className="tdc">{c.name}</td>
                  <td className="tdm">{c.gstin || '—'}</td>
                  <td>{c.state}</td>
                  <td className="tdm">{c.credit_days}d</td>
                  <td className="tda" style={{ color: c.outstanding_paise > 0 ? 'var(--rust)' : 'var(--t3)' }}>
                    {c.outstanding_paise > 0 ? fmtINR(c.outstanding_paise) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'vendors' && (
        <div className="tw">
          <table className="dt">
            <thead><tr>
              <th>ID</th><th>Name</th><th>Type</th><th>GSTIN</th><th>State</th><th>Contact</th>
            </tr></thead>
            <tbody>
              {vendors.map(v => (
                <tr key={v.id}>
                  <td className="tdm">{v.id}</td>
                  <td className="tdc">
                    {v.name}
                    {v.msme === 1 && <span className="bdg b-b" style={{ marginLeft: 5, fontSize: 7 }}>MSME</span>}
                  </td>
                  <td><span className="bdg b-d">{v.type}</span></td>
                  <td className="tdm">{v.gstin || '—'}</td>
                  <td>{v.state}</td>
                  <td className="tdm">{v.contact || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,.78)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          zIndex: 100, padding: 14,
        }} onClick={e => e.target === e.currentTarget && setModalOpen(false)}>
          <div style={{
            background: 'var(--bg2)', border: '1px solid rgba(128,128,128,.15)',
            borderRadius: 10, width: '100%', maxWidth: 380,
          }}>
            <div style={{
              padding: '13px 16px', borderBottom: '1px solid var(--bd)',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: 'var(--t1)' }}>
                Add {tab === 'customers' ? 'Customer' : 'Vendor'}
              </span>
              <button onClick={() => setModalOpen(false)}
                style={{ color: 'var(--t3)', fontSize: 15 }}>✕</button>
            </div>
            <div style={{ padding: '14px 16px' }}>
              <div className="fg">
                <label className="fl">Name *</label>
                <input className="fi" value={form.name}
                  onChange={e => upd('name')(e.target.value)}
                  placeholder="Full legal name" />
              </div>
              <div className="fg">
                <label className="fl">GSTIN</label>
                <input className="fi" value={form.gstin} maxLength={15}
                  onChange={e => upd('gstin')(e.target.value.toUpperCase())}
                  placeholder="33AAAAA0000A1Z5" />
              </div>
              <div className="fg2">
                <div className="fg" style={{ marginBottom: 0 }}>
                  <label className="fl">State</label>
                  <select className="fsel" value={form.state}
                    onChange={e => upd('state')(e.target.value)}>
                    {STATES.map(s => <option key={s}>{s}</option>)}
                  </select>
                </div>
                {tab === 'customers' ? (
                  <div className="fg" style={{ marginBottom: 0 }}>
                    <label className="fl">Credit Days</label>
                    <input className="fi" type="number" min={0}
                      value={form.credit_days}
                      onChange={e => upd('credit_days')(e.target.value)} />
                  </div>
                ) : (
                  <div className="fg" style={{ marginBottom: 0 }}>
                    <label className="fl">Type</label>
                    <select className="fsel" value={form.type}
                      onChange={e => upd('type')(e.target.value)}>
                      {['Quarry', 'Broker', 'Transporter', 'Other'].map(t => <option key={t}>{t}</option>)}
                    </select>
                  </div>
                )}
              </div>
              {tab === 'vendors' && (
                <>
                  <div className="fg" style={{ marginTop: 11 }}>
                    <label className="fl">Contact</label>
                    <input className="fi" type="tel" placeholder="9876543210"
                      value={form.contact} onChange={e => upd('contact')(e.target.value)} />
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 4 }}>
                    <input id="msme" type="checkbox" checked={form.msme}
                      onChange={e => upd('msme')(e.target.checked)}
                      style={{ accentColor: 'var(--rust)' }} />
                    <label htmlFor="msme" style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, color: 'var(--t2)' }}>
                      MSME vendor — 45-day payment rule
                    </label>
                  </div>
                </>
              )}
            </div>
            <div style={{ padding: '11px 16px', borderTop: '1px solid var(--bd)',
              display: 'flex', justifyContent: 'flex-end', gap: 7 }}>
              <button className="btn btn-s" onClick={() => setModalOpen(false)}>Cancel</button>
              <button className="btn btn-p" onClick={save}>Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Kind Defaults Panel — shows reference data for all 10 product kinds ───
function KindDefaultsPanel() {
  const KINDS = [
    { kind: 'block',    label: 'Block',        uom: 'CFT',    hsn: '2515', gst: '12%',  grade: 'No',  desc: 'Raw/rough-sawn block from quarry' },
    { kind: 'slab',     label: 'Slab',         uom: 'sqft',   hsn: '2516', gst: '12%',  grade: 'Yes', desc: 'Cut and polished slab — 18/20/30/40mm' },
    { kind: 'tile',     label: 'Tile',         uom: 'piece',  hsn: '2516', gst: '12%',  grade: 'Yes', desc: 'Floor/wall tiles — 300×300 to 800×800' },
    { kind: 'cts',      label: 'Cut-to-Size',  uom: 'sqft',   hsn: '2516', gst: '12%',  grade: 'Yes', desc: 'Custom countertops, vanity tops' },
    { kind: 'strip',    label: 'Strip',        uom: 'rft',    hsn: '2516', gst: '12%',  grade: 'Yes', desc: 'Skirting, stair risers, borders' },
    { kind: 'kerb',     label: 'Kerb Stone',   uom: 'piece',  hsn: '2516', gst: '12%',  grade: 'No',  desc: 'Road kerbs — CC-Type-1, bull-nose, etc.' },
    { kind: 'cobble',   label: 'Cobblestone',  uom: 'piece',  hsn: '2516', gst: '12%',  grade: 'No',  desc: 'Setts, Belgian blocks, paving cobbles' },
    { kind: 'chips',    label: 'Chips',        uom: 'tonne',  hsn: '2517', gst: '5%',   grade: 'No',  desc: 'Crushed waste for terrazzo, flooring' },
    { kind: 'dust',     label: 'Dust',         uom: 'tonne',  hsn: '2517', gst: '5%',   grade: 'No',  desc: 'Quarry byproduct — fillers, compound' },
    { kind: 'monument', label: 'Monument',     uom: 'piece',  hsn: '2516', gst: '12%',  grade: 'No',  desc: 'Markers, headstones, ledgers (110mm etc.)' },
  ];

  return (
    <div>
      <div style={{ fontSize: 10, color: 'var(--t3)', padding: '4px 2px 10px', fontFamily: "'IBM Plex Mono', monospace" }}>
        Reference defaults. Each product you create picks up the HSN and UOM from its kind. Standard specs (sizes, thicknesses, monument types) are pickable in the create form.
      </div>
      <div className="tw">
        <table className="dt">
          <thead><tr>
            <th>Kind</th><th>Label</th><th>UOM</th><th>HSN</th><th>GST Rate</th><th>Needs Grade</th><th>Description</th>
          </tr></thead>
          <tbody>
            {KINDS.map(k => (
              <tr key={k.kind}>
                <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9 }}>{k.kind}</td>
                <td style={{ fontSize: 11, fontWeight: 600 }}>{k.label}</td>
                <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9 }}>{k.uom}</td>
                <td><span className="bdg b-d">{k.hsn}</span></td>
                <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: k.gst === '5%' ? 'var(--sage)' : 'var(--gold)' }}>{k.gst}</td>
                <td>{k.grade}</td>
                <td style={{ fontSize: 9, color: 'var(--t2)' }}>{k.desc}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Standard Specs Panel — industry-standard dimensions for each kind ───
function StandardSpecsPanel() {
  return (
    <div>
      <div style={{ fontSize: 10, color: 'var(--t3)', padding: '4px 2px 10px', fontFamily: "'IBM Plex Mono', monospace" }}>
        Industry-standard specifications available as picklists in the create form. Custom dimensions always allowed.
      </div>

      <SpecCard title="Slabs" subtitle="Standard thicknesses + sizes">
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
          <SpecBlock label="Thicknesses" items={[
            { k: '18 mm', v: 'Domestic floor/wall (India)' },
            { k: '20 mm', v: 'Standard export, countertops' },
            { k: '30 mm', v: 'Premium US/EU countertops' },
            { k: '40 mm', v: 'Heavy-duty paving' },
          ]} />
          <SpecBlock label="Gang-sawn Sizes" items={[
            { k: '2600×1600', v: 'Standard' },
            { k: '2700×1800', v: 'Large' },
            { k: '3000×1800', v: 'Export jumbo' },
            { k: '3000×2000', v: 'XL export' },
          ]} />
        </div>
      </SpecCard>

      <SpecCard title="Tiles" subtitle="Standard sizes × thicknesses">
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
          <SpecBlock label="Sizes" items={[
            { k: '300×300', v: "12″×12″ (1′×1′) — bathroom floors" },
            { k: '400×400', v: '16″×16″ — domestic (India)' },
            { k: '600×300', v: "24″×12″ (2′×1′) — bathroom walls" },
            { k: '600×600', v: "24″×24″ (2′×2′) — most common" },
            { k: '800×800', v: '32″×32″ — premium' },
            { k: '305×305', v: '12″ (US export precise)' },
          ]} />
          <SpecBlock label="Thicknesses" items={[
            { k: '10 mm', v: '' }, { k: '12 mm', v: '' },
            { k: '15 mm', v: '' }, { k: '18 mm', v: '' }, { k: '20 mm', v: '' },
          ]} />
        </div>
      </SpecCard>

      <SpecCard title="Cobblestones / Setts" subtitle="European standard paving">
        <SpecBlock label="Types" items={[
          { k: 'Small cobble',   v: '100×100×50mm · Driveways, pedestrian' },
          { k: 'Cube sett',      v: '100×100×100mm · Squares, plazas' },
          { k: 'Standard sett',  v: '200×100×100mm · Roads, heavy paving' },
          { k: 'Paving cobble',  v: '100×200×50mm · Garden paths' },
          { k: 'Random split',   v: 'varies · Rustic decorative' },
        ]} />
      </SpecCard>

      <SpecCard title="Kerb Stones" subtitle="Standard road kerb profiles">
        <SpecBlock label="Profiles" items={[
          { k: 'CC Type-1',   v: '900×150×300mm straight' },
          { k: 'CC Type-2',   v: '900×150×300mm half-battered' },
          { k: 'HB-450',      v: '900×150×450mm half-batter' },
          { k: 'Bull-nose',   v: '900×125×250mm rounded edge' },
          { k: 'Dropper',     v: '900×150×180mm transitions' },
        ]} />
      </SpecCard>

      <SpecCard title="Monuments" subtitle="Industry-standard memorial specifications (export-quality)">
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
          <SpecBlock label="Flat Markers" items={[
            { k: "24″×12″×4″",  v: '610×305×100mm (US standard)' },
            { k: "36″×12″×4″",  v: '915×305×100mm (US large)' },
            { k: 'Ledger 110mm', v: '1830×760×110mm (UK graveyard)' },
          ]} />
          <SpecBlock label="Bevel / Slant" items={[
            { k: 'Bevel 24″×14″', v: '610×355×100mm' },
            { k: 'Bevel 36″×14″', v: '915×355×100mm' },
            { k: 'Slant 24″×20″', v: '610×510×200mm' },
            { k: 'Slant 36″×20″', v: '915×510×200mm' },
          ]} />
          <SpecBlock label="Upright + Base" items={[
            { k: "Upright 24″×24″", v: '610×610×150mm' },
            { k: "Upright 36″×24″", v: '915×610×150mm' },
            { k: "Upright 48″×24″", v: '1220×610×150mm' },
            { k: "Base 36″×12″",    v: '915×305×100mm' },
            { k: "Base 48″×14″",    v: '1220×355×150mm' },
          ]} />
          <SpecBlock label="Other" items={[
            { k: "Columbarium 12″×12″", v: '305×305×25mm' },
            { k: "Columbarium 12″×24″", v: '610×305×25mm' },
            { k: "Mausoleum 3′×8′",     v: '2440×915×100mm' },
          ]} />
        </div>
        <div style={{ fontSize: 9, color: 'var(--t3)', marginTop: 8, fontFamily: "'IBM Plex Mono', monospace" }}>
          Common varieties for monument work: Absolute Black, Imperial Red, Paradiso Classic, Kashmir White, Bahama Blue
        </div>
      </SpecCard>
    </div>
  );
}

function SpecCard({ title, subtitle, children }) {
  return (
    <div style={{ border: '1px solid var(--bd)', borderRadius: 6, padding: 12, marginBottom: 10, background: 'var(--bg2)' }}>
      <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 12, fontWeight: 700, color: 'var(--rust)' }}>{title}</div>
      <div style={{ fontSize: 8.5, color: 'var(--t3)', marginBottom: 8, fontFamily: "'IBM Plex Mono', monospace" }}>{subtitle}</div>
      {children}
    </div>
  );
}

function SpecBlock({ label, items }) {
  return (
    <div style={{ flex: '1 1 280px', minWidth: 200 }}>
      <div style={{ fontSize: 8, color: 'var(--t3)', textTransform: 'uppercase', letterSpacing: 1.2, marginBottom: 4, fontFamily: "'IBM Plex Mono', monospace" }}>{label}</div>
      {items.map(it => (
        <div key={it.k} style={{ padding: '3px 0', borderBottom: '1px solid var(--bd)', display: 'flex', gap: 8 }}>
          <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: 'var(--t1)', minWidth: 110 }}>{it.k}</span>
          {it.v && <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, color: 'var(--t3)' }}>{it.v}</span>}
        </div>
      ))}
    </div>
  );
}
