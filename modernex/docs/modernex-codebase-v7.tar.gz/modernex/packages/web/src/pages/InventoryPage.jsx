import { useEffect, useMemo, useState } from 'react';
import { api } from '../utils/api.js';
import { useToast } from '../contexts/ToastContext.jsx';
import { useAuth } from '../contexts/AuthContext.jsx';
import { fmtINR } from '../utils/format.js';
import { useVarietyDefaults, resolveProductPhoto } from '../utils/varietyDefaults.js';

const KIND_CONFIG = {
  block:    { label: 'Blocks',     uom: 'CFT',   hsn: '2515', color: 'var(--gold)', needsGrade: false,
              fields: ['length_m', 'width_m', 'height_m', 'source_quarry'] },
  slab:     { label: 'Slabs',      uom: 'sqft',  hsn: '2516', color: 'var(--rust)', needsGrade: true,
              fields: ['size_lw', 'thickness_mm', 'sqft'] },
  tile:     { label: 'Tiles',      uom: 'pc',    hsn: '2516', color: 'var(--blue)', needsGrade: true,
              fields: ['size_lw', 'thickness_mm', 'sqft_per_tile', 'pieces_per_box'] },
  cts:      { label: 'Cut-to-Size',uom: 'sqft',  hsn: '2516', color: 'var(--sage)', needsGrade: true,
              fields: ['customer_spec', 'length_mm', 'width_mm', 'thickness_mm'] },
  strip:    { label: 'Strips',     uom: 'rft',   hsn: '2516', color: 'var(--sage)', needsGrade: true,
              fields: ['length_mm', 'width_mm', 'thickness_mm'] },
  kerb:     { label: 'Kerbs',      uom: 'pc',    hsn: '2516', color: 'var(--blue)', needsGrade: false,
              fields: ['profile', 'length_mm', 'height_mm', 'width_mm'] },
  cobble:   { label: 'Cobbles',    uom: 'pc',    hsn: '2516', color: 'var(--blue)', needsGrade: false,
              fields: ['cobble_type', 'length_mm', 'width_mm', 'height_mm'] },
  chips:    { label: 'Chips',      uom: 'tonne', hsn: '2517', color: 'var(--gold)', needsGrade: false,
              fields: ['mesh_size_mm', 'bulk_density'] },
  dust:     { label: 'Dust',       uom: 'tonne', hsn: '2517', color: 'var(--gold)', needsGrade: false,
              fields: [] },
  monument: { label: 'Monuments',  uom: 'pc',    hsn: '2516', color: 'var(--rust)', needsGrade: false,
              fields: ['monument_type', 'length_mm', 'width_mm', 'thickness_mm'] },
};
const KIND_ORDER = ['block', 'slab', 'tile', 'cts', 'strip', 'kerb', 'cobble', 'chips', 'dust', 'monument'];

// Industry-standard specs — populated into picklists
const STANDARD_SPECS = {
  slab: {
    thicknesses: [18, 20, 30, 40],
    sizes: ['2600×1600', '2700×1800', '3000×1800', '3000×2000'],
  },
  tile: {
    thicknesses: [10, 12, 15, 18, 20],
    sizes: ['300×300', '400×400', '600×300', '600×600', '800×800', '305×305'],
    boxCounts: { '300×300': 10, '400×400': 8, '600×300': 8, '600×600': 4, '800×800': 2, '305×305': 10 },
  },
  cts: {
    thicknesses: [20, 30, 40],
  },
  cobble: {
    types: [
      { key: 'small',    label: 'Small cobble 100×100×50mm',   l: 100, w: 100, h: 50 },
      { key: 'cube',     label: 'Cube sett 100×100×100mm',     l: 100, w: 100, h: 100 },
      { key: 'standard', label: 'Standard sett 200×100×100mm', l: 200, w: 100, h: 100 },
      { key: 'paving',   label: 'Paving cobble 100×200×50mm',  l: 100, w: 200, h: 50 },
      { key: 'random',   label: 'Random split (rustic)',       l: 0,   w: 0,   h: 50 },
    ],
  },
  kerb: {
    profiles: [
      { key: 'CC-Type-1', label: 'CC Type-1 straight',     l: 900, w: 150, h: 300 },
      { key: 'CC-Type-2', label: 'CC Type-2 half-batter',  l: 900, w: 150, h: 300 },
      { key: 'HB-450',    label: 'Half-batter 450mm',       l: 900, w: 150, h: 450 },
      { key: 'BullNose',  label: 'Bull-nose edge',          l: 900, w: 125, h: 250 },
      { key: 'Dropper',   label: 'Dropper kerb',            l: 900, w: 150, h: 180 },
    ],
  },
  monument: {
    thicknesses: [50, 75, 100, 110, 150, 200],
    types: [
      { key: 'flat_marker_24x12',  label: 'Flat marker 24″×12″×4″',   l: 610,  w: 305, t: 100 },
      { key: 'flat_marker_36x12',  label: 'Flat marker 36″×12″×4″',   l: 915,  w: 305, t: 100 },
      { key: 'ledger_110',         label: 'Ledger stone 110mm',        l: 1830, w: 760, t: 110 },
      { key: 'bevel_24x14',        label: 'Bevel marker 24″×14″',      l: 610,  w: 355, t: 100 },
      { key: 'bevel_36x14',        label: 'Bevel marker 36″×14″',      l: 915,  w: 355, t: 100 },
      { key: 'slant_24x20',        label: 'Slant memorial 24″×20″',    l: 610,  w: 510, t: 200 },
      { key: 'slant_36x20',        label: 'Slant memorial 36″×20″',    l: 915,  w: 510, t: 200 },
      { key: 'upright_24x24',      label: 'Upright die 24″×24″',       l: 610,  w: 610, t: 150 },
      { key: 'upright_36x24',      label: 'Upright die 36″×24″',       l: 915,  w: 610, t: 150 },
      { key: 'upright_48x24',      label: 'Upright die 48″×24″',       l: 1220, w: 610, t: 150 },
      { key: 'base_36x12',         label: 'Base 36″×12″',              l: 915,  w: 305, t: 100 },
      { key: 'base_48x14',         label: 'Base 48″×14″',              l: 1220, w: 355, t: 150 },
      { key: 'columbarium_12x12',  label: 'Columbarium 12″×12″',       l: 305,  w: 305, t: 25 },
      { key: 'columbarium_12x24',  label: 'Columbarium 12″×24″',       l: 610,  w: 305, t: 25 },
      { key: 'mausoleum_3x8',      label: 'Mausoleum slab 3′×8′',      l: 2440, w: 915, t: 100 },
    ],
  },
};

const FIELD_META = {
  length_m:        { label: 'Length (m)',       type: 'number', step: 0.01 },
  width_m:         { label: 'Width (m)',        type: 'number', step: 0.01 },
  height_m:        { label: 'Height (m)',       type: 'number', step: 0.01 },
  source_quarry:   { label: 'Source Quarry',    type: 'text' },
  size_lw:         { label: 'Size L×W (mm)',    type: 'picklist', placeholder: '2600×1600' },
  thickness_mm:    { label: 'Thickness (mm)',   type: 'picklist_numeric' },
  sqft:            { label: 'Sqft (per piece)', type: 'number', step: 0.01 },
  sqft_per_tile:   { label: 'Sqft per Tile',    type: 'number', step: 0.01 },
  pieces_per_box:  { label: 'Pieces per Box',   type: 'number', step: 1 },
  customer_spec:   { label: 'Customer Spec',    type: 'text' },
  length_mm:       { label: 'Length (mm)',      type: 'number', step: 1 },
  width_mm:        { label: 'Width (mm)',       type: 'number', step: 1 },
  profile:         { label: 'Profile',          type: 'picklist_kerb' },
  height_mm:       { label: 'Height (mm)',      type: 'number', step: 1 },
  cobble_type:     { label: 'Cobble Type',      type: 'picklist_cobble' },
  monument_type:   { label: 'Monument Type',    type: 'picklist_monument' },
  mesh_size_mm:    { label: 'Mesh Size (mm)',   type: 'number', step: 0.5 },
  bulk_density:    { label: 'Bulk Density',     type: 'number', step: 1 },
  spec_notes:      { label: 'Specification Notes', type: 'textarea' },
};

export function InventoryPage() {
  const { user } = useAuth();
  const { notify } = useToast();
  const [products, setProducts] = useState([]);
  const [summary, setSummary] = useState(null);
  const [q, setQ] = useState('');
  const [kindFilter, setKindFilter] = useState('All');
  const [variety, setVariety] = useState('All');
  const [grade, setGrade] = useState('All');
  const [modal, setModal] = useState(null);
  const [editing, setEditing] = useState(null);
  const [bulkOpen, setBulkOpen] = useState(false);
  const { map: varietyMap } = useVarietyDefaults();

  const canEdit = user?.role === 'admin' || user?.role === 'yard';

  const load = () => {
    api.get('/products?active=true').then(d => setProducts(d.products || []));
    api.get('/products/stats/summary').then(d => setSummary(d));
  };
  useEffect(load, []);

  const availableKinds = useMemo(() => {
    const set = new Set(products.map(p => p.kind));
    return KIND_ORDER.filter(k => set.has(k));
  }, [products]);

  const varieties = useMemo(() => {
    const set = new Set(products.map(p => p.variety));
    return ['All', ...Array.from(set).sort()];
  }, [products]);

  const filtered = useMemo(() => products.filter(p => {
    if (kindFilter !== 'All' && p.kind !== kindFilter) return false;
    if (variety !== 'All' && p.variety !== variety) return false;
    if (grade !== 'All' && p.grade !== grade) return false;
    if (q) {
      const qx = q.toLowerCase();
      if (!(p.variety?.toLowerCase().includes(qx) ||
            p.id?.toLowerCase().includes(qx) ||
            p.lot_id?.toLowerCase().includes(qx))) return false;
    }
    return true;
  }), [products, kindFilter, variety, grade, q]);

  const openNew = () => { setEditing(null); setModal('new'); };
  const openEdit = (p) => { setEditing(p); setModal('edit'); };

  const printLabels = () => {
    if (!filtered.length) return;
    const ids = filtered.map(p => p.id).join(',');
    window.open(`/api/qr/product-labels?ids=${ids}`, '_blank');
  };

  return (
    <div className="pw">
      <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8, alignItems: 'flex-start' }}>
        <div>
          <div className="ph-title">Inventory</div>
          <div className="ph-sub">All product kinds · Multi-HSN · FIFO</div>
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          <button className="btn btn-s btn-sm" onClick={printLabels} disabled={!filtered.length}>
            🏷 Print QR Labels ({filtered.length})
          </button>
          {user?.role === 'admin' && (
            <button className="btn btn-s btn-sm" onClick={() => setBulkOpen(true)}>
              ⚡ Bulk Rate Update
            </button>
          )}
          {canEdit && (
            <button className="btn btn-p btn-sm" onClick={openNew}>+ New Product</button>
          )}
        </div>
      </div>

      {/* Per-kind stats */}
      {summary?.byKind && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))',
                      gap: 8, margin: '12px 0' }}>
          {summary.byKind.map(k => (
            <div key={k.kind} style={{
              background: 'var(--bg2)', border: '1px solid var(--bd)',
              borderRadius: 5, padding: '8px 10px',
              borderLeft: `3px solid ${KIND_CONFIG[k.kind]?.color || 'var(--t3)'}`,
            }}>
              <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8,
                            color: 'var(--t3)', textTransform: 'uppercase', letterSpacing: 1 }}>
                {KIND_CONFIG[k.kind]?.label || k.kind}
              </div>
              <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 16,
                            fontWeight: 700, color: 'var(--t1)', marginTop: 2 }}>
                {k.products}
              </div>
              <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, color: 'var(--t2)', marginTop: 2 }}>
                {fmtINR(k.value_paise || 0)}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Filters */}
      <div style={{ display: 'flex', gap: 6, padding: '8px 0', flexWrap: 'wrap' }}>
        {['All', ...availableKinds].map(k => (
          <button key={k} type="button"
            onClick={() => setKindFilter(k)}
            className={kindFilter === k ? 'btn btn-p btn-sm' : 'btn btn-s btn-sm'}
            style={{ fontSize: 10 }}>
            {k === 'All' ? 'All' : KIND_CONFIG[k]?.label}
          </button>
        ))}
      </div>
      <div className="sbar">
        <input className="si" placeholder="Search variety, ID, lot…" value={q} onChange={e => setQ(e.target.value)} type="search" />
        <select className="sf" value={variety} onChange={e => setVariety(e.target.value)}>
          {varieties.map(v => <option key={v} value={v}>{v}</option>)}
        </select>
        <select className="sf" value={grade} onChange={e => setGrade(e.target.value)}>
          <option>All</option><option>A+</option><option>A</option><option>B</option>
        </select>
      </div>

      <div className="tw">
        <table className="dt">
          <thead>
            <tr>
              <th></th>
              <th>ID</th><th>Kind</th><th>Variety</th><th>Details</th>
              <th>Grade</th><th>Lot</th><th>Stock</th>
              <th style={{ textAlign: 'right' }}>Rate</th>
              <th style={{ textAlign: 'right' }}>Value</th>
              <th>HSN</th>
              {canEdit && <th></th>}
            </tr>
          </thead>
          <tbody>
            {filtered.map(p => {
              const cfg = KIND_CONFIG[p.kind] || {};
              const d = p.dimensions || {};
              const details = detailsFor(p);
              const value = Math.round(p.rate_paise * p.stock);
              const photoUrl = resolveProductPhoto(p, varietyMap);
              return (
                <tr key={p.id}>
                  <td style={{ width: 48, padding: 4 }}>
                    {photoUrl ? (
                      <img src={photoUrl} alt={p.variety}
                        style={{ width: 40, height: 32, objectFit: 'cover', borderRadius: 3,
                                 background: 'var(--bg3)', display: 'block' }}
                        onError={e => { e.currentTarget.style.display = 'none'; }} />
                    ) : (
                      <div style={{ width: 40, height: 32, background: 'var(--bg3)', borderRadius: 3,
                                    border: '1px dashed var(--bd)' }} />
                    )}
                  </td>
                  <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9 }}>{p.id}</td>
                  <td><span className="bdg" style={{ background: cfg.color + '20', color: cfg.color, border: `1px solid ${cfg.color}60` }}>
                    {cfg.label || p.kind}
                  </span></td>
                  <td style={{ fontSize: 11, fontWeight: 600 }}>{p.variety}</td>
                  <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, color: 'var(--t2)' }}>{details}</td>
                  <td>{p.grade && <span className="bdg" style={{
                    color: `var(--${p.grade === 'A+' ? 'gold' : p.grade === 'A' ? 'sage' : 'blue'})`,
                  }}>{p.grade}</span>}</td>
                  <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9 }}>{p.lot_id || '—'}</td>
                  <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10,
                    color: p.stock <= 2 ? 'var(--rust)' : p.stock <= 5 ? 'var(--gold)' : 'var(--sage)' }}>
                    {p.stock} {cfg.uom === 'tonne' ? 'MT' : 'pc'}
                  </td>
                  <td style={{ textAlign: 'right', fontFamily: "'IBM Plex Mono', monospace", fontSize: 10 }}>
                    ₹{(p.rate_paise / 100).toFixed(0)}/{cfg.uom}
                  </td>
                  <td style={{ textAlign: 'right', fontFamily: "'IBM Plex Mono', monospace", fontSize: 10 }}>
                    {fmtINR(value)}
                  </td>
                  <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, color: 'var(--t3)' }}>{p.hsn}</td>
                  {canEdit && (
                    <td style={{ display: 'flex', gap: 3 }}>
                      <button className="btn btn-s btn-sm" onClick={() => openEdit(p)}>Edit</button>
                    </td>
                  )}
                </tr>
              );
            })}
            {filtered.length === 0 && (
              <tr><td colSpan={canEdit ? 12 : 11} style={{
                textAlign: 'center', padding: 30, color: 'var(--t3)' }}>
                No products match
              </td></tr>
            )}
          </tbody>
        </table>
      </div>

      {modal && (
        <ProductEditModal
          product={editing}
          mode={modal}
          onClose={() => { setModal(null); setEditing(null); }}
          onSaved={() => { load(); setModal(null); setEditing(null); notify('Saved'); }}
          onError={msg => notify(msg, true)}
        />
      )}

      {bulkOpen && (
        <BulkRateModal onClose={() => setBulkOpen(false)}
          varieties={varieties.filter(v => v !== 'All')}
          onDone={() => { load(); setBulkOpen(false); }}
          onError={msg => notify(msg, true)} />
      )}
    </div>
  );
}

function detailsFor(p) {
  const d = p.dimensions || {};
  switch (p.kind) {
    case 'block': return `${d.length_m}×${d.width_m}×${d.height_m}m · ${d.cft?.toFixed(1) || '?'} CFT`;
    case 'slab':  return `${d.size_lw || ''}mm · ${d.thickness_mm || ''}mm · ${d.sqft?.toFixed(1) || ''}sqft`;
    case 'tile':  return `${d.size_lw || ''}mm · ${d.thickness_mm || ''}mm${d.pieces_per_box ? ' · ' + d.pieces_per_box + '/box' : ''}`;
    case 'cts':   return `${d.length_mm || ''}×${d.width_mm || ''}mm · ${d.sqft?.toFixed(1) || ''}sqft${d.customer_spec ? ' · ' + d.customer_spec.slice(0, 30) : ''}`;
    case 'strip': return `${d.length_mm || ''}×${d.width_mm || ''}mm · ${d.rft_per_piece?.toFixed(2) || ''} rft/pc`;
    case 'kerb':  return `${d.profile || '—'} · ${d.length_mm || ''}mm`;
    case 'cobble': {
      const typeLabel = STANDARD_SPECS.cobble?.types.find(t => t.key === d.cobble_type)?.label || d.cobble_type || '—';
      return `${typeLabel.split(' ')[0]} · ${d.length_mm}×${d.width_mm}×${d.height_mm}mm`;
    }
    case 'chips': return `${d.mesh_size_mm || ''}mm mesh`;
    case 'dust':  return 'Quarry byproduct';
    case 'monument': {
      const typeLabel = STANDARD_SPECS.monument?.types.find(t => t.key === d.monument_type)?.label || d.monument_type || '—';
      return `${typeLabel} · ${d.thickness_mm || '—'}mm`;
    }
    default: return '';
  }
}

// ─── Product create/edit modal ───
// ─── Dimension field renderer — handles picklists for standard specs ───
function renderDimField(f, meta, kind, dims, updDim, setDims) {
  const val = dims[f] ?? '';

  // Size picklist (slab/tile) — also auto-fills pieces_per_box for tiles
  if (meta.type === 'picklist' && f === 'size_lw') {
    const sizes = STANDARD_SPECS[kind]?.sizes || [];
    return (
      <div key={f} className="fg" style={{ marginBottom: 6 }}>
        <label className="fl">{meta.label}</label>
        <div style={{ display: 'flex', gap: 4 }}>
          <select className="fsel" style={{ flex: 1 }}
            value={sizes.includes(val) ? val : '__custom'}
            onChange={e => {
              const v = e.target.value;
              if (v === '__custom') return;   // keep existing custom input
              setDims(d => {
                const updated = { ...d, size_lw: v };
                // Auto-fill pieces_per_box for known tile sizes
                if (kind === 'tile') {
                  const boxes = STANDARD_SPECS.tile.boxCounts?.[v];
                  if (boxes && !d.pieces_per_box) updated.pieces_per_box = boxes;
                }
                return updated;
              });
            }}>
            {sizes.map(s => <option key={s} value={s}>{s} mm</option>)}
            <option value="__custom">Custom…</option>
          </select>
          <input className="fi" style={{ flex: 1 }} type="text"
            placeholder={meta.placeholder}
            value={val}
            onChange={e => updDim(f, e.target.value)} />
        </div>
      </div>
    );
  }

  // Thickness picklist — standard thicknesses per kind
  if (meta.type === 'picklist_numeric' && f === 'thickness_mm') {
    const thicknesses = STANDARD_SPECS[kind]?.thicknesses || [];
    return (
      <div key={f} className="fg" style={{ marginBottom: 6 }}>
        <label className="fl">{meta.label}</label>
        <div style={{ display: 'flex', gap: 4 }}>
          <select className="fsel" style={{ flex: 1 }}
            value={thicknesses.includes(+val) ? val : '__custom'}
            onChange={e => {
              const v = e.target.value;
              if (v === '__custom') return;
              updDim(f, Number(v));
            }}>
            {thicknesses.map(t => <option key={t} value={t}>{t} mm</option>)}
            <option value="__custom">Custom…</option>
          </select>
          <input className="fi" style={{ flex: 1 }} type="number" step={1}
            value={val}
            onChange={e => updDim(f, Number(e.target.value))} />
        </div>
      </div>
    );
  }

  // Kerb profile picklist — also auto-fills L/W/H
  if (meta.type === 'picklist_kerb') {
    const profiles = STANDARD_SPECS.kerb?.profiles || [];
    return (
      <div key={f} className="fg" style={{ marginBottom: 6 }}>
        <label className="fl">{meta.label}</label>
        <select className="fsel" value={val}
          onChange={e => {
            const v = e.target.value;
            const spec = profiles.find(p => p.key === v);
            if (spec) {
              setDims(d => ({
                ...d, profile: v,
                length_mm: spec.l, width_mm: spec.w, height_mm: spec.h,
              }));
            } else {
              updDim(f, v);
            }
          }}>
          <option value="">— pick profile —</option>
          {profiles.map(p => <option key={p.key} value={p.key}>{p.label}</option>)}
          <option value="__custom">Custom…</option>
        </select>
      </div>
    );
  }

  // Cobble type picklist — auto-fills dimensions
  if (meta.type === 'picklist_cobble') {
    const types = STANDARD_SPECS.cobble?.types || [];
    return (
      <div key={f} className="fg" style={{ marginBottom: 6 }}>
        <label className="fl">{meta.label}</label>
        <select className="fsel" value={val}
          onChange={e => {
            const v = e.target.value;
            const spec = types.find(t => t.key === v);
            if (spec) {
              setDims(d => ({
                ...d, cobble_type: v,
                length_mm: spec.l || d.length_mm,
                width_mm: spec.w || d.width_mm,
                height_mm: spec.h,
              }));
            } else {
              updDim(f, v);
            }
          }}>
          <option value="">— pick cobble type —</option>
          {types.map(t => <option key={t.key} value={t.key}>{t.label}</option>)}
        </select>
      </div>
    );
  }

  // Monument type picklist — auto-fills L/W/thickness
  if (meta.type === 'picklist_monument') {
    const types = STANDARD_SPECS.monument?.types || [];
    return (
      <div key={f} className="fg" style={{ marginBottom: 6 }}>
        <label className="fl">{meta.label}</label>
        <select className="fsel" value={val}
          onChange={e => {
            const v = e.target.value;
            const spec = types.find(t => t.key === v);
            if (spec) {
              setDims(d => ({
                ...d, monument_type: v,
                length_mm: spec.l, width_mm: spec.w, thickness_mm: spec.t,
              }));
            } else {
              updDim(f, v);
            }
          }}>
          <option value="">— pick monument type —</option>
          {types.map(t => <option key={t.key} value={t.key}>{t.label}</option>)}
          <option value="__custom">Custom…</option>
        </select>
      </div>
    );
  }

  // Default — text / number / textarea
  if (meta.type === 'textarea') {
    return (
      <div key={f} className="fg" style={{ marginBottom: 6 }}>
        <label className="fl">{meta.label}</label>
        <textarea className="fi" value={val}
          onChange={e => updDim(f, e.target.value)} rows={2} />
      </div>
    );
  }
  return (
    <div key={f} className="fg" style={{ marginBottom: 6 }}>
      <label className="fl">{meta.label}</label>
      <input className="fi" type={meta.type} step={meta.step}
        placeholder={meta.placeholder}
        value={val}
        onChange={e => updDim(f, meta.type === 'number' ? Number(e.target.value) : e.target.value)} />
    </div>
  );
}

function ProductEditModal({ product, mode, onClose, onSaved, onError }) {
  const isEdit = mode === 'edit';
  const [kind, setKind] = useState(product?.kind || 'slab');
  const [variety, setVariety] = useState(product?.variety || '');
  const [g, setG] = useState(product?.grade || '');
  const [lotId, setLotId] = useState(product?.lot_id || '');
  const [rate, setRate] = useState(product ? (product.rate_paise / 100).toFixed(0) : '');
  const [stock, setStock] = useState(product?.stock ?? 0);
  const [notes, setNotes] = useState(product?.notes || '');
  const [dims, setDims] = useState(product?.dimensions || {});
  const [saving, setSaving] = useState(false);

  const cfg = KIND_CONFIG[kind] || {};

  const updDim = (key, val) => setDims(d => ({ ...d, [key]: val }));

  async function submit(e) {
    e.preventDefault();
    if (!variety) { onError('Variety required'); return; }
    if (!rate) { onError('Rate required'); return; }
    setSaving(true);
    try {
      const payload = {
        kind, variety,
        grade: g || null,
        lot_id: lotId || null,
        rate_paise: Math.round(Number(rate) * 100),
        stock: Number(stock),
        notes: notes || null,
        dimensions: normalizeDims(kind, dims),
      };
      if (isEdit) {
        delete payload.kind;   // immutable
        await api.patch(`/products/${product.id}`, payload);
      } else {
        await api.post('/products', payload);
      }
      onSaved();
    } catch (err) {
      onError(err.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Overlay title={isEdit ? `Edit ${product.id}` : 'New Product'} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="fg">
          <label className="fl">Kind *</label>
          <select className="fsel" value={kind}
            onChange={e => setKind(e.target.value)} disabled={isEdit}>
            {KIND_ORDER.map(k => (
              <option key={k} value={k}>{KIND_CONFIG[k].label} · {KIND_CONFIG[k].uom} · HSN {KIND_CONFIG[k].hsn}</option>
            ))}
          </select>
          {isEdit && (
            <div style={{ fontSize: 8, color: 'var(--t3)', marginTop: 2 }}>
              Kind is immutable — create a new product to change it.
            </div>
          )}
        </div>

        <div className="fg2">
          <div className="fg" style={{ marginBottom: 0 }}>
            <label className="fl">Variety *</label>
            <input className="fi" value={variety} onChange={e => setVariety(e.target.value)} required
              placeholder="e.g. Paradiso Classic" />
          </div>
          {cfg.needsGrade && (
            <div className="fg" style={{ marginBottom: 0 }}>
              <label className="fl">Grade</label>
              <select className="fsel" value={g} onChange={e => setG(e.target.value)}>
                <option value="">—</option><option>A+</option><option>A</option><option>B</option>
              </select>
            </div>
          )}
        </div>

        <div className="fg2">
          <div className="fg" style={{ marginBottom: 0 }}>
            <label className="fl">Rate (₹/{cfg.uom}) *</label>
            <input className="fi" type="number" min="0" step="0.01" value={rate}
              onChange={e => setRate(e.target.value)} required />
          </div>
          <div className="fg" style={{ marginBottom: 0 }}>
            <label className="fl">Stock ({cfg.uom === 'tonne' ? 'MT' : 'pc'})</label>
            <input className="fi" type="number" min="0" step="0.01" value={stock}
              onChange={e => setStock(e.target.value)} />
          </div>
        </div>

        <div className="fg">
          <label className="fl">Lot ID</label>
          <input className="fi" value={lotId} onChange={e => setLotId(e.target.value)} placeholder="LOT-030" />
        </div>

        {cfg.fields?.length > 0 && (
          <div style={{ margin: '10px 0 4px', padding: '8px 10px',
            background: 'var(--bg3)', borderRadius: 5, border: '1px solid var(--bd)' }}>
            <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8,
              letterSpacing: 1.2, textTransform: 'uppercase', color: 'var(--t3)',
              marginBottom: 6 }}>
              Dimensions ({cfg.label})
            </div>
            {cfg.fields.map(f => {
              const meta = FIELD_META[f] || { label: f, type: 'text' };
              return renderDimField(f, meta, kind, dims, updDim, setDims);
            })}
          </div>
        )}

        <div className="fg" style={{ marginTop: 10 }}>
          <label className="fl">Notes</label>
          <input className="fi" value={notes} onChange={e => setNotes(e.target.value)} maxLength={500} />
        </div>

        <div style={{ display: 'flex', gap: 7, marginTop: 14 }}>
          <button className="btn btn-p" type="submit" disabled={saving}>
            {saving ? 'Saving…' : (isEdit ? 'Save' : 'Create')}
          </button>
          <button className="btn btn-s" type="button" onClick={onClose}>Cancel</button>
        </div>
      </form>
    </Overlay>
  );
}

function normalizeDims(kind, dims) {
  const cfg = KIND_CONFIG[kind];
  if (!cfg) return {};
  const out = {};
  for (const f of cfg.fields) {
    const v = dims[f];
    if (v === '' || v == null) continue;
    out[f] = v;
  }
  return out;
}

// ─── Bulk rate update modal ───
function BulkRateModal({ onClose, varieties, onDone, onError }) {
  const [kind, setKind] = useState('');
  const [variety, setVariety] = useState('');
  const [grade, setGrade] = useState('');
  const [action, setAction] = useState('multiply');
  const [value, setValue] = useState(1.05);
  const [preview, setPreview] = useState(null);
  const [running, setRunning] = useState(false);

  async function runPreview() {
    setRunning(true);
    try {
      // Use the same endpoint — it's idempotent in "preview" sense since we
      // re-call with the same filter after an apply.
      // For true preview we'd need a dry-run flag; as a safe alternative,
      // we just go straight to apply with confirmation.
      setPreview({ ready: true });
    } finally {
      setRunning(false);
    }
  }

  async function apply() {
    if (!confirm(`Apply ${action} of ${value} to filtered products? This cannot be undone.`)) return;
    setRunning(true);
    try {
      const filter = {};
      if (kind) filter.kind = kind;
      if (variety) filter.variety = variety;
      if (grade) filter.grade = grade;
      const { updated } = await api.post('/products/bulk-rate', { filter, action, value: Number(value) });
      alert(`Updated ${updated} products.`);
      onDone();
    } catch (err) {
      onError(err.message || 'Bulk update failed');
    } finally {
      setRunning(false);
    }
  }

  return (
    <Overlay title="Bulk Rate Update" onClose={onClose}>
      <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, color: 'var(--t2)', marginBottom: 12 }}>
        Updates master rates on all matching products. Use empty filters to match everything.
      </div>
      <div className="fg">
        <label className="fl">Kind (optional)</label>
        <select className="fsel" value={kind} onChange={e => setKind(e.target.value)}>
          <option value="">All kinds</option>
          {KIND_ORDER.map(k => <option key={k} value={k}>{KIND_CONFIG[k].label}</option>)}
        </select>
      </div>
      <div className="fg">
        <label className="fl">Variety (optional)</label>
        <select className="fsel" value={variety} onChange={e => setVariety(e.target.value)}>
          <option value="">All varieties</option>
          {varieties.map(v => <option key={v} value={v}>{v}</option>)}
        </select>
      </div>
      <div className="fg">
        <label className="fl">Grade (optional)</label>
        <select className="fsel" value={grade} onChange={e => setGrade(e.target.value)}>
          <option value="">Any</option><option>A+</option><option>A</option><option>B</option>
        </select>
      </div>
      <div className="fg2">
        <div className="fg" style={{ marginBottom: 0 }}>
          <label className="fl">Action</label>
          <select className="fsel" value={action} onChange={e => setAction(e.target.value)}>
            <option value="set">Set to (₹)</option>
            <option value="add">Add (₹)</option>
            <option value="multiply">Multiply by</option>
          </select>
        </div>
        <div className="fg" style={{ marginBottom: 0 }}>
          <label className="fl">Value</label>
          <input className="fi" type="number" step="0.01" value={value}
            onChange={e => setValue(e.target.value)} />
        </div>
      </div>
      <div style={{ fontSize: 9, color: 'var(--t3)', padding: '6px 10px',
        background: 'var(--bg3)', borderRadius: 4, marginTop: 6 }}>
        Examples:{' '}
        <code>multiply × 1.05</code> = +5% rate increase.{' '}
        <code>add ₹10</code> = +₹10 to rate.{' '}
        <code>set ₹450</code> = fixed rate.
      </div>
      <div style={{ display: 'flex', gap: 7, marginTop: 14 }}>
        <button className="btn btn-p" type="button" onClick={apply} disabled={running}>
          {running ? 'Applying…' : 'Apply'}
        </button>
        <button className="btn btn-s" type="button" onClick={onClose}>Cancel</button>
      </div>
    </Overlay>
  );
}

function Overlay({ title, children, onClose }) {
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,.78)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 100, padding: 14, overflowY: 'auto',
    }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: 'var(--bg2)', border: '1px solid rgba(128,128,128,.15)',
        borderRadius: 10, width: '100%', maxWidth: 440,
      }}>
        <div style={{ padding: '13px 16px', borderBottom: '1px solid var(--bd)',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: 'var(--t1)' }}>{title}</span>
          <button onClick={onClose} style={{ color: 'var(--t3)', fontSize: 15 }}>✕</button>
        </div>
        <div style={{ padding: '14px 16px' }}>{children}</div>
      </div>
    </div>
  );
}
