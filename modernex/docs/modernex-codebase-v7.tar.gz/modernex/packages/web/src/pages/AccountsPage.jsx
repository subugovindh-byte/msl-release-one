import { useEffect, useState } from 'react';
import { api } from '../utils/api.js';
import { useToast } from '../contexts/ToastContext.jsx';
import { fmtINR, fmtINRCompact } from '../utils/format.js';
import { StatusBadge, StatCard } from '../components/Shared.jsx';

export function AccountsPage() {
  const { notify } = useToast();
  const [tab, setTab] = useState('ar');
  const [invoices, setInvoices] = useState([]);
  const [editInvoice, setEditInvoice] = useState(null);
  const [pos, setPos] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [payments, setPayments] = useState([]);
  const [summary, setSummary] = useState(null);

  const loadAll = () => {
    api.get('/invoices').then(d => setInvoices(d.invoices || []));
    api.get('/purchase').then(d => setPos(d.purchase_orders || []));
    api.get('/vendors').then(d => setVendors(d.vendors || []));
    api.get('/payments').then(d => setPayments(d.payments || []));
    api.get('/reports/dashboard').then(d => setSummary(d.summary));
  };
  useEffect(() => { loadAll(); }, []);

  const markPaid = async (id) => {
    try {
      await api.post(`/invoices/${id}/pay`, { mode: 'Manual' });
      notify(`${id} settled`);
      loadAll();
    } catch (err) {
      notify(err.message || 'Failed', true);
    }
  };

  const sendEmail = async (id) => {
    try {
      const r = await api.post(`/invoices/${id}/send-email`, {});
      notify(r.sent ? `${id} emailed` : `Skipped: ${r.reason}`, !r.sent);
    } catch (err) {
      notify(err.message || 'Email failed', true);
    }
  };

  const sendWhatsApp = async (id) => {
    try {
      const r = await api.post(`/invoices/${id}/send-whatsapp`, {});
      notify(r.sent ? `${id} WhatsApp sent` : `Skipped: ${r.reason}`, !r.sent);
    } catch (err) {
      notify(err.message || 'WhatsApp failed', true);
    }
  };

  const openPDF = (id) => {
    window.open(`/api/invoices/${encodeURIComponent(id)}/pdf`, '_blank');
  };

  return (
    <div className="pw">
      <div className="ph-title">Accounts</div>
      <div className="ph-sub">AR · AP · GST · Payments</div>

      {summary && (
        <div className="sc-grid">
          <StatCard label="Receivables AR" value={fmtINRCompact(summary.ar_paise)} sub={`${summary.unpaid_count} unpaid`} tone="r" />
          <StatCard label="Collected" value={fmtINRCompact(summary.collected_paise)} sub="settled" tone="s" />
          <StatCard label="Payables AP" value={fmtINRCompact(summary.ap_paise)} sub="incl GST" tone="g" />
          <StatCard label="Net GST Payable" value={fmtINRCompact(summary.net_gst_paise)} sub="output − ITC" tone="b" />
        </div>
      )}

      <div className="itabs">
        {['ar', 'ap', 'payments', 'gst'].map(k => (
          <div key={k} className={`itab${tab === k ? ' on' : ''}`} onClick={() => setTab(k)}>
            {{ ar: 'Receivables', ap: 'Payables', payments: 'Payments', gst: 'GST' }[k]}
          </div>
        ))}
      </div>

      {tab === 'ar' && (
        <div className="tw">
          <table className="dt">
            <thead><tr>
              <th>Invoice</th><th>Date</th><th>Customer</th><th>IRN</th>
              <th className="r">Taxable</th><th className="r">GST</th><th className="r">Total</th>
              <th>Status</th><th>Action</th>
            </tr></thead>
            <tbody>
              {invoices.map(inv => (
                <tr key={inv.id}>
                  <td className="tdm">{inv.id}</td>
                  <td>{inv.date}</td>
                  <td className="tdc">{inv.customer_name}</td>
                  <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8 }}>
                    {inv.irn ? inv.irn.slice(0, 10) + '…' : '—'}
                  </td>
                  <td className="tda">{fmtINR(inv.taxable_paise)}</td>
                  <td style={{ textAlign: 'right', fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, padding: '8px 10px', color: 'var(--t2)' }}>
                    {fmtINR(inv.cgst_paise + inv.sgst_paise + inv.igst_paise)}
                  </td>
                  <td className="tda">{fmtINR(inv.total_paise)}</td>
                  <td><StatusBadge value={inv.paid ? 'paid' : 'pending'} /></td>
                  <td style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                    <button className="btn btn-s btn-sm" onClick={() => openPDF(inv.id)}>PDF</button>
                    <button className="btn btn-s btn-sm" onClick={() => sendEmail(inv.id)}>✉</button>
                    <button className="btn btn-s btn-sm" onClick={() => sendWhatsApp(inv.id)}>💬</button>
                    {!inv.paid && (
                      <>
                        <button className="btn btn-s btn-sm" onClick={() => setEditInvoice(inv)}>Edit Lines</button>
                        <button className="btn btn-sage btn-sm" onClick={() => markPaid(inv.id)}>Settle ✓</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'ap' && (
        <div className="tw">
          <table className="dt">
            <thead><tr>
              <th>PO No</th><th>Date</th><th>Vendor</th><th>Variety</th>
              <th className="r">Taxable</th><th className="r">GST</th><th className="r">Total</th><th>Status</th>
            </tr></thead>
            <tbody>
              {pos.map(p => {
                const v = vendors.find(x => x.id === p.vendor_id);
                return (
                  <tr key={p.id}>
                    <td className="tdm">{p.id}</td><td>{p.date}</td>
                    <td className="tdc">{v?.name || '—'}</td><td>{p.variety}</td>
                    <td className="tda">{fmtINR(p.taxable_paise)}</td>
                    <td style={{ textAlign: 'right', fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, padding: '8px 10px', color: 'var(--sage)' }}>
                      {fmtINR(p.gst_paise)}
                    </td>
                    <td className="tda">{fmtINR(p.total_paise)}</td>
                    <td><StatusBadge value={p.status} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'payments' && (
        <div className="tw">
          <table className="dt">
            <thead><tr>
              <th>Ref</th><th>Date</th><th>Type</th><th>Party</th>
              <th>Mode</th><th>UTR</th><th className="r">Amount</th>
            </tr></thead>
            <tbody>
              {payments.map(p => (
                <tr key={p.id}>
                  <td className="tdm">{p.id}</td><td>{p.date}</td>
                  <td><StatusBadge value={p.type} /></td>
                  <td className="tdc">{p.party}</td>
                  <td className="tdm">{p.mode}</td>
                  <td className="tdm" style={{ fontSize: 9 }}>{p.utr || '—'}</td>
                  <td className="tda">{fmtINR(p.amount_paise)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'gst' && summary && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <GSTCard title="Output Tax" rows={[
            ['Total Taxable', summary.revenue_paise],
            ['Output GST', summary.gst_output_paise],
          ]} />
          <GSTCard title="GSTR-3B Worksheet" rows={[
            ['Output Tax', summary.gst_output_paise],
            ['ITC Claimed', summary.gst_itc_paise],
            ['Net Payable', summary.net_gst_paise],
          ]} />
        </div>
      )}

      {editInvoice && (
        <InvoiceLineEditor invoice={editInvoice}
          onClose={() => setEditInvoice(null)}
          onSaved={() => { setEditInvoice(null); loadAll(); }} />
      )}
    </div>
  );
}

// ─── Invoice line editor (post-invoice rate correction, unpaid only) ───
function InvoiceLineEditor({ invoice, onClose, onSaved }) {
  const [full, setFull] = useState(null);
  const [edits, setEdits] = useState({});       // { lineNo: { rate_paise?, qty? } }
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    api.get(`/invoices/${invoice.id}`).then(d => setFull(d.invoice));
  }, [invoice.id]);

  if (!full) {
    return <Overlay title="Loading…" onClose={onClose}>—</Overlay>;
  }

  const setEdit = (lineNo, key, val) => setEdits(e => ({ ...e, [lineNo]: { ...e[lineNo], [key]: val } }));
  const pending = Object.keys(edits).filter(k => {
    const e = edits[k];
    return e && (e.rate_paise != null || e.qty != null);
  });

  async function applyAll() {
    if (!reason || reason.length < 5) { setError('Reason required (min 5 chars)'); return; }
    if (!pending.length) { setError('No changes to apply'); return; }
    setSaving(true); setError(null);
    try {
      for (const lineNo of pending) {
        const payload = { reason };
        if (edits[lineNo].rate_paise != null) payload.rate_paise = edits[lineNo].rate_paise;
        if (edits[lineNo].qty != null)        payload.qty = edits[lineNo].qty;
        // eslint-disable-next-line no-await-in-loop
        await api.patch(`/invoices/${invoice.id}/items/${lineNo}`, payload);
      }
      onSaved();
    } catch (err) {
      setError(err.message || 'Apply failed');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Overlay title={`Edit ${invoice.id} — Unpaid Only`} onClose={onClose}>
      <div style={{ fontSize: 9, color: 'var(--t3)', marginBottom: 10 }}>
        Editing rate or qty on an unpaid invoice. If the total shifts more than 1%, the IRN will be regenerated.
      </div>
      <div className="tw" style={{ maxHeight: 300, overflowY: 'auto' }}>
        <table className="dt">
          <thead><tr>
            <th>#</th><th>Product</th><th>UOM</th>
            <th style={{ textAlign: 'right' }}>Qty</th>
            <th style={{ textAlign: 'right' }}>Rate</th>
            <th style={{ textAlign: 'right' }}>Line</th>
          </tr></thead>
          <tbody>
            {full.items?.map(it => {
              const edit = edits[it.line_no] || {};
              const newRate = edit.rate_paise != null ? edit.rate_paise : it.rate_paise;
              const newQty = edit.qty != null ? edit.qty : it.qty;
              const newLine = Math.round(newRate * it.uom_qty * newQty);
              const changed = edit.rate_paise != null || edit.qty != null;
              return (
                <tr key={it.line_no} style={{ background: changed ? 'var(--rustW)' : undefined }}>
                  <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9 }}>{it.line_no}</td>
                  <td style={{ fontSize: 10 }}>
                    <div>{it.variety}</div>
                    <div style={{ fontSize: 8, color: 'var(--t3)' }}>{it.product_kind} · {it.product_id}</div>
                  </td>
                  <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9 }}>
                    {it.uom_qty} {it.uom}
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <input type="number" min="0.01" step="0.01" value={newQty}
                      onChange={e => setEdit(it.line_no, 'qty', Math.max(0.01, +e.target.value))}
                      style={{ width: 55, fontSize: 10, padding: '2px 4px',
                        background: 'var(--bg3)', border: '1px solid var(--bd)', borderRadius: 3,
                        color: 'var(--t1)', fontFamily: "'IBM Plex Mono', monospace", textAlign: 'right' }} />
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <input type="number" min="0" step="0.01" value={(newRate / 100).toFixed(2)}
                      onChange={e => setEdit(it.line_no, 'rate_paise', Math.round(+e.target.value * 100))}
                      style={{ width: 70, fontSize: 10, padding: '2px 4px',
                        background: 'var(--bg3)', border: '1px solid var(--bd)', borderRadius: 3,
                        color: 'var(--t1)', fontFamily: "'IBM Plex Mono', monospace", textAlign: 'right' }} />
                  </td>
                  <td style={{ textAlign: 'right', fontFamily: "'IBM Plex Mono', monospace", fontSize: 10,
                               color: changed ? 'var(--rust)' : 'var(--t1)' }}>
                    {fmtINR(newLine)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="fg" style={{ marginTop: 10 }}>
        <label className="fl">Reason for edit * (required for audit)</label>
        <input className="fi" value={reason} onChange={e => setReason(e.target.value)}
          placeholder="e.g. Negotiated discount with Rajan Tiles" maxLength={500} />
      </div>

      {error && (
        <div style={{ color: 'var(--rust)', fontSize: 9, marginTop: 6 }}>{error}</div>
      )}

      <div style={{ display: 'flex', gap: 7, marginTop: 14 }}>
        <button className="btn btn-p" onClick={applyAll} disabled={saving || !pending.length}>
          {saving ? 'Applying…' : `Apply ${pending.length} change${pending.length !== 1 ? 's' : ''}`}
        </button>
        <button className="btn btn-s" onClick={onClose}>Cancel</button>
      </div>
    </Overlay>
  );
}

function Overlay({ title, children, onClose }) {
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,.78)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 100, padding: 14, overflowY: 'auto',
    }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: 'var(--bg2)', border: '1px solid rgba(128,128,128,.15)',
        borderRadius: 10, width: '100%', maxWidth: 560,
      }}>
        <div style={{ padding: '13px 16px', borderBottom: '1px solid var(--bd)',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: 'var(--t1)' }}>{title}</span>
          <button onClick={onClose} style={{ color: 'var(--t3)', fontSize: 15 }}>✕</button>
        </div>
        <div style={{ padding: '14px 16px' }}>{children}</div>
      </div>
    </div>
  );
}

function GSTCard({ title, rows }) {
  return (
    <div className="card" style={{ marginBottom: 0 }}>
      <div className="card-head"><span className="card-title">{title}</span></div>
      <div className="card-body">
        {rows.map(([l, v], i) => (
          <div key={l} style={{
            display: 'flex', justifyContent: 'space-between', padding: '6px 0',
            borderBottom: i < rows.length - 1 ? '1px solid var(--bd)' : 'none',
          }}>
            <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, color: 'var(--t2)' }}>{l}</span>
            <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: 'var(--gold)' }}>{fmtINR(v)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
