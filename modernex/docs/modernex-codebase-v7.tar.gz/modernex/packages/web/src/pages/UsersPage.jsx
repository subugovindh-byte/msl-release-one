import { useEffect, useState } from 'react';
import { api } from '../utils/api.js';
import { useAuth } from '../contexts/AuthContext.jsx';
import { useToast } from '../contexts/ToastContext.jsx';
import { StatusBadge } from '../components/Shared.jsx';
import { fmtDate } from '../utils/format.js';

const ROLES = ['admin', 'accounts', 'yard', 'sales'];

export function UsersPage() {
  const { user: me } = useAuth();
  const { notify } = useToast();
  const [users, setUsers] = useState([]);
  const [modal, setModal] = useState(null);  // 'new' | 'edit' | 'reset' | 'changePw' | null
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ username: '', full_name: '', email: '', phone: '',
    role: 'sales', password: '', must_change: true });
  const [generatedPw, setGeneratedPw] = useState(null);

  const load = () => api.get('/users').then(d => setUsers(d.users || []));
  useEffect(() => { if (me?.role === 'admin') load(); }, [me]);

  if (me?.role !== 'admin') {
    return (
      <div className="pw">
        <div className="ph-title">Users</div>
        <div className="ph-sub">User management — admin access required</div>
        <div className="card" style={{ maxWidth: 500 }}>
          <div className="card-head"><span className="card-title">Change Your Password</span></div>
          <div className="card-body">
            <ChangePasswordForm onDone={() => notify('Password changed')} />
          </div>
        </div>
      </div>
    );
  }

  const upd = k => v => setForm(f => ({ ...f, [k]: v }));

  async function createUser(e) {
    e.preventDefault();
    try {
      const payload = {
        username: form.username,
        full_name: form.full_name,
        email: form.email || undefined,
        phone: form.phone || undefined,
        role: form.role,
        password: form.password || undefined,
        must_change_password: form.must_change,
      };
      const { user, generated_password } = await api.post('/users', payload);
      notify(`User ${user.username} created`);
      if (generated_password) setGeneratedPw({ username: user.username, password: generated_password });
      setModal(null);
      setForm({ username: '', full_name: '', email: '', phone: '', role: 'sales', password: '', must_change: true });
      load();
    } catch (err) {
      notify(err.message || 'Failed to create user', true);
    }
  }

  async function saveEdit(e) {
    e.preventDefault();
    try {
      await api.patch(`/users/${editing.id}`, {
        full_name: form.full_name,
        email: form.email || '',
        phone: form.phone || '',
        role: form.role,
      });
      notify(`${editing.username} updated`);
      setModal(null);
      setEditing(null);
      load();
    } catch (err) {
      notify(err.message || 'Update failed', true);
    }
  }

  async function resetPassword(userId) {
    if (!confirm(`Reset password for this user? Generated password will be shown ONCE.`)) return;
    try {
      const { generated_password } = await api.post(`/users/${userId}/reset-password`, { must_change: true });
      if (generated_password) {
        setGeneratedPw({
          username: users.find(u => u.id === userId)?.username,
          password: generated_password,
        });
      }
      load();
    } catch (err) {
      notify(err.message || 'Reset failed', true);
    }
  }

  async function toggleActive(user) {
    try {
      await api.patch(`/users/${user.id}`, { active: !user.active });
      notify(`${user.username} ${user.active ? 'deactivated' : 'activated'}`);
      load();
    } catch (err) {
      notify(err.message || 'Failed', true);
    }
  }

  async function unlockUser(userId) {
    try {
      await api.post(`/users/${userId}/unlock`);
      notify('Account unlocked');
      load();
    } catch (err) {
      notify(err.message, true);
    }
  }

  return (
    <div className="pw">
      <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
        <div>
          <div className="ph-title">Users</div>
          <div className="ph-sub">Admin · Role-based access control</div>
        </div>
        <button className="btn btn-p btn-sm" onClick={() => { setModal('new'); setForm({ username: '', full_name: '', email: '', phone: '', role: 'sales', password: '', must_change: true }); }}>
          + New User
        </button>
      </div>

      <div className="tw">
        <table className="dt">
          <thead><tr>
            <th>Username</th><th>Full Name</th><th>Role</th><th>Email</th>
            <th>Last Login</th><th>Status</th><th>Actions</th>
          </tr></thead>
          <tbody>
            {users.map(u => {
              const isLocked = u.locked_until && new Date(u.locked_until) > new Date();
              return (
                <tr key={u.id}>
                  <td className="tdm">{u.username}{u.id === me.id && <span className="bdg b-b" style={{ marginLeft: 5, fontSize: 7 }}>you</span>}</td>
                  <td className="tdc">{u.full_name}</td>
                  <td><span className="bdg b-d">{u.role}</span></td>
                  <td className="tdm">{u.email || '—'}</td>
                  <td style={{ fontSize: 10, color: 'var(--t3)' }}>
                    {u.last_login ? fmtDate(u.last_login) : '—'}
                  </td>
                  <td>
                    {!u.active ? <StatusBadge value="inactive" />
                      : isLocked ? <span className="bdg b-r">locked</span>
                      : u.must_change_password ? <span className="bdg b-g">pw change</span>
                      : <span className="bdg b-s">active</span>}
                  </td>
                  <td style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                    <button className="btn btn-s btn-sm" onClick={() => {
                      setEditing(u);
                      setForm({ full_name: u.full_name, email: u.email || '', phone: u.phone || '', role: u.role });
                      setModal('edit');
                    }}>Edit</button>
                    <button className="btn btn-s btn-sm" onClick={() => resetPassword(u.id)}>Reset PW</button>
                    {isLocked && <button className="btn btn-sage btn-sm" onClick={() => unlockUser(u.id)}>Unlock</button>}
                    {u.id !== me.id && (
                      <button className="btn btn-s btn-sm" onClick={() => toggleActive(u)}>
                        {u.active ? 'Deactivate' : 'Activate'}
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* NEW / EDIT MODAL */}
      {(modal === 'new' || modal === 'edit') && (
        <Modal onClose={() => setModal(null)} title={modal === 'new' ? 'New User' : `Edit ${editing?.username}`}>
          <form onSubmit={modal === 'new' ? createUser : saveEdit}>
            {modal === 'new' && (
              <div className="fg">
                <label className="fl">Username *</label>
                <input className="fi" required pattern="[a-zA-Z0-9_.-]{3,}"
                  value={form.username} onChange={e => upd('username')(e.target.value)}
                  placeholder="lowercase, no spaces" />
              </div>
            )}
            <div className="fg">
              <label className="fl">Full Name *</label>
              <input className="fi" required value={form.full_name}
                onChange={e => upd('full_name')(e.target.value)} />
            </div>
            <div className="fg2">
              <div className="fg" style={{ marginBottom: 0 }}>
                <label className="fl">Email</label>
                <input className="fi" type="email" value={form.email}
                  onChange={e => upd('email')(e.target.value)} />
              </div>
              <div className="fg" style={{ marginBottom: 0 }}>
                <label className="fl">Phone</label>
                <input className="fi" type="tel" value={form.phone}
                  onChange={e => upd('phone')(e.target.value)} />
              </div>
            </div>
            <div className="fg">
              <label className="fl">Role *</label>
              <select className="fsel" value={form.role}
                onChange={e => upd('role')(e.target.value)}
                disabled={modal === 'edit' && editing?.id === me.id}>
                {ROLES.map(r => <option key={r}>{r}</option>)}
              </select>
            </div>
            {modal === 'new' && (
              <>
                <div className="fg">
                  <label className="fl">Password (leave blank to generate)</label>
                  <input className="fi" type="password" minLength={8}
                    value={form.password} onChange={e => upd('password')(e.target.value)}
                    placeholder="Min 8 chars" />
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                  <input id="mustChange" type="checkbox" checked={form.must_change}
                    onChange={e => upd('must_change')(e.target.checked)}
                    style={{ accentColor: 'var(--rust)' }} />
                  <label htmlFor="mustChange" style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, color: 'var(--t2)' }}>
                    Force password change on first login
                  </label>
                </div>
              </>
            )}
            <div style={{ display: 'flex', gap: 7, marginTop: 14 }}>
              <button className="btn btn-p" type="submit">{modal === 'new' ? 'Create' : 'Save'}</button>
              <button className="btn btn-s" type="button" onClick={() => setModal(null)}>Cancel</button>
            </div>
          </form>
        </Modal>
      )}

      {/* GENERATED PASSWORD DISPLAY */}
      {generatedPw && (
        <Modal onClose={() => setGeneratedPw(null)} title="Password Generated">
          <div style={{ padding: '10px 0' }}>
            <p style={{ fontSize: 13, color: 'var(--t2)', marginBottom: 12 }}>
              Copy and share this password <strong style={{ color: 'var(--rust)' }}>out-of-band</strong> (in person, SMS, etc).
              It will NOT be shown again.
            </p>
            <div style={{
              background: 'var(--bg3)', border: '1px solid var(--bd)', borderRadius: 4,
              padding: '12px 16px', fontFamily: "'IBM Plex Mono', monospace",
            }}>
              <div style={{ fontSize: 9, color: 'var(--t3)', marginBottom: 4, letterSpacing: 1.5 }}>USER</div>
              <div style={{ fontSize: 13, color: 'var(--t1)', marginBottom: 10 }}>{generatedPw.username}</div>
              <div style={{ fontSize: 9, color: 'var(--t3)', marginBottom: 4, letterSpacing: 1.5 }}>PASSWORD</div>
              <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--rust)', userSelect: 'all' }}>
                {generatedPw.password}
              </div>
            </div>
            <button className="btn btn-p" style={{ width: '100%', marginTop: 14 }}
              onClick={() => {
                navigator.clipboard?.writeText(generatedPw.password);
                notify('Copied to clipboard');
              }}>
              Copy Password
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function ChangePasswordForm({ onDone }) {
  const { notify } = useToast();
  const [form, setForm] = useState({ current: '', new: '', confirm: '' });
  const [submitting, setSubmitting] = useState(false);

  async function submit(e) {
    e.preventDefault();
    if (form.new !== form.confirm) {
      notify('Passwords do not match', true);
      return;
    }
    if (form.new.length < 8) {
      notify('New password must be at least 8 characters', true);
      return;
    }
    setSubmitting(true);
    try {
      await api.post('/users/me/change-password', {
        current_password: form.current,
        new_password: form.new,
      });
      setForm({ current: '', new: '', confirm: '' });
      onDone?.();
    } catch (err) {
      notify(err.message || 'Failed', true);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={submit}>
      <div className="fg">
        <label className="fl">Current Password</label>
        <input className="fi" type="password" required
          value={form.current} onChange={e => setForm(f => ({ ...f, current: e.target.value }))} />
      </div>
      <div className="fg">
        <label className="fl">New Password (min 8)</label>
        <input className="fi" type="password" required minLength={8}
          value={form.new} onChange={e => setForm(f => ({ ...f, new: e.target.value }))} />
      </div>
      <div className="fg">
        <label className="fl">Confirm New Password</label>
        <input className="fi" type="password" required minLength={8}
          value={form.confirm} onChange={e => setForm(f => ({ ...f, confirm: e.target.value }))} />
      </div>
      <button className="btn btn-p" type="submit" disabled={submitting}>
        {submitting ? 'Saving…' : 'Change Password'}
      </button>
    </form>
  );
}

function Modal({ title, children, onClose }) {
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,.78)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 100, padding: 14,
    }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: 'var(--bg2)', border: '1px solid rgba(128,128,128,.15)',
        borderRadius: 10, width: '100%', maxWidth: 420,
      }}>
        <div style={{
          padding: '13px 16px', borderBottom: '1px solid var(--bd)',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: 'var(--t1)' }}>{title}</span>
          <button onClick={onClose} style={{ color: 'var(--t3)', fontSize: 15 }}>✕</button>
        </div>
        <div style={{ padding: '14px 16px' }}>
          {children}
        </div>
      </div>
    </div>
  );
}
