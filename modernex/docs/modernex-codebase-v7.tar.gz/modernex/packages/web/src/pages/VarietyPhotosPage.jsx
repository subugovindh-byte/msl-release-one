import { useEffect, useState } from 'react';
import { api } from '../utils/api.js';
import { useAuth } from '../contexts/AuthContext.jsx';
import { useToast } from '../contexts/ToastContext.jsx';

// Admin-only page for managing per-variety reference photos.
// Each variety has a photo (default loaded from seed) that can be overridden
// by uploading a new image. The override flows through to all products of
// that variety in POS, Inventory, and Products pages.
export function VarietyPhotosPage() {
  const { user } = useAuth();
  const { notify } = useToast();
  const [varieties, setVarieties] = useState([]);
  const [filter, setFilter] = useState('All');
  const [uploading, setUploading] = useState(null);

  const isAdmin = user?.role === 'admin';

  const load = () => api.get('/variety-defaults').then(d => setVarieties(d.varieties || []));
  useEffect(() => { load(); }, []);

  const regions = ['All', ...Array.from(new Set(varieties.map(v => v.region).filter(Boolean))).sort()];
  const filtered = filter === 'All' ? varieties : varieties.filter(v => v.region === filter);

  async function handleUpload(variety, file) {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      notify('File too large (>5MB)', true);
      return;
    }
    setUploading(variety);
    try {
      const reader = new FileReader();
      const dataUri = await new Promise((res, rej) => {
        reader.onload = () => res(reader.result);
        reader.onerror = rej;
        reader.readAsDataURL(file);
      });
      await api.patch(`/variety-defaults/${encodeURIComponent(variety)}`, {
        photo_url: dataUri,
      });
      notify(`Updated ${variety}`);
      load();
    } catch (err) {
      notify(err.message || 'Upload failed', true);
    } finally {
      setUploading(null);
    }
  }

  if (!isAdmin) {
    return (
      <div className="pw">
        <div className="ph-title">Variety Photos</div>
        <div style={{ padding: 30, color: 'var(--t3)', textAlign: 'center' }}>
          Admin access required
        </div>
      </div>
    );
  }

  return (
    <div className="pw">
      <div className="ph-title">Variety Photo Library</div>
      <div className="ph-sub">
        Per-variety reference photos · used as fallback when products lack custom uploads · admin only
      </div>

      <div style={{ display: 'flex', gap: 6, padding: '10px 0', flexWrap: 'wrap' }}>
        {regions.map(r => (
          <button key={r} type="button"
            onClick={() => setFilter(r)}
            className={filter === r ? 'btn btn-p btn-sm' : 'btn btn-s btn-sm'}
            style={{ fontSize: 10 }}>
            {r}
          </button>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: 10 }}>
        {filtered.map(v => (
          <div key={v.variety} style={{
            background: 'var(--bg2)', border: '1px solid var(--bd)',
            borderRadius: 6, padding: 10,
          }}>
            <div style={{ width: '100%', height: 100, marginBottom: 8,
                          borderRadius: 4, overflow: 'hidden', background: 'var(--bg3)',
                          display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {v.photo_url ? (
                <img src={v.photo_url} alt={v.variety}
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                <span style={{ fontSize: 9, color: 'var(--t3)' }}>No photo</span>
              )}
            </div>
            <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 12, fontWeight: 600,
                          color: 'var(--t1)' }}>
              {v.variety}
            </div>
            <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8,
                          color: 'var(--t3)', marginTop: 2, textTransform: 'uppercase', letterSpacing: 1 }}>
              {v.region || '—'} · {v.source || 'reference'}
            </div>
            {v.notes && (
              <div style={{ fontSize: 9, color: 'var(--t2)', marginTop: 4, lineHeight: 1.4 }}>
                {v.notes}
              </div>
            )}
            <label style={{ display: 'block', marginTop: 8 }}>
              <span className="btn btn-s btn-sm" style={{ width: '100%', display: 'inline-block', textAlign: 'center' }}>
                {uploading === v.variety ? 'Uploading…' : 'Upload Photo'}
              </span>
              <input type="file" accept="image/*"
                style={{ display: 'none' }}
                onChange={e => handleUpload(v.variety, e.target.files?.[0])} />
            </label>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div style={{ padding: 30, color: 'var(--t3)', textAlign: 'center' }}>
          No varieties match
        </div>
      )}
    </div>
  );
}
