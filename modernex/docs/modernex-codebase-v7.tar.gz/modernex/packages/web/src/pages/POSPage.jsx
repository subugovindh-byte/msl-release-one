import { useState, useEffect, useMemo } from 'react';
import { api } from '../utils/api.js';
import { useToast } from '../contexts/ToastContext.jsx';
import { fmtINR } from '../utils/format.js';
import { useVarietyDefaults, resolveProductPhoto } from '../utils/varietyDefaults.js';

// Mirror shared/constants.js locally — no shared/web build plumbing needed for this
const KIND_CONFIG = {
  block:    { label: 'Blocks',     uom: 'CFT',    hsn: '2515', icon: 'B' },
  slab:     { label: 'Slabs',      uom: 'sqft',   hsn: '2516', icon: 'S' },
  tile:     { label: 'Tiles',      uom: 'pc',     hsn: '2516', icon: 'T' },
  cts:      { label: 'Cut-to-Size',uom: 'sqft',   hsn: '2516', icon: 'C' },
  strip:    { label: 'Strips',     uom: 'rft',    hsn: '2516', icon: 'R' },
  kerb:     { label: 'Kerbs',      uom: 'pc',     hsn: '2516', icon: 'K' },
  cobble:   { label: 'Cobbles',    uom: 'pc',     hsn: '2516', icon: 'B' },
  chips:    { label: 'Chips',      uom: 'tonne',  hsn: '2517', icon: 'H' },
  dust:     { label: 'Dust',       uom: 'tonne',  hsn: '2517', icon: 'D' },
  monument: { label: 'Monuments',  uom: 'pc',     hsn: '2516', icon: 'M' },
};
const KIND_ORDER = ['block', 'slab', 'tile', 'cts', 'strip', 'kerb', 'cobble', 'chips', 'dust', 'monument'];

function uomQtyForProduct(p) {
  const d = p.dimensions || {};
  if (p.kind === 'slab' || p.kind === 'cts')  return d.sqft || 1;
  if (p.kind === 'block')                     return d.cft || 1;
  if (p.kind === 'strip')                     return d.rft_per_piece || 1;
  if (p.kind === 'tile')                      return d.sqft_per_tile || 1;
  return 1;
}

export function POSPage() {
  const { notify } = useToast();
  const [products, setProducts] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [cart, setCart] = useState([]);
  const [q, setQ] = useState('');
  const [kindFilter, setKindFilter] = useState('All');
  const [variety, setVariety] = useState('All');
  const [grade, setGrade] = useState('All');
  const [custId, setCustId] = useState('');
  const [disc, setDisc] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [invoice, setInvoice] = useState(null);
  const [collectionAccounts, setCollectionAccounts] = useState([]);
  const [collAccId, setCollAccId] = useState('');
  const { map: varietyMap } = useVarietyDefaults();

  useEffect(() => {
    api.get('/products?active=true').then(d => setProducts(d.products || []));
    api.get('/customers').then(d => {
      setCustomers(d.customers || []);
      const walkIn = d.customers?.find(c => c.name?.includes('Walk-in'));
      if (walkIn) setCustId(walkIn.id);
    });
    api.get('/collection-accounts?active=true').then(d => {
      const list = d.accounts || [];
      setCollectionAccounts(list);
      const def = list.find(a => a.is_default);
      if (def) setCollAccId(def.id);
      else if (list[0]) setCollAccId(list[0].id);
    });
  }, []);

  const cust = customers.find(c => c.id === custId);

  // Kinds that have any product (dynamic filter chips)
  const availableKinds = useMemo(() => {
    const set = new Set(products.map(p => p.kind));
    return KIND_ORDER.filter(k => set.has(k));
  }, [products]);

  const varieties = useMemo(() => {
    const set = new Set(products.map(p => p.variety));
    return ['All', ...Array.from(set).sort()];
  }, [products]);

  const filtered = useMemo(() => {
    return products.filter(p => {
      if (kindFilter !== 'All' && p.kind !== kindFilter) return false;
      if (variety !== 'All' && p.variety !== variety) return false;
      if (grade !== 'All' && p.grade !== grade) return false;
      if (q) {
        const qx = q.toLowerCase();
        if (!(p.variety?.toLowerCase().includes(qx) ||
              p.id?.toLowerCase().includes(qx) ||
              p.lot_id?.toLowerCase().includes(qx))) return false;
      }
      return true;
    });
  }, [products, kindFilter, variety, grade, q]);

  const add = (p) => {
    if (p.stock <= 0) return;
    const idx = cart.findIndex(ci => ci.product.id === p.id);
    if (idx >= 0) {
      if (cart[idx].qty >= p.stock) return;
      setCart(c => c.map((ci, i) =>
        i === idx ? { ...ci, qty: ci.qty + 1 } : ci));
    } else {
      setCart(c => [...c, {
        product: p,
        qty: 1,
        uom_qty: uomQtyForProduct(p),
        rate_paise: p.rate_paise,          // start with master rate, user may override
      }]);
    }
  };

  const updateQty = (pid, delta) => {
    setCart(c => c.map(ci => {
      if (ci.product.id !== pid) return ci;
      const nq = ci.qty + delta;
      if (nq < 1) return null;
      if (nq > ci.product.stock) return ci;
      return { ...ci, qty: nq };
    }).filter(Boolean));
  };

  const setLineRate = (pid, rupees) => {
    const paise = Math.max(0, Math.round(Number(rupees) * 100));
    setCart(c => c.map(ci => ci.product.id === pid ? { ...ci, rate_paise: paise } : ci));
  };

  const removeLine = (pid) => setCart(c => c.filter(ci => ci.product.id !== pid));

  const subtotal = cart.reduce((s, ci) =>
    s + Math.round(ci.rate_paise * ci.uom_qty * ci.qty), 0);
  const discountPaise = Math.round(subtotal * (disc / 100));
  const taxable = subtotal - discountPaise;
  // Simplified preview: assume 12% for the tax line (real calc happens on server across HSN groups)
  const tax = Math.round(taxable * 0.12);
  const total = taxable + tax;

  async function createInvoice() {
    if (!cart.length || !custId) return;
    setSubmitting(true);
    try {
      const payload = {
        customer_id: custId,
        discount_pct: disc,
        collection_account_id: collAccId || undefined,
        items: cart.map(ci => ({
          product_id: ci.product.id,
          uom_qty: ci.uom_qty,
          qty: ci.qty,
          rate_paise: ci.rate_paise,
        })),
      };
      const { invoice } = await api.post('/invoices', payload);
      setInvoice(invoice);
      setCart([]);
      api.get('/products?active=true').then(d => setProducts(d.products || []));
      notify(`${invoice.id} created`);
    } catch (err) {
      notify(err.message || 'Invoice failed', true);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="pos-wrap">
      {/* ═══ CATALOG ═══ */}
      <div className="pos-cat">
        {/* Kind filter chips */}
        <div style={{ display: 'flex', gap: 6, padding: '8px 12px', flexWrap: 'wrap',
                      borderBottom: '1px solid var(--bd)', background: 'var(--bg2)' }}>
          {['All', ...availableKinds].map(k => (
            <button key={k} type="button"
              onClick={() => setKindFilter(k)}
              className={kindFilter === k ? 'btn btn-p btn-sm' : 'btn btn-s btn-sm'}
              style={{ fontSize: 10 }}>
              {k === 'All' ? 'All Products' : KIND_CONFIG[k]?.label || k}
              <span style={{ marginLeft: 5, opacity: 0.6, fontSize: 9 }}>
                {k === 'All'
                  ? products.length
                  : products.filter(p => p.kind === k).length}
              </span>
            </button>
          ))}
        </div>

        <div className="sbar">
          <input className="si" placeholder="Search variety, lot, ID…"
            value={q} onChange={e => setQ(e.target.value)} type="search" />
          <select className="sf" value={variety} onChange={e => setVariety(e.target.value)}>
            {varieties.map(v => <option key={v} value={v}>{v}</option>)}
          </select>
          <select className="sf" value={grade} onChange={e => setGrade(e.target.value)}>
            <option>All</option><option>A+</option><option>A</option><option>B</option>
          </select>
        </div>

        {filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 40, color: 'var(--t3)',
                        fontFamily: "'IBM Plex Mono', monospace", fontSize: 11 }}>
            No products match your filters
          </div>
        ) : (
          <div className="slab-grid">
            {filtered.map(p => {
              const cartItem = cart.find(ci => ci.product.id === p.id);
              const cq = cartItem?.qty || 0;
              const cfg = KIND_CONFIG[p.kind] || {};
              return (
                <ProductCard key={p.id} product={p} cq={cq}
                  cfg={cfg}
                  varietyMap={varietyMap}
                  onClick={() => add(p)} />
              );
            })}
          </div>
        )}
      </div>

      {/* ═══ CART ═══ */}
      <div className="cart-wrap">
        <div className="cart-head">
          <span className="cart-ht">Bill</span>
          <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9,
            color: 'var(--t3)', padding: '3px 7px', border: '1px solid var(--bd)',
            borderRadius: 3, background: 'var(--bg3)',
          }}>{cart.reduce((s, ci) => s + ci.qty, 0)} items</span>
        </div>
        <div className="cart-cust">
          <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 7.5,
            letterSpacing: 1, textTransform: 'uppercase', color: 'var(--t3)', marginBottom: 3 }}>
            Customer
          </div>
          <select className="fsel" style={{ padding: '6px 8px', fontSize: 11 }}
            value={custId} onChange={e => setCustId(e.target.value)}>
            {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        {collectionAccounts.length > 1 && (
          <div className="cart-cust" style={{ borderTop: '1px solid var(--bd)' }}>
            <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 7.5,
              letterSpacing: 1, textTransform: 'uppercase', color: 'var(--t3)', marginBottom: 3 }}>
              Collect Into
            </div>
            <select className="fsel" style={{ padding: '6px 8px', fontSize: 11 }}
              value={collAccId} onChange={e => setCollAccId(e.target.value)}>
              {collectionAccounts.map(a => (
                <option key={a.id} value={a.id}>
                  {a.name}{a.is_default ? ' ★' : ''}
                </option>
              ))}
            </select>
          </div>
        )}

        <div className="cart-list">
          {cart.length === 0 ? (
            <div className="cart-empty">
              <div className="ce-ico">🪨</div>
              <div className="ce-txt">Tap items to add</div>
            </div>
          ) : cart.map(ci => {
            const lt = Math.round(ci.rate_paise * ci.uom_qty * ci.qty);
            const cfg = KIND_CONFIG[ci.product.kind] || {};
            const rateRupees = (ci.rate_paise / 100).toFixed(2);
            return (
              <div key={ci.product.id} className="ci">
                <div className="ci-top">
                  <div className="ci-nm">
                    <span className="bdg b-d" style={{ fontSize: 7, marginRight: 5 }}>{cfg.icon}</span>
                    {ci.product.variety}
                  </div>
                  <button className="ci-rm" onClick={() => removeLine(ci.product.id)}>✕</button>
                </div>
                <div className="ci-dt">
                  {ci.product.id} · {ci.product.kind} · {ci.uom_qty} {cfg.uom}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
                  <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8, color: 'var(--t3)' }}>₹</span>
                  <input type="number" min="0" step="0.01"
                    value={rateRupees}
                    onChange={e => setLineRate(ci.product.id, e.target.value)}
                    style={{ width: 70, fontSize: 10, fontFamily: "'IBM Plex Mono', monospace",
                             padding: '2px 4px', background: 'var(--bg3)', border: '1px solid var(--bd)',
                             borderRadius: 3, color: 'var(--t1)' }} />
                  <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8, color: 'var(--t3)' }}>/{cfg.uom}</span>
                  {ci.rate_paise !== ci.product.rate_paise && (
                    <span style={{ fontSize: 7, color: 'var(--gold)', letterSpacing: 1 }}>MODIFIED</span>
                  )}
                </div>
                <div className="ci-bot" style={{ marginTop: 6 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                    <button className="btn btn-s btn-sm" style={{ padding: '2px 7px' }}
                      onClick={() => updateQty(ci.product.id, -1)}>−</button>
                    <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, minWidth: 18, textAlign: 'center' }}>{ci.qty}</span>
                    <button className="btn btn-s btn-sm" style={{ padding: '2px 7px' }}
                      disabled={ci.qty >= ci.product.stock}
                      onClick={() => updateQty(ci.product.id, 1)}>+</button>
                  </div>
                  <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, color: 'var(--rust)', fontWeight: 600 }}>
                    {fmtINR(lt)}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="tot-block">
          <div className="tot-row"><span>Subtotal</span><span>{fmtINR(subtotal)}</span></div>
          <div className="tot-row">
            <span>Discount %</span>
            <input type="number" min="0" max="30" value={disc}
              onChange={e => setDisc(Math.max(0, Math.min(30, +e.target.value || 0)))}
              style={{ width: 50, textAlign: 'right', fontSize: 10, padding: '2px 4px',
                       background: 'var(--bg3)', border: '1px solid var(--bd)', borderRadius: 3,
                       color: 'var(--t1)', fontFamily: "'IBM Plex Mono', monospace" }} />
          </div>
          <div className="tot-row"><span>Taxable</span><span>{fmtINR(taxable)}</span></div>
          <div className="tot-row"><span>GST (approx 12%)</span><span>{fmtINR(tax)}</span></div>
          <div className="tot-grand">
            <span className="tg-lbl">Grand Total</span>
            <span className="tg-val">{fmtINR(total)}</span>
          </div>
        </div>

        <div style={{ padding: '10px 12px' }}>
          <button className="btn btn-p" style={{ width: '100%' }}
            onClick={createInvoice} disabled={!cart.length || !custId || submitting}>
            {submitting ? 'Creating…' : '→ Create Invoice'}
          </button>
        </div>
      </div>

      {invoice && <InvoiceOverlay invoice={invoice} onClose={() => setInvoice(null)} />}
    </div>
  );
}

// ─── ProductCard — renders kind-appropriate layout with variety photo ───
function ProductCard({ product, cq, cfg, varietyMap, onClick }) {
  const d = product.dimensions || {};
  const photoUrl = resolveProductPhoto(product, varietyMap);
  let primaryLine = null;
  let secondaryLine = null;

  switch (product.kind) {
    case 'block':
      primaryLine = `${d.length_m || '?'} × ${d.width_m || '?'} × ${d.height_m || '?'}m`;
      secondaryLine = `${d.cft || '?'} CFT`;
      break;
    case 'slab':
      primaryLine = `${d.size_lw || '?'} mm`;
      secondaryLine = `${d.thickness_mm || '?'}mm · ${d.sqft?.toFixed(1) || '?'}sqft`;
      break;
    case 'tile':
      primaryLine = `${d.size_lw || '?'} mm`;
      secondaryLine = `${d.thickness_mm || '?'}mm${d.pieces_per_box ? ` · ${d.pieces_per_box}/box` : ''}`;
      break;
    case 'cts':
      primaryLine = `${d.length_mm || '?'} × ${d.width_mm || '?'}mm`;
      secondaryLine = `${d.thickness_mm || '?'}mm · ${d.sqft?.toFixed(1) || '?'}sqft`;
      break;
    case 'strip':
      primaryLine = `${d.length_mm || '?'} × ${d.width_mm || '?'}mm`;
      secondaryLine = `${d.rft_per_piece?.toFixed(2) || '?'} rft/pc`;
      break;
    case 'kerb':
      primaryLine = d.profile || 'Profile —';
      secondaryLine = `${d.length_mm || '?'}mm`;
      break;
    case 'cobble':
      primaryLine = d.cobble_type || '—';
      secondaryLine = `${d.length_mm || '?'}×${d.width_mm || '?'}×${d.height_mm || '?'}mm`;
      break;
    case 'chips':
      primaryLine = `${d.mesh_size_mm || '?'}mm mesh`;
      secondaryLine = product.stock + ' tonnes';
      break;
    case 'dust':
      primaryLine = 'Quarry dust';
      secondaryLine = product.stock + ' tonnes';
      break;
    case 'monument':
      primaryLine = d.monument_type || 'Monument';
      secondaryLine = d.length_mm ? `${d.length_mm}×${d.width_mm}×${d.thickness_mm}mm` : `${product.stock} pc`;
      break;
  }

  const low = product.stock <= 2;
  const uom = cfg.uom || 'pc';

  return (
    <div className={`slab${cq ? ' ink' : ''}${low ? ' low' : ''}`}
         style={{ cursor: product.stock > 0 ? 'pointer' : 'not-allowed',
                  opacity: product.stock > 0 ? 1 : 0.55 }}
         onClick={onClick}>
      {cq > 0 && <div className="sl-dot">{cq}</div>}
      {photoUrl && (
        <img src={photoUrl} alt={product.variety}
          style={{ width: '100%', height: 60, objectFit: 'cover', borderRadius: 3,
                   margin: '-2px 0 6px', background: 'var(--bg3)', display: 'block' }}
          onError={e => { e.currentTarget.style.display = 'none'; }} />
      )}
      <div style={{ fontSize: 6.5, letterSpacing: 1.2, textTransform: 'uppercase',
        color: 'var(--t3)', fontFamily: "'IBM Plex Mono', monospace", marginBottom: 2 }}>
        {product.kind} · {cfg.icon}
      </div>
      <div className="sl-var">{product.variety}</div>
      <div className="sl-lot">{product.lot_id || product.id}</div>
      <div className="sl-dims">{primaryLine}</div>
      <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8, color: 'var(--t3)', marginTop: 1 }}>
        {secondaryLine}
      </div>
      <div className="sl-bot">
        <div>
          <div className="sl-price">
            ₹{(product.rate_paise / 100).toFixed(0)}
            <span className="sl-unit">/{uom}</span>
          </div>
          <div className="sl-sqft">
            Stock: {product.stock}{' '}
            {product.kind === 'chips' || product.kind === 'dust' ? 'MT' : 'pc'}
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          {product.grade && (
            <span className="bdg" style={{
              color: `var(--${product.grade === 'A+' ? 'gold' : product.grade === 'A' ? 'sage' : 'blue'})`,
              background: `var(--${product.grade === 'A+' ? 'goldW' : product.grade === 'A' ? 'sageW' : 'blueW'})`,
            }}>{product.grade}</span>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Invoice confirmation overlay (kept from v4 — now works for all kinds) ───
function InvoiceOverlay({ invoice, onClose }) {
  const qrUrl = `/api/qr/upi/invoice/${encodeURIComponent(invoice.id)}?size=400&_t=${Date.now()}`;
  return (
    <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.78)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 14, zIndex: 50, overflowY: 'auto' }}>
      <div style={{ background: 'var(--bg2)', border: '1px solid rgba(128,128,128,.15)',
        borderRadius: 10, width: '100%', maxWidth: 420, maxHeight: '95%', overflowY: 'auto' }}>
        <div style={{ background: 'var(--bg3)', padding: '16px 16px 12px', borderBottom: '1px solid var(--bd)' }}>
          <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 16, fontWeight: 800, color: 'var(--rust)' }}>
            Modernex Stones LLP
          </div>
          <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8, color: 'var(--t3)', marginTop: 2 }}>
            GSTIN 33AABFM1234A1Z7 · Multi-HSN
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10, flexWrap: 'wrap', gap: 6 }}>
            <div>
              <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 7.5, color: 'var(--t3)', textTransform: 'uppercase' }}>Invoice</div>
              <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: 'var(--t1)', fontWeight: 500 }}>{invoice.id}</div>
            </div>
            <div>
              <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 7.5, color: 'var(--t3)', textTransform: 'uppercase' }}>Date</div>
              <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, color: 'var(--t1)', fontWeight: 500 }}>{invoice.date}</div>
            </div>
          </div>
        </div>
        <div style={{ padding: '12px 16px' }}>
          <div style={{ borderBottom: '1px solid var(--bd)', marginBottom: 10, paddingBottom: 9 }}>
            <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 7.5, letterSpacing: 1, textTransform: 'uppercase', color: 'var(--t3)', marginBottom: 3 }}>Bill To</div>
            <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 600, color: 'var(--t1)' }}>{invoice.customer_name}</div>
            {invoice.customer_gstin && <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8, color: 'var(--t3)', marginTop: 1 }}>GSTIN: {invoice.customer_gstin}</div>}
          </div>
          <div style={{ background: '#ffffff', borderRadius: 6, padding: 16, marginBottom: 12, textAlign: 'center' }}>
            <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8, letterSpacing: 1.5, textTransform: 'uppercase', color: '#666', marginBottom: 8 }}>
              Scan to Pay via UPI
            </div>
            <img src={qrUrl} alt={`UPI QR for ${invoice.id}`}
              style={{ width: 200, height: 200, display: 'block', margin: '0 auto' }}
              onError={e => { e.currentTarget.style.display = 'none'; }} />
            <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, color: '#333', marginTop: 8 }}>
              Amount: {fmtINR(invoice.total_paise)}
            </div>
            <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8, color: '#666', marginTop: 2 }}>
              Ref: {invoice.id}
            </div>
          </div>
          {invoice.irn && (
            <div style={{ background: 'var(--bg3)', borderRadius: 4, padding: '7px 10px', marginBottom: 10, border: '1px solid var(--bd)' }}>
              <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 7.5, letterSpacing: 1.5, textTransform: 'uppercase', color: 'var(--sage)', marginBottom: 2 }}>e-Invoice (IRP) · IRN</div>
              <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 7.5, color: 'var(--t2)', wordBreak: 'break-all', lineHeight: 1.5 }}>{invoice.irn}</div>
            </div>
          )}
          <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 9, borderTop: '1px solid var(--bd)' }}>
            <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: 'var(--t1)' }}>Grand Total</span>
            <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 14, color: 'var(--rust)' }}>{fmtINR(invoice.total_paise)}</span>
          </div>
        </div>
        <div style={{ padding: '10px 16px', borderTop: '1px solid var(--bd)', display: 'flex', gap: 7 }}>
          <button className="btn btn-s" style={{ flex: 1 }}
            onClick={() => window.open(`/api/invoices/${encodeURIComponent(invoice.id)}/pdf`, '_blank')}>
            PDF
          </button>
          <button className="btn btn-p" style={{ flex: 2 }} onClick={onClose}>Done ✓</button>
        </div>
      </div>
    </div>
  );
}
