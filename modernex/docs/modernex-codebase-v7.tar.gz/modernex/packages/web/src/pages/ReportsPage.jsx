import { useEffect, useState } from 'react';
import { api } from '../utils/api.js';
import { fmtINR, fmtINRCompact } from '../utils/format.js';
import { StatusBadge, StatCard } from '../components/Shared.jsx';

export function ReportsPage() {
  const [tab, setTab] = useState('sales');
  const [invoices, setInvoices] = useState([]);
  const [pnl, setPnl] = useState(null);
  const [gstr3b, setGstr3b] = useState(null);
  const [gstr1, setGstr1] = useState(null);
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    api.get('/invoices').then(d => setInvoices(d.invoices || []));
    api.get('/reports/dashboard').then(d => setSummary(d.summary));
    api.get('/reports/pnl').then(setPnl).catch(() => {});
    api.get('/reports/gstr3b').then(setGstr3b).catch(() => {});
    api.get('/reports/gstr1').then(setGstr1).catch(() => {});
  }, []);

  return (
    <div className="pw">
      <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
        <div>
          <div className="ph-title">Reports</div>
          <div className="ph-sub">MIS · P&L · GSTR</div>
        </div>
      </div>

      <div className="itabs">
        {['sales', 'pl', 'gstr'].map(k => (
          <div key={k} className={`itab${tab === k ? ' on' : ''}`} onClick={() => setTab(k)}>
            {{ sales: 'Sales', pl: 'P&L', gstr: 'GSTR' }[k]}
          </div>
        ))}
      </div>

      {tab === 'sales' && summary && (
        <>
          <div className="sc-grid">
            <StatCard label="Revenue" value={fmtINRCompact(summary.revenue_paise)} tone="r" />
            <StatCard label="GST Collected" value={fmtINRCompact(summary.gst_output_paise)} tone="g" />
            <StatCard label="Invoices" value={summary.invoice_count} tone="s" />
            <StatCard label="Avg Invoice"
              value={summary.invoice_count > 0 ? fmtINRCompact(summary.revenue_paise / summary.invoice_count) : '—'}
              tone="b" />
          </div>
          <div className="tw">
            <table className="dt">
              <thead><tr>
                <th>Invoice</th><th>Date</th><th>Customer</th>
                <th className="r">Taxable</th><th className="r">GST</th><th className="r">Total</th><th>Status</th>
              </tr></thead>
              <tbody>
                {invoices.map(i => (
                  <tr key={i.id}>
                    <td className="tdm">{i.id}</td><td>{i.date}</td>
                    <td className="tdc">{i.customer_name}</td>
                    <td className="tda">{fmtINR(i.taxable_paise)}</td>
                    <td style={{ textAlign: 'right', fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, padding: '8px 10px', color: 'var(--t2)' }}>
                      {fmtINR(i.cgst_paise + i.sgst_paise + i.igst_paise)}
                    </td>
                    <td className="tda">{fmtINR(i.total_paise)}</td>
                    <td><StatusBadge value={i.paid ? 'paid' : 'pending'} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {tab === 'pl' && pnl && (
        <div className="card" style={{ maxWidth: 440 }}>
          <div className="card-head"><span className="card-title">P&L Statement</span></div>
          <div className="card-body">
            {[
              ['INCOME', null, 'hd'],
              ['Revenue', pnl.income.revenue_paise, 'cr'],
              ['EXPENSES', null, 'hd'],
              ['Raw Material (COGS)', pnl.expenses.raw_material_paise, 'dr'],
              ['Production Labour+Power', pnl.expenses.production_paise, 'dr'],
              ['Transport & Freight', pnl.expenses.transport_paise, 'dr'],
              ['Overheads', pnl.expenses.overheads_paise, 'dr'],
              ['GROSS PROFIT', pnl.gross_profit_paise, 'gp'],
            ].map(([label, value, kind], i) => (
              kind === 'hd' ? (
                <div key={i} style={{
                  fontFamily: "'IBM Plex Mono', monospace", fontSize: 8,
                  letterSpacing: 2, textTransform: 'uppercase', color: 'var(--t3)',
                  padding: '8px 0 4px',
                }}>{label}</div>
              ) : (
                <div key={i} style={{
                  display: 'flex', justifyContent: 'space-between', padding: '7px 0',
                  borderBottom: kind === 'gp' ? 'none' : '1px solid var(--bd)',
                  borderTop: kind === 'gp' ? '2px solid var(--sageB)' : 'none',
                  fontFamily: kind === 'gp' ? "'Syne', sans-serif" : "'IBM Plex Mono', monospace",
                  fontSize: kind === 'gp' ? 13 : 11,
                  fontWeight: kind === 'gp' ? 700 : 'normal',
                  color: kind === 'gp' ? 'var(--sage)' : 'inherit',
                }}>
                  <span>{label}</span>
                  <span style={{ color: kind === 'cr' ? 'var(--gold)' : kind === 'gp' ? 'var(--sage)' : 'var(--t2)' }}>
                    {fmtINR(value)}
                  </span>
                </div>
              )
            ))}
            <div style={{ marginTop: 10, padding: '8px 10px', background: 'var(--sageW)',
              borderRadius: 4, fontFamily: "'IBM Plex Mono', monospace", fontSize: 10,
              color: 'var(--sage)', textAlign: 'right' }}>
              Margin: {pnl.margin_pct}%
            </div>
          </div>
        </div>
      )}

      {tab === 'gstr' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: 12 }}>
          {/* ─── GSTR-1 HSN breakdown ─── */}
          {gstr1 && (
            <div className="card">
              <div className="card-head">
                <span className="card-title">GSTR-1 — Outward HSN Split</span>
                <span className="bdg b-d">{(gstr1.hsn_breakdown || []).length} rates</span>
              </div>
              <div className="card-body">
                <table className="dt" style={{ fontSize: 10 }}>
                  <thead><tr>
                    <th>HSN</th>
                    <th style={{ textAlign: 'right' }}>Taxable</th>
                    <th style={{ textAlign: 'right' }}>CGST</th>
                    <th style={{ textAlign: 'right' }}>SGST</th>
                    <th style={{ textAlign: 'right' }}>IGST</th>
                  </tr></thead>
                  <tbody>
                    {(gstr1.hsn_breakdown || []).map(row => (
                      <tr key={row.hsn}>
                        <td style={{ fontFamily: "'IBM Plex Mono', monospace" }}>
                          {row.hsn}
                          <div style={{ fontSize: 7.5, color: 'var(--t3)' }}>
                            {row.hsn === '2515' ? 'Raw blocks' :
                             row.hsn === '2516' ? 'Worked stone' :
                             row.hsn === '2517' ? 'Chips/aggregates' : ''}
                            {' · '}
                            {row.hsn === '2517' ? '5%' : '12%'}
                          </div>
                        </td>
                        <td style={{ textAlign: 'right', fontFamily: "'IBM Plex Mono', monospace" }}>{fmtINR(row.taxable)}</td>
                        <td style={{ textAlign: 'right', fontFamily: "'IBM Plex Mono', monospace" }}>{fmtINR(row.cgst)}</td>
                        <td style={{ textAlign: 'right', fontFamily: "'IBM Plex Mono', monospace" }}>{fmtINR(row.sgst)}</td>
                        <td style={{ textAlign: 'right', fontFamily: "'IBM Plex Mono', monospace" }}>{fmtINR(row.igst)}</td>
                      </tr>
                    ))}
                    {(!gstr1.hsn_breakdown || gstr1.hsn_breakdown.length === 0) && (
                      <tr><td colSpan={5} style={{ textAlign: 'center', color: 'var(--t3)', padding: 20 }}>No invoices in range</td></tr>
                    )}
                  </tbody>
                </table>

                <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--bd)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 9, color: 'var(--t3)' }}>
                    <span>B2B ({gstr1.b2b?.count || 0})</span>
                    <span style={{ fontFamily: "'IBM Plex Mono', monospace" }}>{fmtINR(gstr1.b2b?.taxable || 0)}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 9, color: 'var(--t3)', marginTop: 3 }}>
                    <span>B2C ({gstr1.b2c?.count || 0})</span>
                    <span style={{ fontFamily: "'IBM Plex Mono', monospace" }}>{fmtINR(gstr1.b2c?.taxable || 0)}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ─── GSTR-3B ─── */}
          {gstr3b && (
            <div className="card">
              <div className="card-head">
                <span className="card-title">GSTR-3B — Current Period</span>
                <span className="bdg b-g">Multi-HSN</span>
              </div>
              <div className="card-body">
                {[
                  ['3.1(a) Outward Taxable', gstr3b['3_1_outward'].taxable, false],
                  ['CGST', gstr3b['3_1_outward'].cgst, false],
                  ['SGST', gstr3b['3_1_outward'].sgst, false],
                  ['IGST', gstr3b['3_1_outward'].igst, false],
                  ['ITC CGST', gstr3b['4_itc'].cgst_paise, false],
                  ['ITC SGST', gstr3b['4_itc'].sgst_paise, false],
                  ['Net GST Payable', gstr3b.net_payable.total_paise, true],
                ].map(([l, v, hi], i) => (
                  <div key={l} style={{
                    display: 'flex', justifyContent: 'space-between', padding: '7px 0',
                    borderBottom: i < 6 ? '1px solid var(--bd)' : 'none',
                    borderTop: hi ? '2px solid var(--rustB)' : 'none',
                    paddingTop: hi ? 9 : 7,
                  }}>
                    <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: hi ? 10 : 9, color: hi ? 'var(--t1)' : 'var(--t2)' }}>{l}</span>
                    <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: hi ? 12 : 10, color: hi ? 'var(--rust)' : 'var(--gold)' }}>
                      {fmtINR(v)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
