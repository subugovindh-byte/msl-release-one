import { useEffect, useState } from 'react';
import { api } from '../utils/api.js';
import { useAuth } from '../contexts/AuthContext.jsx';
import { useToast } from '../contexts/ToastContext.jsx';
import { StatusBadge } from '../components/Shared.jsx';

const KIND_LABEL = { upi: 'UPI', bank: 'Bank', both: 'UPI + Bank' };

export function CollectionAccountsPage() {
  const { user } = useAuth();
  const { notify } = useToast();
  const [accounts, setAccounts] = useState([]);
  const [modal, setModal] = useState(null);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(blankForm());

  const isAdmin = user?.role === 'admin';

  function blankForm() {
    return {
      name: '', kind: 'upi', upi_id: '', upi_name: '',
      account_number: '', ifsc: '', bank_name: '', branch: '',
      account_holder: '', account_type: 'current',
      notes: '', is_default: false,
    };
  }

  const load = () => api.get('/collection-accounts').then(d => setAccounts(d.accounts || []));
  useEffect(() => { load(); }, []);

  const upd = k => v => setForm(f => ({ ...f, [k]: v }));

  async function save(e) {
    e.preventDefault();
    try {
      const payload = { ...form };
      // Trim empty optional fields
      Object.keys(payload).forEach(k => {
        if (payload[k] === '' && k !== 'name') delete payload[k];
      });
      if (modal === 'new') {
        const { account } = await api.post('/collection-accounts', payload);
        notify(`${account.name} added`);
      } else {
        await api.patch(`/collection-accounts/${editing.id}`, payload);
        notify(`${editing.name} updated`);
      }
      setModal(null);
      setEditing(null);
      setForm(blankForm());
      load();
    } catch (err) {
      notify(err.message || 'Save failed', true);
    }
  }

  async function setDefault(id) {
    try {
      await api.post(`/collection-accounts/${id}/set-default`);
      notify('Default account updated');
      load();
    } catch (err) {
      notify(err.message, true);
    }
  }

  async function deactivate(acc) {
    if (!confirm(`Deactivate "${acc.name}"? It won't be available for new invoices.`)) return;
    try {
      await api.delete(`/collection-accounts/${acc.id}`);
      notify(`${acc.name} deactivated`);
      load();
    } catch (err) {
      notify(err.message, true);
    }
  }

  function openEdit(acc) {
    setEditing(acc);
    setForm({
      name: acc.name || '',
      kind: acc.kind,
      upi_id: acc.upi_id || '',
      upi_name: acc.upi_name || '',
      account_number: acc.account_number || '',
      ifsc: acc.ifsc || '',
      bank_name: acc.bank_name || '',
      branch: acc.branch || '',
      account_holder: acc.account_holder || '',
      account_type: acc.account_type || 'current',
      notes: acc.notes || '',
      is_default: !!acc.is_default,
    });
    setModal('edit');
  }

  return (
    <div className="pw">
      <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
        <div>
          <div className="ph-title">Collection Accounts</div>
          <div className="ph-sub">Where funds are received · UPI · Bank transfers</div>
        </div>
        {isAdmin && (
          <button className="btn btn-p btn-sm" onClick={() => { setForm(blankForm()); setModal('new'); }}>
            + New Account
          </button>
        )}
      </div>

      <div className="tw">
        <table className="dt">
          <thead>
            <tr>
              <th>ID</th><th>Name</th><th>Kind</th><th>UPI / Bank</th>
              <th>Status</th>{isAdmin && <th>Actions</th>}
            </tr>
          </thead>
          <tbody>
            {accounts.map(a => (
              <tr key={a.id}>
                <td className="tdm">{a.id}</td>
                <td className="tdc">
                  {a.name}
                  {a.is_default === 1 && (
                    <span className="bdg b-s" style={{ marginLeft: 6, fontSize: 7 }}>DEFAULT</span>
                  )}
                </td>
                <td><span className="bdg b-d">{KIND_LABEL[a.kind] || a.kind}</span></td>
                <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9.5 }}>
                  {a.upi_id && <div style={{ color: 'var(--gold)' }}>{a.upi_id}</div>}
                  {a.account_number_masked && (
                    <div style={{ color: 'var(--t2)', marginTop: 2 }}>
                      {a.bank_name} · {a.account_number_masked} · {a.ifsc}
                    </div>
                  )}
                </td>
                <td>
                  <StatusBadge value={a.active ? 'active' : 'inactive'} />
                </td>
                {isAdmin && (
                  <td style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                    <button className="btn btn-s btn-sm" onClick={() => openEdit(a)}>Edit</button>
                    {a.active && !a.is_default && (
                      <button className="btn btn-sage btn-sm" onClick={() => setDefault(a.id)}>
                        Set Default
                      </button>
                    )}
                    {a.active && (
                      <button className="btn btn-s btn-sm"
                        onClick={() => deactivate(a)}
                        style={{ color: 'var(--rust)' }}>
                        Deactivate
                      </button>
                    )}
                  </td>
                )}
              </tr>
            ))}
            {accounts.length === 0 && (
              <tr><td colSpan={isAdmin ? 6 : 5} style={{ textAlign: 'center', padding: 24, color: 'var(--t3)' }}>
                No collection accounts configured yet.
              </td></tr>
            )}
          </tbody>
        </table>
      </div>

      {modal && (
        <Modal onClose={() => { setModal(null); setEditing(null); }}
               title={modal === 'new' ? 'New Collection Account' : `Edit ${editing?.name}`}>
          <form onSubmit={save}>
            <div className="fg">
              <label className="fl">Display Name *</label>
              <input className="fi" required maxLength={100}
                value={form.name} onChange={e => upd('name')(e.target.value)}
                placeholder="e.g. HDFC Current — Main" />
            </div>
            <div className="fg">
              <label className="fl">Kind *</label>
              <select className="fsel" value={form.kind}
                onChange={e => upd('kind')(e.target.value)}
                disabled={modal === 'edit'}>
                <option value="upi">UPI only</option>
                <option value="bank">Bank only</option>
                <option value="both">UPI + Bank</option>
              </select>
            </div>

            {(form.kind === 'upi' || form.kind === 'both') && (
              <>
                <div className="fg2">
                  <div className="fg" style={{ marginBottom: 0 }}>
                    <label className="fl">UPI ID *</label>
                    <input className="fi" required={form.kind !== 'bank'}
                      value={form.upi_id} onChange={e => upd('upi_id')(e.target.value)}
                      placeholder="name@bank" />
                  </div>
                  <div className="fg" style={{ marginBottom: 0 }}>
                    <label className="fl">Payee Name</label>
                    <input className="fi" value={form.upi_name}
                      onChange={e => upd('upi_name')(e.target.value)}
                      placeholder="Shown in UPI app" />
                  </div>
                </div>
              </>
            )}

            {(form.kind === 'bank' || form.kind === 'both') && (
              <>
                <div className="fg" style={{ marginTop: 10 }}>
                  <label className="fl">Account Number *</label>
                  <input className="fi" required={form.kind !== 'upi'}
                    value={form.account_number}
                    onChange={e => upd('account_number')(e.target.value.replace(/\s/g, ''))} />
                </div>
                <div className="fg2">
                  <div className="fg" style={{ marginBottom: 0 }}>
                    <label className="fl">IFSC *</label>
                    <input className="fi" required={form.kind !== 'upi'} maxLength={11}
                      value={form.ifsc}
                      onChange={e => upd('ifsc')(e.target.value.toUpperCase())}
                      placeholder="HDFC0001234" />
                  </div>
                  <div className="fg" style={{ marginBottom: 0 }}>
                    <label className="fl">Type</label>
                    <select className="fsel" value={form.account_type}
                      onChange={e => upd('account_type')(e.target.value)}>
                      <option value="current">Current</option>
                      <option value="savings">Savings</option>
                      <option value="od">OD</option>
                      <option value="cc">CC</option>
                    </select>
                  </div>
                </div>
                <div className="fg2">
                  <div className="fg" style={{ marginBottom: 0 }}>
                    <label className="fl">Bank Name</label>
                    <input className="fi" value={form.bank_name}
                      onChange={e => upd('bank_name')(e.target.value)}
                      placeholder="HDFC Bank" />
                  </div>
                  <div className="fg" style={{ marginBottom: 0 }}>
                    <label className="fl">Branch</label>
                    <input className="fi" value={form.branch}
                      onChange={e => upd('branch')(e.target.value)}
                      placeholder="Krishnagiri" />
                  </div>
                </div>
                <div className="fg">
                  <label className="fl">Account Holder</label>
                  <input className="fi" value={form.account_holder}
                    onChange={e => upd('account_holder')(e.target.value)}
                    placeholder="Modernex Stones LLP" />
                </div>
              </>
            )}

            <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 8 }}>
              <input id="isDefault" type="checkbox" checked={form.is_default}
                onChange={e => upd('is_default')(e.target.checked)}
                style={{ accentColor: 'var(--rust)' }} />
              <label htmlFor="isDefault" style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, color: 'var(--t2)' }}>
                Set as default collection account
              </label>
            </div>

            <div className="fg" style={{ marginTop: 10 }}>
              <label className="fl">Notes</label>
              <input className="fi" maxLength={500} value={form.notes}
                onChange={e => upd('notes')(e.target.value)}
                placeholder="Internal notes (optional)" />
            </div>

            <div style={{ display: 'flex', gap: 7, marginTop: 14 }}>
              <button className="btn btn-p" type="submit">
                {modal === 'new' ? 'Create' : 'Save'}
              </button>
              <button className="btn btn-s" type="button" onClick={() => { setModal(null); setEditing(null); }}>
                Cancel
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

function Modal({ title, children, onClose }) {
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,.78)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 100, padding: 14, overflowY: 'auto',
    }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: 'var(--bg2)', border: '1px solid rgba(128,128,128,.15)',
        borderRadius: 10, width: '100%', maxWidth: 440,
      }}>
        <div style={{
          padding: '13px 16px', borderBottom: '1px solid var(--bd)',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: 'var(--t1)' }}>{title}</span>
          <button onClick={onClose} style={{ color: 'var(--t3)', fontSize: 15 }}>✕</button>
        </div>
        <div style={{ padding: '14px 16px' }}>
          {children}
        </div>
      </div>
    </div>
  );
}
