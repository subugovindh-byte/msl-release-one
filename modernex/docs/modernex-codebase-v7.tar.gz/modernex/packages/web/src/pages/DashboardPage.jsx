import { useEffect, useState } from 'react';
import { api } from '../utils/api.js';
import { fmtINRCompact } from '../utils/format.js';
import { StatCard } from '../components/Shared.jsx';

export function DashboardPage() {
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);

  useEffect(() => {
    api.get('/reports/dashboard')
      .then(setData)
      .catch(e => setErr(e.message));
  }, []);

  if (err) return <div className="pw"><div className="ph-title">Dashboard</div><p style={{ color: 'var(--rust)' }}>{err}</p></div>;
  if (!data) return <div className="pw"><div className="ph-title">Dashboard</div><p style={{ color: 'var(--t3)' }}>Loading…</p></div>;

  const s = data.summary;

  return (
    <div className="pw">
      <div className="ph-title">Dashboard</div>
      <div className="ph-sub">Real-time KPIs from SQLite</div>

      <div className="sc-grid">
        <StatCard label="Revenue (excl GST)" value={fmtINRCompact(s.revenue_paise)}
          sub={`${s.invoice_count} invoices`} tone="r" />
        <StatCard label="Receivables AR" value={fmtINRCompact(s.ar_paise)}
          sub={`${s.unpaid_count} unpaid · incl GST`} tone="g" />
        <StatCard label="Stock Value" value={fmtINRCompact(s.stock_value_paise)}
          sub={`${s.total_products || 0} products · all kinds`} tone="s" />
        <StatCard label="Low Stock" value={s.low_stock_count}
          sub="products ≤ 2" tone="b" />
      </div>

      <div className="sc-grid">
        <StatCard label="Collected" value={fmtINRCompact(s.collected_paise)}
          sub="Settled invoices" tone="s" />
        <StatCard label="Payables AP" value={fmtINRCompact(s.ap_paise)}
          sub="Incl GST" tone="r" />
        <StatCard label="GST Output" value={fmtINRCompact(s.gst_output_paise)}
          sub="Collected on sales" tone="g" />
        <StatCard label="Net GST Payable" value={fmtINRCompact(s.net_gst_paise)}
          sub="Output − ITC" tone="b" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 12 }}>
        {/* Product mix by kind */}
        {data.charts.byKind?.length > 0 && (
          <div className="card">
            <div className="card-head"><span className="card-title">Product Mix (Stock Value)</span></div>
            <div className="card-body">
              {(() => {
                const total = data.charts.byKind.reduce((x, k) => x + (k.value_paise || 0), 0);
                const KIND_LBL = {
                  block: 'Blocks', slab: 'Slabs', tile: 'Tiles', cts: 'Cut-to-Size',
                  strip: 'Strips', kerb: 'Kerbs', chips: 'Chips', dust: 'Dust', monument: 'Monuments',
                };
                const colours = ['var(--rust)', 'var(--gold)', 'var(--sage)', 'var(--blue)',
                                 'var(--rustB)', 'var(--goldB)', 'var(--sageB)', 'var(--blueB)', 'var(--t3)'];
                return data.charts.byKind.map((row, i) => {
                  const pct = total ? Math.round(((row.value_paise || 0) / total) * 100) : 0;
                  const colour = colours[i % colours.length];
                  return (
                    <div key={row.kind} style={{ marginBottom: 9 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between',
                        fontFamily: "'IBM Plex Mono', monospace", fontSize: 9.5, marginBottom: 3 }}>
                        <span style={{ color: colour }}>{KIND_LBL[row.kind] || row.kind}</span>
                        <span style={{ color: 'var(--t3)' }}>{fmtINRCompact(row.value_paise || 0)} · {pct}%</span>
                      </div>
                      <div style={{ height: 3, background: 'rgba(128,128,128,.1)', borderRadius: 2 }}>
                        <div style={{ height: 3, borderRadius: 2, width: `${pct}%`, background: colour }} />
                      </div>
                    </div>
                  );
                });
              })()}
            </div>
          </div>
        )}

        {/* Sales mix by kind (30d) */}
        {data.charts.salesByKind?.length > 0 && (
          <div className="card">
            <div className="card-head"><span className="card-title">Sales Mix — Last 30 Days</span></div>
            <div className="card-body">
              {(() => {
                const total = data.charts.salesByKind.reduce((x, k) => x + (k.revenue_paise || 0), 0);
                const KIND_LBL = {
                  block: 'Blocks', slab: 'Slabs', tile: 'Tiles', cts: 'Cut-to-Size',
                  strip: 'Strips', kerb: 'Kerbs', chips: 'Chips', dust: 'Dust', monument: 'Monuments',
                };
                return data.charts.salesByKind.map(row => {
                  const pct = total ? Math.round(((row.revenue_paise || 0) / total) * 100) : 0;
                  return (
                    <div key={row.kind || 'unknown'} style={{ marginBottom: 9 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between',
                        fontFamily: "'IBM Plex Mono', monospace", fontSize: 9.5, marginBottom: 3 }}>
                        <span style={{ color: 'var(--gold)' }}>{KIND_LBL[row.kind] || row.kind || '—'}</span>
                        <span style={{ color: 'var(--t3)' }}>{fmtINRCompact(row.revenue_paise || 0)} · {pct}%</span>
                      </div>
                      <div style={{ height: 3, background: 'rgba(128,128,128,.1)', borderRadius: 2 }}>
                        <div style={{ height: 3, borderRadius: 2, width: `${pct}%`, background: 'var(--gold)' }} />
                      </div>
                    </div>
                  );
                });
              })()}
            </div>
          </div>
        )}

        {/* Grade mix (slabs only) */}
        {data.charts.gradeMix?.length > 0 && (
          <div className="card">
            <div className="card-head"><span className="card-title">Slab Grade Mix</span></div>
            <div className="card-body">
              {data.charts.gradeMix.map(row => {
                const total = data.charts.gradeMix.reduce((x, g) => x + g.stock, 0);
                const pct = total ? Math.round((row.stock / total) * 100) : 0;
                const colour = { 'A+': 'var(--gold)', A: 'var(--sage)', B: 'var(--blue)' }[row.grade] || 'var(--t3)';
                return (
                  <div key={row.grade} style={{ marginBottom: 9 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between',
                      fontFamily: "'IBM Plex Mono', monospace", fontSize: 9.5, marginBottom: 3 }}>
                      <span style={{ color: colour }}>Grade {row.grade}</span>
                      <span style={{ color: 'var(--t3)' }}>{row.stock}pc · {pct}%</span>
                    </div>
                    <div style={{ height: 3, background: 'rgba(128,128,128,.1)', borderRadius: 2 }}>
                      <div style={{ height: 3, borderRadius: 2, width: `${pct}%`, background: colour }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
