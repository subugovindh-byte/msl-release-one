import { useEffect, useState } from 'react';
import { api } from '../utils/api.js';
import { useToast } from '../contexts/ToastContext.jsx';
import { fmtINR } from '../utils/format.js';
import { StatusBadge } from '../components/Shared.jsx';

const VARIETIES = ['Paradiso Classic', 'Paradiso Extra', 'Multicolour Red', 'Tan Brown',
  'Black Galaxy', 'Vizag Blue', 'Steel Grey', 'Absolute Black'];

export function PurchasePage() {
  const { notify } = useToast();
  const [tab, setTab] = useState('list');
  const [pos, setPos] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [form, setForm] = useState({
    vendor_id: '', variety: 'Paradiso Classic', blocks: '', cft: '',
    rate_per_cft: '', transport: '',
  });

  const load = () => api.get('/purchase').then(d => setPos(d.purchase_orders || []));
  useEffect(() => {
    load();
    api.get('/vendors').then(d => {
      setVendors(d.vendors || []);
      if (d.vendors?.[0]) setForm(f => ({ ...f, vendor_id: d.vendors[0].id }));
    });
  }, []);

  const upd = k => v => setForm(f => ({ ...f, [k]: v }));

  const amt = (+form.cft || 0) * (+form.rate_per_cft || 0) + (+form.transport || 0);
  const gst = amt * 0.12;

  async function submit(e) {
    e.preventDefault();
    try {
      const payload = {
        vendor_id: form.vendor_id,
        variety: form.variety,
        blocks: +form.blocks,
        cft: +form.cft,
        rate_per_cft_paise: Math.round(+form.rate_per_cft * 100),
        transport_paise: Math.round((+form.transport || 0) * 100),
      };
      const { po } = await api.post('/purchase', payload);
      notify(`${po.id} created`);
      setForm({ vendor_id: form.vendor_id, variety: 'Paradiso Classic', blocks: '', cft: '', rate_per_cft: '', transport: '' });
      setTab('list');
      load();
    } catch (err) {
      notify(err.message || 'Failed to create PO', true);
    }
  }

  return (
    <div className="pw">
      <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
        <div>
          <div className="ph-title">Purchase</div>
          <div className="ph-sub">Block procurement · POs</div>
        </div>
        <button className="btn btn-p btn-sm" onClick={() => setTab('new')}>+ New PO</button>
      </div>

      <div style={{
        borderLeft: '3px solid var(--gold)', background: 'var(--goldW)',
        padding: '9px 12px', borderRadius: '0 4px 4px 0',
        fontFamily: "'IBM Plex Mono', monospace", fontSize: 9.5, lineHeight: 1.7,
        color: 'var(--t2)', marginBottom: 12,
      }}>
        <b style={{ color: 'var(--t1)' }}>GST compliance: </b>
        ITC @12% on inward supply (HSN 2516). MSME vendors: payment within 45 days.
      </div>

      <div className="itabs">
        <div className={`itab${tab === 'list' ? ' on' : ''}`} onClick={() => setTab('list')}>PO List</div>
        <div className={`itab${tab === 'new' ? ' on' : ''}`} onClick={() => setTab('new')}>New PO</div>
      </div>

      {tab === 'list' && (
        <div className="tw">
          <table className="dt">
            <thead>
              <tr>
                <th>PO No</th><th>Date</th><th>Vendor</th><th>Variety</th><th>Blocks</th>
                <th className="r">Taxable</th><th className="r">GST</th><th className="r">Total</th><th>Status</th>
              </tr>
            </thead>
            <tbody>
              {pos.map(p => {
                const v = vendors.find(x => x.id === p.vendor_id);
                return (
                  <tr key={p.id}>
                    <td className="tdm">{p.id}</td>
                    <td>{p.date}</td>
                    <td className="tdc">
                      {v?.name || '—'}
                      {v?.msme === 1 && <span className="bdg b-b" style={{ marginLeft: 5, fontSize: 7 }}>MSME</span>}
                    </td>
                    <td>{p.variety}</td>
                    <td className="tdm">{p.blocks}</td>
                    <td className="tda">{fmtINR(p.taxable_paise)}</td>
                    <td className="tda" style={{ color: 'var(--sage)' }}>{fmtINR(p.gst_paise)}</td>
                    <td className="tda">{fmtINR(p.total_paise)}</td>
                    <td><StatusBadge value={p.status} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'new' && (
        <form onSubmit={submit} className="card" style={{ maxWidth: 500 }}>
          <div className="card-head"><span className="card-title">New Purchase Order</span></div>
          <div className="card-body">
            <div className="fg">
              <label className="fl">Vendor *</label>
              <select className="fsel" required value={form.vendor_id}
                onChange={e => upd('vendor_id')(e.target.value)}>
                {vendors.map(v => <option key={v.id} value={v.id}>{v.name}{v.msme ? ' (MSME)' : ''}</option>)}
              </select>
            </div>
            <div className="fg2">
              <div className="fg">
                <label className="fl">Variety *</label>
                <select className="fsel" value={form.variety}
                  onChange={e => upd('variety')(e.target.value)}>
                  {VARIETIES.map(v => <option key={v}>{v}</option>)}
                </select>
              </div>
              <div className="fg">
                <label className="fl">Blocks *</label>
                <input className="fi" type="number" min={1} required placeholder="6"
                  value={form.blocks} onChange={e => upd('blocks')(e.target.value)} />
              </div>
            </div>
            <div className="fg3">
              {[
                ['cft', 'Total CFT *', '180'],
                ['rate_per_cft', 'Rate/CFT ₹ *', '900'],
                ['transport', 'Transport ₹', '0'],
              ].map(([k, l, ph]) => (
                <div key={k} className="fg">
                  <label className="fl">{l}</label>
                  <input className="fi" type="number" step="0.01" placeholder={ph}
                    value={form[k]} onChange={e => upd(k)(e.target.value)} />
                </div>
              ))}
            </div>
            {amt > 0 && (
              <div style={{
                fontFamily: "'IBM Plex Mono', monospace", fontSize: 11,
                color: 'var(--gold)', margin: '11px 0',
              }}>
                Taxable: ₹{amt.toFixed(2)} · GST: ₹{gst.toFixed(2)} · Total: ₹{(amt + gst).toFixed(2)}
              </div>
            )}
            <div style={{ display: 'flex', gap: 7 }}>
              <button type="submit" className="btn btn-p">Create PO</button>
              <button type="button" className="btn btn-s" onClick={() => setTab('list')}>Cancel</button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
}
