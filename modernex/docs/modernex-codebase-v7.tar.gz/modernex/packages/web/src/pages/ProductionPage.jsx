import { useEffect, useMemo, useState } from 'react';
import { api } from '../utils/api.js';
import { useAuth } from '../contexts/AuthContext.jsx';
import { useToast } from '../contexts/ToastContext.jsx';
import { fmtINR } from '../utils/format.js';

const KIND_LABEL = {
  block: 'Block', slab: 'Slab', tile: 'Tile', cts: 'Cut-to-Size',
  strip: 'Strip', kerb: 'Kerb', chips: 'Chips', dust: 'Dust', monument: 'Monument',
};
const KIND_UOM = {
  block: 'cft', slab: 'sqft', tile: 'pc', cts: 'sqft',
  strip: 'rft', kerb: 'pc', chips: 'tonne', dust: 'tonne', monument: 'pc',
};
const KIND_ORDER = ['block', 'slab', 'tile', 'cts', 'strip', 'kerb', 'chips', 'dust', 'monument'];
const KIND_HSN = { block: '2515', chips: '2517', dust: '2517' };
// anything else defaults to 2516

export function ProductionPage() {
  const { user } = useAuth();
  const { notify } = useToast();
  const [jobs, setJobs] = useState([]);
  const [products, setProducts] = useState([]);
  const [stats, setStats] = useState(null);
  const [modal, setModal] = useState(false);

  const canCreate = user?.role === 'admin' || user?.role === 'yard';

  const load = () => {
    api.get('/production?limit=50').then(d => setJobs(d.jobs || []));
    api.get('/products?active=true').then(d => setProducts(d.products || []));
    api.get('/production/stats/summary').then(d => setStats(d.stats));
  };
  useEffect(load, []);

  return (
    <div className="pw">
      <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8, alignItems: 'flex-start' }}>
        <div>
          <div className="ph-title">Production Jobs</div>
          <div className="ph-sub">Block → Slab → Tile/CTS transformations · cost apportioned by output value</div>
        </div>
        {canCreate && (
          <button className="btn btn-p btn-sm" onClick={() => setModal(true)}>+ New Job</button>
        )}
      </div>

      {stats && (
        <div className="sc-grid" style={{ margin: '12px 0' }}>
          <StatCard label="Total Jobs (30d)" val={stats.total_jobs || 0} sub="" cls="g" />
          <StatCard label="Completed" val={stats.completed || 0} sub="" cls="s" />
          <StatCard label="In Progress" val={stats.in_progress || 0} sub="" cls="b" />
          <StatCard label="Conversion Cost" val={fmtINR(stats.total_conversion_cost || 0)} sub="30d" cls="r" />
        </div>
      )}

      <div className="tw">
        <table className="dt">
          <thead><tr>
            <th>Job</th><th>Date</th><th>Stage</th><th>Inputs</th><th>Outputs</th>
            <th>Yield %</th><th>Costs</th><th>Status</th>
          </tr></thead>
          <tbody>
            {jobs.map(j => (
              <tr key={j.id}>
                <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9 }}>{j.id}</td>
                <td>{j.date}</td>
                <td><span className="bdg b-d">{j.stage}</span></td>
                <td style={{ fontSize: 9 }}>
                  {j.inputs?.map(i => (
                    <div key={i.product_id} style={{ fontFamily: "'IBM Plex Mono', monospace" }}>
                      {i.kind}/{i.variety} × {i.qty_consumed} {i.uom}
                    </div>
                  )) || '—'}
                </td>
                <td style={{ fontSize: 9 }}>
                  {j.outputs?.length ? j.outputs.map(o => (
                    <div key={o.product_id} style={{ fontFamily: "'IBM Plex Mono', monospace" }}>
                      {o.kind}/{o.variety} × {o.qty_produced} {o.uom}
                    </div>
                  )) : <span style={{ color: 'var(--t3)' }}>(in progress)</span>}
                </td>
                <td>{j.yield_pct ? j.yield_pct + '%' : '—'}</td>
                <td style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9 }}>
                  {fmtINR((j.labour_paise || 0) + (j.power_paise || 0) + (j.consumables_paise || 0))}
                </td>
                <td><span className={`bdg ${j.status === 'Complete' ? 'b-s' : 'b-g'}`}>{j.status}</span></td>
              </tr>
            ))}
            {!jobs.length && (
              <tr><td colSpan={8} style={{ textAlign: 'center', padding: 30, color: 'var(--t3)' }}>
                No production jobs yet
              </td></tr>
            )}
          </tbody>
        </table>
      </div>

      {modal && (
        <NewJobModal products={products}
          onClose={() => setModal(false)}
          onSaved={() => { setModal(false); load(); notify('Job created'); }}
          onError={msg => notify(msg, true)} />
      )}
    </div>
  );
}

function StatCard({ label, val, sub, cls }) {
  const c = { g: 'var(--gold)', s: 'var(--sage)', b: 'var(--blue)', r: 'var(--rust)' }[cls] || 'var(--t1)';
  return (
    <div style={{ background: 'var(--bg2)', border: '1px solid var(--bd)', borderRadius: 5, padding: 10, borderLeft: `3px solid ${c}` }}>
      <div style={{ fontSize: 8, color: 'var(--t3)', textTransform: 'uppercase', letterSpacing: 1, fontFamily: "'IBM Plex Mono', monospace" }}>{label}</div>
      <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--t1)', marginTop: 2, fontFamily: "'Syne', sans-serif" }}>{val}</div>
      {sub && <div style={{ fontSize: 8, color: 'var(--t3)', fontFamily: "'IBM Plex Mono', monospace", marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

// ─── New transformation job modal ───
function NewJobModal({ products, onClose, onSaved, onError }) {
  const [lotId, setLotId] = useState('');
  const [stage, setStage] = useState('polish');
  const [labour, setLabour] = useState(0);
  const [power, setPower] = useState(0);
  const [consumables, setConsumables] = useState(0);
  const [yieldPct, setYieldPct] = useState('');
  const [notes, setNotes] = useState('');
  const [inputs, setInputs] = useState([]);     // [{product_id, qty_consumed}]
  const [outputs, setOutputs] = useState([]);   // [{kind, variety, grade, rate_paise, qty, dimensions}]
  const [saving, setSaving] = useState(false);

  const availProducts = products.filter(p => p.stock > 0);
  const inputCostPaise = useMemo(() => {
    return inputs.reduce((s, i) => {
      const p = products.find(x => x.id === i.product_id);
      if (!p) return s;
      return s + Math.round((p.unit_cost_paise ?? p.rate_paise) * (i.qty_consumed || 0));
    }, 0);
  }, [inputs, products]);
  const conversionCost = Number(labour || 0) * 100 + Number(power || 0) * 100 + Number(consumables || 0) * 100;
  const totalCost = inputCostPaise + conversionCost;
  const totalOutputValue = outputs.reduce((s, o) =>
    s + Math.round((o.rate_paise || 0) * (o.qty || 0)), 0);

  const addInput = () => setInputs([...inputs, { product_id: '', qty_consumed: 1 }]);
  const setInput = (idx, key, val) => setInputs(inputs.map((i, x) => x === idx ? { ...i, [key]: val } : i));
  const removeInput = (idx) => setInputs(inputs.filter((_, i) => i !== idx));

  const addOutput = () => setOutputs([...outputs, {
    kind: 'slab', variety: inputs[0] ? (products.find(p => p.id === inputs[0].product_id)?.variety || '') : '',
    grade: 'A', rate_paise: 0, qty: 1, dimensions: {}
  }]);
  const setOutput = (idx, key, val) => setOutputs(outputs.map((o, x) => x === idx ? { ...o, [key]: val } : o));
  const setOutputDim = (idx, key, val) => setOutputs(outputs.map((o, x) =>
    x === idx ? { ...o, dimensions: { ...o.dimensions, [key]: val } } : o));
  const removeOutput = (idx) => setOutputs(outputs.filter((_, i) => i !== idx));

  async function submit() {
    if (!lotId) { onError('Lot ID required'); return; }
    if (!inputs.length) { onError('At least one input required'); return; }
    if (inputs.some(i => !i.product_id || !i.qty_consumed)) { onError('Fill all input fields'); return; }
    setSaving(true);
    try {
      const payload = {
        lot_id: lotId,
        stage,
        labour_paise: Math.round(Number(labour || 0) * 100),
        power_paise: Math.round(Number(power || 0) * 100),
        consumables_paise: Math.round(Number(consumables || 0) * 100),
        yield_pct: yieldPct ? Number(yieldPct) : undefined,
        notes: notes || undefined,
        inputs: inputs.map(i => ({ product_id: i.product_id, qty_consumed: Number(i.qty_consumed) })),
        outputs: outputs.map(o => ({
          kind: o.kind,
          variety: o.variety,
          grade: o.grade || undefined,
          rate_paise: Math.round(Number(o.rate_paise) || 0),
          qty: Number(o.qty),
          dimensions: o.dimensions || {},
          hsn: KIND_HSN[o.kind] || '2516',
          uom: KIND_UOM[o.kind],
        })),
      };
      await api.post('/production', payload);
      onSaved();
    } catch (err) {
      onError(err.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Overlay title="New Production Job" onClose={onClose}>
      <div className="fg2">
        <div className="fg" style={{ marginBottom: 0 }}>
          <label className="fl">Lot ID *</label>
          <input className="fi" value={lotId} onChange={e => setLotId(e.target.value)} placeholder="LOT-030" />
        </div>
        <div className="fg" style={{ marginBottom: 0 }}>
          <label className="fl">Stage</label>
          <select className="fsel" value={stage} onChange={e => setStage(e.target.value)}>
            <option value="split">Split</option>
            <option value="cut">Cut</option>
            <option value="polish">Polish</option>
            <option value="done">Done</option>
          </select>
        </div>
      </div>

      {/* Inputs */}
      <div style={{ margin: '14px 0 4px', padding: '8px 10px',
        background: 'var(--bg3)', borderRadius: 5, border: '1px solid var(--bd)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
          <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8, letterSpacing: 1.2, textTransform: 'uppercase', color: 'var(--t3)' }}>
            Inputs (consumed)
          </span>
          <button type="button" className="btn btn-s btn-sm" onClick={addInput}>+ Input</button>
        </div>
        {inputs.length === 0 && (
          <div style={{ fontSize: 9, color: 'var(--t3)', padding: 6 }}>No inputs yet</div>
        )}
        {inputs.map((inp, idx) => {
          const p = products.find(x => x.id === inp.product_id);
          return (
            <div key={idx} style={{ display: 'flex', gap: 6, marginBottom: 4, alignItems: 'center' }}>
              <select className="fsel" style={{ flex: 2, fontSize: 10, padding: '4px' }}
                value={inp.product_id} onChange={e => setInput(idx, 'product_id', e.target.value)}>
                <option value="">— pick product —</option>
                {availProducts.map(pp => (
                  <option key={pp.id} value={pp.id}>
                    {pp.id} · {KIND_LABEL[pp.kind]}/{pp.variety} ({pp.stock} {KIND_UOM[pp.kind]})
                  </option>
                ))}
              </select>
              <input type="number" min="0.01" step="0.01" value={inp.qty_consumed}
                onChange={e => setInput(idx, 'qty_consumed', e.target.value)}
                style={{ width: 70, fontSize: 10, padding: '4px', background: 'var(--bg2)',
                  border: '1px solid var(--bd)', borderRadius: 3, color: 'var(--t1)', fontFamily: "'IBM Plex Mono', monospace" }} />
              <span style={{ fontSize: 8, color: 'var(--t3)', minWidth: 30 }}>
                {p ? KIND_UOM[p.kind] : 'qty'}
              </span>
              <button type="button" className="btn btn-s btn-sm" onClick={() => removeInput(idx)}>✕</button>
            </div>
          );
        })}
      </div>

      {/* Outputs */}
      <div style={{ margin: '8px 0 4px', padding: '8px 10px',
        background: 'var(--bg3)', borderRadius: 5, border: '1px solid var(--bd)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
          <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 8, letterSpacing: 1.2, textTransform: 'uppercase', color: 'var(--t3)' }}>
            Outputs (new products created)
          </span>
          <button type="button" className="btn btn-s btn-sm" onClick={addOutput}>+ Output</button>
        </div>
        {outputs.length === 0 && (
          <div style={{ fontSize: 9, color: 'var(--t3)', padding: 6 }}>
            No outputs yet — job will be saved as "In Progress"
          </div>
        )}
        {outputs.map((out, idx) => (
          <div key={idx} style={{ border: '1px solid var(--bd)', borderRadius: 4, padding: 6, marginBottom: 5 }}>
            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              <select className="fsel" style={{ flex: 1, fontSize: 10, padding: '4px' }}
                value={out.kind} onChange={e => setOutput(idx, 'kind', e.target.value)}>
                {KIND_ORDER.map(k => <option key={k} value={k}>{KIND_LABEL[k]}</option>)}
              </select>
              <input className="fi" style={{ flex: 2, fontSize: 10, padding: '4px' }}
                value={out.variety} onChange={e => setOutput(idx, 'variety', e.target.value)}
                placeholder="Variety" />
              <select className="fsel" style={{ width: 55, fontSize: 10, padding: '4px' }}
                value={out.grade || ''} onChange={e => setOutput(idx, 'grade', e.target.value)}>
                <option value="">—</option><option>A+</option><option>A</option><option>B</option>
              </select>
              <button type="button" className="btn btn-s btn-sm" onClick={() => removeOutput(idx)}>✕</button>
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 7, color: 'var(--t3)' }}>Rate ₹/{KIND_UOM[out.kind]}</div>
                <input type="number" min="0" step="0.01"
                  value={(out.rate_paise / 100).toFixed(2)}
                  onChange={e => setOutput(idx, 'rate_paise', Math.round(Number(e.target.value) * 100))}
                  style={{ width: '100%', fontSize: 10, padding: '4px', background: 'var(--bg2)',
                    border: '1px solid var(--bd)', borderRadius: 3, color: 'var(--t1)', fontFamily: "'IBM Plex Mono', monospace" }} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 7, color: 'var(--t3)' }}>Quantity (pc)</div>
                <input type="number" min="0.01" step="0.01" value={out.qty}
                  onChange={e => setOutput(idx, 'qty', e.target.value)}
                  style={{ width: '100%', fontSize: 10, padding: '4px', background: 'var(--bg2)',
                    border: '1px solid var(--bd)', borderRadius: 3, color: 'var(--t1)', fontFamily: "'IBM Plex Mono', monospace" }} />
              </div>
              {['slab', 'tile'].includes(out.kind) && (
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 7, color: 'var(--t3)' }}>Size L×W mm</div>
                  <input value={out.dimensions?.size_lw || ''}
                    onChange={e => setOutputDim(idx, 'size_lw', e.target.value)}
                    placeholder="2600×1600"
                    style={{ width: '100%', fontSize: 10, padding: '4px', background: 'var(--bg2)',
                      border: '1px solid var(--bd)', borderRadius: 3, color: 'var(--t1)', fontFamily: "'IBM Plex Mono', monospace" }} />
                </div>
              )}
              {['slab', 'tile', 'cts', 'strip'].includes(out.kind) && (
                <div style={{ flex: 0.5 }}>
                  <div style={{ fontSize: 7, color: 'var(--t3)' }}>Thk mm</div>
                  <input type="number" value={out.dimensions?.thickness_mm || ''}
                    onChange={e => setOutputDim(idx, 'thickness_mm', Number(e.target.value))}
                    style={{ width: '100%', fontSize: 10, padding: '4px', background: 'var(--bg2)',
                      border: '1px solid var(--bd)', borderRadius: 3, color: 'var(--t1)', fontFamily: "'IBM Plex Mono', monospace" }} />
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Conversion costs */}
      <div className="fg2">
        <div className="fg" style={{ marginBottom: 0 }}>
          <label className="fl">Labour ₹</label>
          <input className="fi" type="number" min="0" value={labour} onChange={e => setLabour(e.target.value)} />
        </div>
        <div className="fg" style={{ marginBottom: 0 }}>
          <label className="fl">Power ₹</label>
          <input className="fi" type="number" min="0" value={power} onChange={e => setPower(e.target.value)} />
        </div>
      </div>
      <div className="fg2">
        <div className="fg" style={{ marginBottom: 0 }}>
          <label className="fl">Consumables ₹</label>
          <input className="fi" type="number" min="0" value={consumables} onChange={e => setConsumables(e.target.value)} />
        </div>
        <div className="fg" style={{ marginBottom: 0 }}>
          <label className="fl">Yield %</label>
          <input className="fi" type="number" min="0" max="100" value={yieldPct}
            onChange={e => setYieldPct(e.target.value)} placeholder="29" />
        </div>
      </div>

      {/* Cost summary */}
      <div style={{ margin: '10px 0', padding: '8px 10px', background: 'var(--bg3)', borderRadius: 5, fontSize: 10, fontFamily: "'IBM Plex Mono', monospace" }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--t3)' }}>
          <span>Input cost (FIFO)</span><span>{fmtINR(inputCostPaise)}</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--t3)' }}>
          <span>Conversion cost</span><span>{fmtINR(conversionCost)}</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--t1)', fontWeight: 600, marginTop: 4, paddingTop: 4, borderTop: '1px solid var(--bd)' }}>
          <span>Total cost</span><span>{fmtINR(totalCost)}</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--gold)', marginTop: 2 }}>
          <span>Expected output value</span><span>{fmtINR(totalOutputValue)}</span>
        </div>
        {totalOutputValue > 0 && (
          <div style={{ display: 'flex', justifyContent: 'space-between', color: totalOutputValue > totalCost ? 'var(--sage)' : 'var(--rust)', marginTop: 2 }}>
            <span>Margin (pre-GST)</span>
            <span>{fmtINR(totalOutputValue - totalCost)} ({(((totalOutputValue - totalCost) / totalOutputValue) * 100).toFixed(1)}%)</span>
          </div>
        )}
      </div>

      <div className="fg">
        <label className="fl">Notes</label>
        <input className="fi" value={notes} onChange={e => setNotes(e.target.value)} maxLength={500} />
      </div>

      <div style={{ display: 'flex', gap: 7, marginTop: 14 }}>
        <button className="btn btn-p" onClick={submit} disabled={saving}>
          {saving ? 'Saving…' : 'Create Job'}
        </button>
        <button className="btn btn-s" onClick={onClose}>Cancel</button>
      </div>
    </Overlay>
  );
}

function Overlay({ title, children, onClose }) {
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,.78)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 100, padding: 14, overflowY: 'auto',
    }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: 'var(--bg2)', border: '1px solid rgba(128,128,128,.15)',
        borderRadius: 10, width: '100%', maxWidth: 680,
      }}>
        <div style={{ padding: '13px 16px', borderBottom: '1px solid var(--bd)',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 700, color: 'var(--t1)' }}>{title}</span>
          <button onClick={onClose} style={{ color: 'var(--t3)', fontSize: 15 }}>✕</button>
        </div>
        <div style={{ padding: '14px 16px' }}>{children}</div>
      </div>
    </div>
  );
}
