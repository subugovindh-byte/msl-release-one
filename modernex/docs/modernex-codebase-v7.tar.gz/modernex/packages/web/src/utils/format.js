// ═══════════════════════════════════════
// FRONTEND HELPERS
// ═══════════════════════════════════════

export const fmtINR = (paise) => {
  const rupees = (paise || 0) / 100;
  return '₹\u202f' + new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: 2, maximumFractionDigits: 2,
  }).format(rupees);
};

export const fmtINRCompact = (paise) => {
  const r = (paise || 0) / 100;
  if (r >= 1e7) return '₹' + (r / 1e7).toFixed(2) + 'Cr';
  if (r >= 1e5) return '₹' + (r / 1e5).toFixed(2) + 'L';
  if (r >= 1e3) return '₹' + (r / 1e3).toFixed(1) + 'K';
  return '₹' + r.toFixed(0);
};

export const fmtDate = (iso) => {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('en-IN',
    { day: '2-digit', month: 'short', year: 'numeric' });
};

export const today = () => new Date().toISOString().slice(0, 10);
