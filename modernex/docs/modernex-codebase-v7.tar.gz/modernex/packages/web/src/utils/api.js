// ═══════════════════════════════════════
// API CLIENT — fetch wrapper with auth + error handling
// ═══════════════════════════════════════

const BASE = '/api';

class APIError extends Error {
  constructor(message, status, code, details) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

async function request(method, path, body, options = {}) {
  const opts = {
    method,
    credentials: 'include',  // send cookies for auth
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  };
  if (body !== undefined) opts.body = JSON.stringify(body);

  let res;
  try {
    res = await fetch(BASE + path, opts);
  } catch (err) {
    throw new APIError('Network error', 0, 'NETWORK_ERROR');
  }

  let data = null;
  const ct = res.headers.get('content-type');
  if (ct?.includes('application/json')) {
    try { data = await res.json(); }
    catch { /* empty body */ }
  }

  if (!res.ok) {
    // Attempt token refresh on 401 (but not on /auth routes to avoid loops)
    if (res.status === 401 && !path.startsWith('/auth') && !options._retry) {
      const refreshed = await tryRefresh();
      if (refreshed) {
        return request(method, path, body, { ...options, _retry: true });
      }
    }
    throw new APIError(
      data?.error || res.statusText,
      res.status,
      data?.code || 'HTTP_ERROR',
      data?.details
    );
  }
  return data;
}

let _refreshing = null;
async function tryRefresh() {
  if (_refreshing) return _refreshing;
  _refreshing = fetch(BASE + '/auth/refresh', {
    method: 'POST',
    credentials: 'include',
  }).then(r => r.ok).catch(() => false).finally(() => {
    _refreshing = null;
  });
  return _refreshing;
}

export const api = {
  get: (path) => request('GET', path),
  post: (path, body) => request('POST', path, body),
  patch: (path, body) => request('PATCH', path, body),
  delete: (path) => request('DELETE', path),
};

export { APIError };
