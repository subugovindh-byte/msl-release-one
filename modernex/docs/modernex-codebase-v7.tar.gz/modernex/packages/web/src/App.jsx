import { Routes, Route, Navigate, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext.jsx';
import { useTheme } from './contexts/ThemeContext.jsx';
import { useToast } from './contexts/ToastContext.jsx';
import { LoginPage } from './pages/LoginPage.jsx';
import { DashboardPage } from './pages/DashboardPage.jsx';
import { POSPage } from './pages/POSPage.jsx';
import { InventoryPage } from './pages/InventoryPage.jsx';
import { ProductionPage } from './pages/ProductionPage.jsx';
import { PurchasePage } from './pages/PurchasePage.jsx';
import { AccountsPage } from './pages/AccountsPage.jsx';
import { ReportsPage } from './pages/ReportsPage.jsx';
import { MastersPage } from './pages/MastersPage.jsx';
import { CollectionAccountsPage } from './pages/CollectionAccountsPage.jsx';
import { UsersPage } from './pages/UsersPage.jsx';
import { SystemPage } from './pages/SystemPage.jsx';
import { VarietyPhotosPage } from './pages/VarietyPhotosPage.jsx';

const CO = 'Modernex Stones LLP';
const GSTIN = '33AABFM1234A1Z7';
const HSN = '2516';

const NAV = [
  { sec: 'Operations' },
  { id: 'pos',         path: '/pos',         lbl: 'POS',        icon: '[P]' },
  { id: 'inventory',   path: '/inventory',   lbl: 'Inventory',  icon: '[I]' },
  { id: 'production',  path: '/production',  lbl: 'Production', icon: '[G]' },
  { sec: 'Finance' },
  { id: 'purchase',    path: '/purchase',    lbl: 'Purchase',   icon: '[$]' },
  { id: 'accounts',    path: '/accounts',    lbl: 'Accounts',   icon: '[A]' },
  { id: 'reports',     path: '/reports',     lbl: 'Reports',    icon: '[R]' },
  { sec: 'Setup' },
  { id: 'masters',       path: '/masters',       lbl: 'Masters',         icon: '[M]' },
  { id: 'variety-photos',path: '/variety-photos',lbl: 'Variety Photos',  icon: '[V]' },
  { id: 'accounts-cfg',  path: '/accounts-cfg',  lbl: 'Bank/UPI',        icon: '[B]' },
  { id: 'users',         path: '/users',         lbl: 'Users',           icon: '[U]' },
  { id: 'system',        path: '/system',        lbl: 'System',          icon: '[S]' },
];

function today() {
  return new Date().toLocaleDateString('en-IN',
    { day: '2-digit', month: 'short', year: 'numeric' });
}

export function App() {
  const { user, loading, logout } = useAuth();
  const { theme, toggle } = useTheme();
  const { notify } = useToast();
  const navigate = useNavigate();

  if (loading) {
    return <div style={{
      flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: "'IBM Plex Mono', monospace", color: 'var(--t3)', fontSize: 11,
    }}>Loading…</div>;
  }

  if (!user) {
    return (
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    );
  }

  const handleLogout = async () => {
    await logout();
    notify('Signed out');
    navigate('/login');
  };

  return (
    <>
      <div className="topbar">
        <div>
          <div className="tb-brand">{CO}</div>
          <div className="tb-sub">GST {GSTIN} · HSN {HSN} · FY 2025-26</div>
        </div>
        <div className="tb-right">
          <span className="chip">{today()}</span>
          <button className="theme-btn" onClick={toggle} aria-label="Toggle theme">
            <span>{theme === 'dark' ? '☀' : '🌙'}</span>
            <span>{theme === 'dark' ? ' Day' : ' Night'}</span>
          </button>
        </div>
      </div>

      <div className="body-wrap">
        <div className="sidebar">
          <div className="sb-user">
            <div className="sb-av">{user.fullName?.[0] || user.username[0]}</div>
            <div>
              <div className="sb-name">{user.fullName || user.username}</div>
              <div className="sb-role">{user.role}</div>
            </div>
          </div>

          {NAV.map((item, i) =>
            item.sec ? (
              <div key={i} className="sb-sec">{item.sec}</div>
            ) : (
              <NavLink
                key={item.id}
                to={item.path}
                className={({ isActive }) => `sb-item${isActive ? ' active' : ''}`}
              >
                <span className="sb-icon">{item.icon}</span>
                <span className="sb-label">{item.lbl}</span>
              </NavLink>
            )
          )}

          <div className="sb-foot">
            <div className="sb-foot-txt">
              SQLite WAL · Azure Blob<br />
              JWT · bcrypt r=12<br />
              GST 2024 · WCAG 2.2
            </div>
            <button className="sb-logout" onClick={handleLogout}>⎋ Sign Out</button>
          </div>
        </div>

        <div className="page-area">
          <Routes>
            <Route path="/" element={<Navigate to="/pos" />} />
            <Route path="/login" element={<Navigate to="/pos" />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/pos" element={<POSPage />} />
            <Route path="/inventory" element={<InventoryPage />} />
            <Route path="/production" element={<ProductionPage />} />
            <Route path="/purchase" element={<PurchasePage />} />
            <Route path="/accounts" element={<AccountsPage />} />
            <Route path="/reports" element={<ReportsPage />} />
            <Route path="/masters" element={<MastersPage />} />
            <Route path="/variety-photos" element={<VarietyPhotosPage />} />
            <Route path="/accounts-cfg" element={<CollectionAccountsPage />} />
            <Route path="/users" element={<UsersPage />} />
            <Route path="/system" element={<SystemPage />} />
            <Route path="*" element={<Navigate to="/pos" />} />
          </Routes>
        </div>
      </div>
    </>
  );
}
