import { createContext, useContext, useState, useCallback } from 'react';
import { createPortal } from 'react-dom';

const ToastCtx = createContext(null);

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const notify = useCallback((msg, err = false) => {
    const id = Date.now() + Math.random();
    setToasts(t => [...t, { id, msg, err }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3200);
  }, []);

  return (
    <ToastCtx.Provider value={{ notify }}>
      {children}
      {createPortal(
        <div className="toast-area">
          {toasts.map(t => (
            <div key={t.id} className={`toast ${t.err ? 'err' : ''}`}>
              {t.msg}
            </div>
          ))}
        </div>,
        document.body
      )}
    </ToastCtx.Provider>
  );
}

export const useToast = () => useContext(ToastCtx);
