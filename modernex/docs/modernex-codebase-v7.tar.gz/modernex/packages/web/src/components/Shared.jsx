const MAP = {
  paid: 'b-s', pending: 'b-r', received: 'b-s', approved: 'b-b',
  new: 'b-g', 'In Progress': 'b-g', Complete: 'b-s', overdue: 'b-r',
  receipt: 'b-s', payment: 'b-r', cancelled: 'b-r', draft: 'b-d',
  split: 'b-g', cut: 'b-b', polish: 'b-s', done: 'b-r',
};

export function StatusBadge({ value }) {
  return <span className={`bdg ${MAP[value] || 'b-d'}`}>{value}</span>;
}

export function StatCard({ label, value, sub, tone = 'r' }) {
  return (
    <div className={`sc ${tone}`}>
      <div className="sc-lbl">{label}</div>
      <div className="sc-val">{value}</div>
      {sub && <div className="sc-sub">{sub}</div>}
    </div>
  );
}
