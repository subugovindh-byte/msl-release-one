# Modernex Stones LLP — Accounts & Operations System v2.0

Production-ready accounts, inventory, production, and GST compliance system for a granite quarry operation. Built with Node.js + Express + SQLite (WAL) backend and React + Vite frontend, deployable to Azure App Service.

## Architecture

- **Backend**: Node.js 20 · Express 5 · better-sqlite3 · JWT · bcrypt · Zod · Azure Blob
- **Frontend**: React 18 · Vite 5 · CSS variables theming (day/night)
- **Database**: SQLite WAL · FIFO inventory · audit triggers · 4-tier backup
- **Cloud**: Azure App Service B2 · Blob Storage · Key Vault · App Insights (India South)

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Set up environment
cp .env.example .env
# Edit .env with your values

# 3. Run database migrations + seed
npm run migrate -w @modernex/api

# 4. Start dev servers (API + web concurrently)
npm run dev

# Web app: http://localhost:5173
# API:     http://localhost:8080
```

## Workspace Structure

```
modernex/
├── packages/
│   ├── api/         # Node.js Express API
│   ├── web/         # React frontend
│   └── shared/      # Shared TypeScript types + GST logic
├── scripts/         # Backup/restore utilities
└── .github/         # CI/CD workflows
```

## Features

### Operations
- **POS**: Slab catalog with filters, cart, discount, customer GSTIN-aware invoicing
- **Inventory**: 12+ granite varieties, FIFO stock, low-stock alerts, value tracking
- **Production**: Split → Cut → Polish job cards with labour/power/consumables tracking

### Finance
- **Purchase**: Block procurement POs with MSME flag, GST ITC tracking
- **Accounts**: AR/AP ledgers, GST (CGST/SGST/IGST auto-detect), payment receipts
- **Reports**: Sales MIS, P&L, GSTR-1 and GSTR-3B worksheets

### Setup
- **Masters**: Customer/vendor management with GSTIN validation
- **System**: 4-tier backup (WAL → event → scheduled → manual), auth, compliance

### Compliance
- GST Act 2017 / e-Invoice 2024 (IRN + e-Way Bill)
- MSMED Act 2006 (45-day payment rule)
- IT Act 2000 (immutable audit trail)
- IndAS 2 / IndAS 115 (FIFO + revenue recognition)

## Deployment

See [`ModernexDeployment.html`](../ModernexDeployment.html) for the full Azure deployment spec, including CLI commands, cost breakdown, and rollout plan.

Quick deploy:
```bash
# After setting up Azure resources per the spec
git push origin main   # Triggers GitHub Actions → slot swap deploy
```

## Testing

```bash
npm test              # All tests
npm test -w @modernex/api   # API tests only (Vitest + Supertest)
npm test -w @modernex/web   # Frontend tests only
```

## Scripts

```bash
npm run dev           # Dev servers (api:8080, web:5173)
npm run build         # Production build
npm run migrate       # Run DB migrations
npm run backup        # Trigger Blob backup
npm run restore -- 2025-04-15   # Restore from date
```

## Default Demo Accounts (dev seed)

| Username  | Password    | Role       |
|-----------|-------------|------------|
| admin     | admin123    | admin      |
| accounts  | accounts123 | accounts   |
| yard      | yard123     | yard       |
| sales     | sales123    | sales      |

**⚠️ Change all passwords before production deployment.**

## License

Proprietary — © 2025 Modernex Stones LLP
