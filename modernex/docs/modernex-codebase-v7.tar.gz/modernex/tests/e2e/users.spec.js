import { test, expect } from '@playwright/test';

async function login(page, user = 'admin', pw = 'admin123') {
  await page.goto('/login');
  await page.getByLabel('Username').fill(user);
  await page.getByLabel('Password').fill(pw);
  await page.getByRole('button', { name: /sign in/i }).click();
  await expect(page).toHaveURL(/\/pos/);
}

test.describe('User management', () => {
  test('admin can view user list', async ({ page }) => {
    await login(page);
    await page.goto('/users');
    await expect(page.locator('.ph-title')).toContainText('Users');
    await expect(page.locator('tbody tr').first()).toBeVisible();
    // Seed admin must be visible
    await expect(page.getByText('admin').first()).toBeVisible();
  });

  test('create new user generates password', async ({ page }) => {
    await login(page);
    await page.goto('/users');

    await page.getByRole('button', { name: /new user/i }).click();
    const uniqueName = `testuser${Date.now().toString().slice(-6)}`;
    await page.getByLabel('Username *').fill(uniqueName);
    await page.getByLabel('Full Name *').fill('Test User');
    await page.getByLabel('Role *').selectOption('sales');
    // Leave password blank → generated
    await page.getByRole('button', { name: 'Create' }).click();

    // Password reveal modal
    await expect(page.getByText(/Password Generated/i)).toBeVisible();
    await expect(page.getByText(uniqueName).first()).toBeVisible();
  });

  test('self-service password change', async ({ page }) => {
    await login(page, 'sales', 'sales123');
    await page.goto('/users');
    await expect(page.getByText(/Change Your Password/i)).toBeVisible();

    await page.getByLabel('Current Password').fill('sales123');
    await page.getByLabel('New Password (min 8)').fill('newSalesPW!');
    await page.getByLabel('Confirm New Password').fill('newSalesPW!');
    await page.getByRole('button', { name: /change password/i }).click();

    await expect(page.locator('.toast').first()).toBeVisible();

    // Change it back so other tests don't break
    await page.getByLabel('Current Password').fill('newSalesPW!');
    await page.getByLabel('New Password (min 8)').fill('sales123');
    await page.getByLabel('Confirm New Password').fill('sales123');
    await page.getByRole('button', { name: /change password/i }).click();
  });
});
