import { test, expect } from '@playwright/test';

async function login(page, user = 'admin', pw = 'admin123') {
  await page.goto('/login');
  await page.getByLabel('Username').fill(user);
  await page.getByLabel('Password').fill(pw);
  await page.getByRole('button', { name: /sign in/i }).click();
  await expect(page).toHaveURL(/\/pos/);
}

test.describe('POS happy path', () => {
  test('add slab to cart, create invoice, verify IRN', async ({ page }) => {
    await login(page);

    // Pick first available slab
    const firstSlab = page.locator('.slab').first();
    await expect(firstSlab).toBeVisible();
    await firstSlab.click();

    // Cart shows 1 item
    await expect(page.locator('.cart-cnt-bdg, .cart-ht').first()).toBeVisible();
    const cartBadge = page.getByText(/items$/).first();
    await expect(cartBadge).toContainText('1');

    // Select a customer (not walk-in, so we get GSTIN)
    await page.locator('.cart-cust select').selectOption({ index: 0 });

    // Grand total > 0
    const grand = page.locator('.tg-val');
    await expect(grand).toContainText(/₹/);

    // Invoice
    await page.getByRole('button', { name: /invoice/i }).click();

    // Overlay shows IRN
    await expect(page.getByText(/IRN/i)).toBeVisible({ timeout: 10_000 });
    await expect(page.getByText(/Grand Total/i)).toBeVisible();

    // Close
    await page.getByRole('button', { name: /done/i }).click();

    // Cart is empty again
    await expect(page.getByText(/Tap slabs to add/i)).toBeVisible();
  });

  test('filter slabs by variety', async ({ page }) => {
    await login(page);
    const totalBefore = await page.locator('.slab').count();

    await page.locator('.sf').nth(0).selectOption('Paradiso Classic');
    await page.waitForTimeout(200);

    const afterFilter = await page.locator('.slab').count();
    expect(afterFilter).toBeLessThanOrEqual(totalBefore);

    // All visible should match
    const varieties = await page.locator('.sl-var').allTextContents();
    for (const v of varieties) {
      expect(v).toBe('Paradiso Classic');
    }
  });

  test('role sees allowed pages; sales cannot see Users', async ({ page }) => {
    await login(page, 'sales', 'sales123');
    // Users link should exist in sidebar but route should gracefully degrade
    await page.goto('/users');
    // Non-admin sees "change your password" fallback
    await expect(page.getByText(/Change Your Password/i)).toBeVisible();
  });
});
